package DemoARRAYLIST;

import java.util.ArrayList;

public class LearningArrayList1 {

	public static void main(String[] args) {
	
		ArrayList obj = new ArrayList();
		
	    obj.add(1234);
	    obj.add("L");
	    obj.add("Learning Selenium");
	    obj.add("Learning Selenium");
	    
	   System.out.println("The ArrayList is "+obj);
	   

	}

}
