package DemoARRAYLIST;

import java.util.ArrayList;
import java.util.Iterator;

public class LearningArrayList2 {

	public static void main(String[] args) {
	
		ArrayList obj = new ArrayList();
		
	    obj.add(1234);
	    obj.add("L");
	    obj.add("Learning Selenium");
	    obj.add("Learning Selenium");
	    
	 //Learning ITERATOR
	    
	    /*Iterator itr = obj.iterator();
	    
	   while(itr.hasNext())
	   {
		   Object value= itr.next();
		   System.out.println("The arraylist is "+ value);
	   }
	    */
	    
	    

	}

}
