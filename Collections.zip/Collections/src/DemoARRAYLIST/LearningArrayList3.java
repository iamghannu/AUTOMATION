package DemoARRAYLIST;

import java.util.ArrayList;

public class LearningArrayList3 {

	public static void main(String[] args) {
	
		ArrayList obj = new ArrayList();
		
	    obj.add(1234);
	    obj.add("L");
	    obj.add("Learning Selenium");
	    obj.add("Learning Selenium");
	    
	    //For Loop
	    for(int i=0;i<obj.size();i++)
	    {
	      System.out.println("The ArrayList is "+ obj.get(i));
	      
	    }
	   
	    //Enhanced For Loop
	    for(Object dummy: obj )
	    {
	    	System.out.println("The ArrayList is "+ dummy);
	    }

	}

}
