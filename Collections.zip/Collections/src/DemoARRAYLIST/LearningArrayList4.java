package DemoARRAYLIST;

import java.util.ArrayList;

public class LearningArrayList4 {

	public static void main(String[] args) {
	
		ArrayList<Integer> Numbers = new ArrayList<>();
		int i=0;
		while(i<10)
		{
			Numbers.add(i);
			i++;
		}
		System.out.println("First ArrayList is "+Numbers);

		ArrayList<Integer> EvenNumbers = new ArrayList<Integer>();
		int j=2;
		while(j<20)
		{
			EvenNumbers.add(j);
			j= j+2;
		}
		System.out.println("Second ArrayList is "+EvenNumbers);
		
		ArrayList<Integer> CommonNumbers = new ArrayList<>(Numbers);
		CommonNumbers.retainAll(EvenNumbers);
		System.out.println("The Common Numbers are "+CommonNumbers);
		
		ArrayList<String> PlacesToGO = new ArrayList<String>();
		
		PlacesToGO.add("PARIS");
		PlacesToGO.add("ITALY");
		PlacesToGO.add("ICELAND");
		PlacesToGO.add("SYDNEY");
		
		ArrayList<String> PlacesMyAukadAllows = new ArrayList<>();
		PlacesMyAukadAllows.add("LONAVALA");
		PlacesMyAukadAllows.add("LAVASA");
		PlacesMyAukadAllows.add("MAHABALESHWAR");
		
		ArrayList<String> DreamVsReality = new ArrayList<>(PlacesToGO);
		DreamVsReality.retainAll(PlacesMyAukadAllows);
		
		System.out.println("Places I want to Go "+PlacesToGO);
		System.out.println("Places My Bank Balance Allows Me To Go "+PlacesMyAukadAllows);
		System.out.println("Does Dreams Ever Turn To Reality "+DreamVsReality);
		
	}

}
