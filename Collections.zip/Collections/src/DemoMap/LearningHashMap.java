package DemoMap;

import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.TreeMap;

public class LearningHashMap {

	public static void main(String[] args) {
		LinkedHashMap<String , String> input= new LinkedHashMap<>();
		input.put("GAMBHIR", "1");
		input.put("SEHWAG", "1");// NATE VALUES CAN BE DUPLICATE, BUT KEYS CANNOT BE DUPLICATE
		input.put("DRAVID", "3");
		input.put("SACHIN", "4");
		input.put("LAXMAN", "5");
		input.put("GANGULY", "6");
		input.put("DHONI", "7");
		
		
		System.out.println(input);
		System.out.println("Sehwag Bats at Position "+input.get("SEHWAG"));
		for(Map.Entry<String,String> Value:input.entrySet())
		{
			System.out.println(Value.getKey()+" Bats At "+Value.getValue());
		}
		
		HashMap<String, String> abc = new HashMap<String, String>();
		abc.put("CAPGEMINI", "4");
		abc.put("CTS", "7.5");
		abc.put("INFOSYS", "8");
		System.out.println(abc);
		for(Map.Entry<String, String> xyz:abc.entrySet())
		{
			System.out.println(xyz.getKey()+" has value "+xyz.getValue());
		}
		
		
		
	}

}
