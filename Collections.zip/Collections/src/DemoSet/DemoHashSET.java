package DemoSet;

import java.util.ArrayList;
import java.util.HashSet;

public class DemoHashSET {

	public static void main(String[] args) {
		
		HashSet<String> Example = new HashSet<>();
		Example.add("SACHIN");
		Example.add("SHIAVNI");
		Example.add("RANGA");
		System.out.println(Example);//HashSet does not maintain any order or indexing
		
		//ADDING A DUPLICATE VALUE(SET DOES NOT ALLOW DUPLICATE VALUES)
		Example.add("SACHIN");
		
		System.out.println(Example);// Note: SACHIN WOULD BE PRESENT ONLY ONCE, EVEN THOUGH ADDED TWICE
		
		
	ArrayList<String> ExampleList = new ArrayList<>(Example);
	System.out.println(ExampleList);
	ExampleList.add("SACHIN");
	System.out.println(ExampleList);// Note: SACHIN WOULD BE PRESENT TWICE, BCZ ARRAYLIST ALLOWS DUPLICATE DATA
	}

}
