package DemoSet;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.LinkedHashSet;

public class DemoLinkedListSET {

	public static void main(String[] args) {
		
		LinkedHashSet<String> Example = new LinkedHashSet<>();
		Example.add("SACHIN");
		Example.add("SHIAVNI");
		Example.add("RANGA");
		System.out.println(Example);//Note: LinkedHashSet Maintains INSERTION order but no indexing
		
		//ADDING A DUPLICATE VALUE(SET DOES NOT ALLOW DUPLICATE VALUES)
		Example.add("SACHIN");
		
		System.out.println(Example);// Note: SACHIN WOULD BE PRESENT ONLY ONCE, EVEN THOUGH ADDED TWICE
		
		
	ArrayList<String> ExampleList = new ArrayList<>(Example);
	System.out.println(ExampleList);
	ExampleList.add("SACHIN");
	System.out.println(ExampleList);// Note: SACHIN WOULD BE PRESENT TWICE, BCZ ARRAYLIST ALLOWS DUPLICATE DATA
	
		}

}
