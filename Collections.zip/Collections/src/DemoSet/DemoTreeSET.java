package DemoSet;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.LinkedHashSet;
import java.util.TreeSet;

public class DemoTreeSET {

	public static void main(String[] args) {
		
		TreeSet<String> Example = new TreeSet<>();
		Example.add("SACHIN");
		Example.add("SHIAVNI");
		Example.add("RANGA");
		
		System.out.println(Example);//Note: TreeSet Maintains ascending order but no indexing
		
		//ADDING A DUPLICATE VALUE(SET DOES NOT ALLOW DUPLICATE VALUES)
		Example.add("SACHIN");
		
		System.out.println(Example);// Note: SACHIN WOULD BE PRESENT ONLY ONCE, EVEN THOUGH ADDED TWICE
		
		
	ArrayList<String> ExampleList = new ArrayList<>(Example);
	System.out.println(ExampleList);
	ExampleList.add("SACHIN");
	System.out.println(ExampleList);// Note: SACHIN WOULD BE PRESENT TWICE, BCZ ARRAYLIST ALLOWS DUPLICATE DATA
	Example.comparator();
	
		}

}
