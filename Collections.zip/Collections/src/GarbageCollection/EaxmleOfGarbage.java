package GarbageCollection;

public class EaxmleOfGarbage {

	public static void main(String[] args) {
		SeniorEmployee E=new SeniorEmployee("GFG1",56,"MANAGER"); 
		SeniorEmployee F=new SeniorEmployee("GFG2",45,"SUPERVISOR");  
		SeniorEmployee G=new SeniorEmployee("GFG3",25,"SENIOR CONSULATANT"); 
        E.show(); 
        F.show(); 
        G.show(); 
        E.showNextId(); 
        F.showNextId(); 
        G.showNextId(); 
              
        {  
            //It is sub block to keep 
            // all those interns. 
        	SeniorEmployee X=new SeniorEmployee("GFG4",23,"MANAGER");      
        	SeniorEmployee Y=new SeniorEmployee("GFG5",21,"SUPERVISOR"); 
            X.show(); 
            Y.show(); 
            X.showNextId(); 
            Y.showNextId(); 
            X = Y = null; 
            System.gc();  
            System.runFinalization(); 
        } 
        E.showNextId(); 

	}

	
	
}
