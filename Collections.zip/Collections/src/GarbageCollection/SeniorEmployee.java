package GarbageCollection;

public class SeniorEmployee extends Employee {

	private String Designation;
	public SeniorEmployee(String name, int age,String Designation) {
		super(name, age);
		this.Designation=Designation;
	}
     @Override
	 public void show() 
	    { 
		 super.show();
	     System.out.println("EXECUTING IN CHILD CLASS");
	    } 
     @Override
	    public void showNextId() 
	    { 
    	 super.showNextId();
	       System.out.println("EXECUTING IN CHILD CLASS");
	    } 
	    
	    @Override
	    protected void finalize() 
	    { 
	        super.finalize();
	        System.out.println("EXECUTING FINALIZE METHOD IN CHILD CLASS");
	    } 
	    
}
