package InterviewPractice;

import java.util.Scanner;

public class ArmStrongNumber {

	public static void main(String[] args) {
		
		int num;
		
		Scanner in= new Scanner(System.in);
		num=in.nextInt();
		
		int temp; int orginal=num;int length=num;int count=0;
		double sum=0; 
		while(length>0)
		{
			
			length=length/10;
			count++;
		}
		while(num>0)
		{
			temp=num%10;
			num=num/10;
			
			sum= sum+(Math.pow(temp,count));
		}
		
		if(sum==orginal)
		{
			System.out.println(sum);
			System.out.println("ARMSTRONG NUMBER");
		}
		
		else
		{
			System.out.println(sum);
			System.out.println("Not an armstrong number");
		}

	}

}
