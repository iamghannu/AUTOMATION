package InterviewPractice;

public class CharDigSpCharSeparation {

	public static void main(String[] args) {
		String name= "ghanshyam@,#$423";
		process(name);

	}

	
	public static void process(String str)
	{
		StringBuffer num= new StringBuffer();
		StringBuffer alp= new StringBuffer();
		StringBuffer spc= new StringBuffer();
		for(int i=0;i< str.length();i++)
		{
			if(Character.isDigit(str.charAt(i)))
			{
				num.append(str.charAt(i));
			}
			else if (Character.isAlphabetic(str.charAt(i)))
			{
				alp.append(str.charAt(i));
			}
			
			else
			{
				spc.append(str.charAt(i));
			}
		}
		
		
	System.out.println(num);System.out.println(alp);System.out.println(spc);
	}
}
