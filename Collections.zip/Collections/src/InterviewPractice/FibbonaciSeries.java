package InterviewPractice;

import java.util.Scanner;

public class FibbonaciSeries {

	public static void main(String[] args) {

		System.out.println("Enter the lenth of Fibbonaci Series");
		int lenth;
		Scanner in = new Scanner(System.in);
		lenth=in.nextInt();
		int x=0;int y=1;
		System.out.print("The Fibbonaci Series is "+x+" "+y);
		for(int i=0;i<lenth-2;i++)
		{
			y=x+y;
			x=y-x;
			System.out.print(" "+y);
		}
	}

}
