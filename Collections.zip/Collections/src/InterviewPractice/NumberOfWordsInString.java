package InterviewPractice;

import java.util.Scanner;

public class NumberOfWordsInString {

	public static void main(String[] args) {
		System.out.println("Enter the String");
		String input;
		Scanner in= new Scanner(System.in);
		input=in.nextLine();
		System.out.println("No Of Words Prsent In the Input String Are: "+CountNoOfWords(input));
	}
	
	public static int CountNoOfWords(String input)
	{
		String[] NoOfWords= input.split(" ");
		
		
		return NoOfWords.length;
		
	}

}
