package InterviewPractice;

public class Pallindrom {

	public static void main(String[] args) {
		String Name="madam";
		System.out.println(Name);
		String ReversedName = null;
		char[] reversed= Name.toCharArray();
		for(int i=reversed.length-1;i>=0;i--)
		{
			System.out.print(reversed[i]);
			ReversedName=ReversedName+reversed[i];			
		}
		
		if(Name.equalsIgnoreCase(ReversedName))
		{
			System.out.println("\nYes it is a pallindrome");
		}
		else
		{
			System.out.println("\nNo it is not a pallindrome");
		}
		
	}

}
