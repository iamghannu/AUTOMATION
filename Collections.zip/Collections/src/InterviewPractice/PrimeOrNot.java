package InterviewPractice;

import java.util.Scanner;

public class PrimeOrNot {

	public static void main(String[] args) {
		int Num;
		System.out.println("Input Number ");
		Scanner input= new Scanner(System.in);
		Num=input.nextInt();
		//input.close();
		System.out.println("The Number Input is "+Num);
		Boolean isPrime = true;
		int temp;
		for(int i=2;i<Num/2;i++)
		{
			 temp= Num%i;
			if(temp==0)
			{
				isPrime=false;
			}
		}
		if(isPrime.equals(true))
		{
			System.out.println("Yes the input number is PRIME");
		}
		else
		{
			System.out.println("No the input number is not PRIME");
		}
	}

}
