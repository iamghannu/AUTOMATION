package InterviewPractice;

public class RemoveSpaceFromString {

	public static void main(String[] args) {
		String str= "I      am        IRONMAN";
		StringBuffer sb= new StringBuffer();
		/*String str2= str.replace(" ", "");
		System.out.println(str2);*/

		char[] ch= str.toCharArray();
		for(int i=0;i<ch.length;i++)
		{
			if((ch[i]!= ' ') && (ch[i] != '\t'))
			{
				sb.append(ch[i]);
			}
		}
		
		System.out.println(sb);
	}

}
