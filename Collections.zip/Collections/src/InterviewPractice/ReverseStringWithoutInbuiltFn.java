package InterviewPractice;

public class ReverseStringWithoutInbuiltFn {

	public static void main(String[] args) {
		String Name="ghanshyam agarwal";
		System.out.println(Name);
		char[] reversed= Name.toCharArray();
		for(int i=reversed.length-1;i>=0;i--)
		{
			System.out.print(reversed[i]);
		}

	}

	
	
	
	
	
}
