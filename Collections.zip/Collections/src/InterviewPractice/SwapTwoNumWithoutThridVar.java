package InterviewPractice;

import java.util.Scanner;

public class SwapTwoNumWithoutThridVar {

	public static void main(String[] args) {
		int x,y;
		System.out.println("Enter x and y");
		Scanner in = new Scanner(System.in);
        x=in.nextInt();
        y=in.nextInt();
        System.out.println("The Numbers before swapping are\nx="+x+"\ny="+y);
        x=x+y;
        y=x-y;
        x=x-y;
        System.out.println("The Numbers after swapping are\nx="+x+"\ny="+y);
	}

}
