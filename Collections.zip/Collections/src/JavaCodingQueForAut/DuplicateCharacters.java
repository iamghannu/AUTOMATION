package JavaCodingQueForAut;

import java.util.ArrayList;
import java.util.LinkedHashSet;

public class DuplicateCharacters {

	public static void main(String[] args)
	{
		String name="GHANSHYAM AGARWAL";
		
		char[] NameInChar= name.toCharArray();
		ArrayList<Character> Duplicate= new ArrayList<>();
		Duplicate= processed(NameInChar);
		System.out.println(Duplicate);
		for(int i=0;i<Duplicate.size();i++)
		{
			System.out.print(Duplicate.get(i));
		}
		
		
		
	}
	
	public static ArrayList<Character> processed(char[] input)
	{
		LinkedHashSet<Character> Unique =new LinkedHashSet<>();
		LinkedHashSet<Character> Duplicatei =new LinkedHashSet<>();
		for(char c: input)
		{
			if(!Unique.add(c))
				
			{
				Duplicatei.add(c);
			}
		}
		ArrayList<Character> output= new ArrayList<>(Duplicatei);
		return output;
		
	}
	
	
	
	
	
	
}
