package JavaCodingQueForAut;



import java.util.LinkedHashMap;

import java.util.Map;

public class DuplicateCharactersAndCount {

	public static void main(String[] args)
	{
		String  name= "Ghanshyam Agarwal";
		System.out.println(name);
	  name=  name.replaceAll(" ", "") ;
		System.out.println(name);
		
		char[] NameInChar= name.toCharArray();
		LinkedHashMap<Character, Integer> Duplicate= new LinkedHashMap<>();
		Duplicate= processed(NameInChar);
		System.out.println(Duplicate);
		for(Map.Entry<Character, Integer> data:Duplicate.entrySet() )
		{
			System.out.println("The letter "+data.getKey()+" is present "+data.getValue()+" times.");
		}
		
		
		
	}
	
	public static LinkedHashMap<Character , Integer> processed(char[] input)
	{
		
		LinkedHashMap<Character , Integer> Result= new LinkedHashMap<>();
		for(int i=0;i<input.length;i++)
		{
			int count=1;
		if(!Result.containsKey(input[i]))
		{
			for(int j=i+1;j<input.length;j++)
		{
			if(input[i]==input[j])
			{
				count++;
			
			}
		}
		
			Result.put(input[i],count);
		
		}
		else
		{
			Result.put(input[i],1);
		}
		}
		return Result;
		
	}
	
	
	
	
	
	
}
