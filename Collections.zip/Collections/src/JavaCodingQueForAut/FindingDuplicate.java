package JavaCodingQueForAut;

import java.util.ArrayList;
import java.util.LinkedHashSet;

public class FindingDuplicate {

	public static void main(String[] args)
	{
		ArrayList<String> input =new ArrayList<>();
		input.add("INDIA");
		input.add("USA");
		input.add("AUSTRALIA");
		input.add("INDIA");
		input.add("INDIA");
		input.add("AUSTRALIA");
		System.out.println(input);
		System.out.println(process(input));
	}
	
	public static ArrayList<String> process(ArrayList<String> input)
	{
		LinkedHashSet<String> Unique = new LinkedHashSet<>();
		LinkedHashSet<String> Duplicate = new LinkedHashSet<>();
		for(String VALUE : input)
		{
			if(!Unique.add(VALUE))
			{
				Duplicate.add(VALUE);
			}
		}
		
		ArrayList<String> Output =new ArrayList<>(Duplicate);
		return Output;
		
	}
}
