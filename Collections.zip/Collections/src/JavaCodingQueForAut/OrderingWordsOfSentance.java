package JavaCodingQueForAut;

import java.util.Scanner;
import java.util.Set;
import java.util.TreeSet;

public class OrderingWordsOfSentance {

	public static void main(String[] args) {
	    String sentence=null;
	    System.out.println("Enter the Sentence:\n");
	    Scanner in= new Scanner(System.in);
	    sentence=in.nextLine();	    
	    Process(sentence);
	}

	public static void Process(String arg1)
	{
		String[] words= arg1.split(" ");
		Set<String> ordered= new TreeSet<String>();
		for(int i=0;i<words.length;i++)
		{
			ordered.add(words[i]);
		}
		for(String abc:ordered)
		{
		System.out.print(abc+" ");
		}
	}
	
	
}
