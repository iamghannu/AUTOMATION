package JavaCodingQueForAut;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Iterator;
import java.util.ListIterator;

public class ReverseTheString {

	public static void main(String[] args) {
		
		String input= "Reverse The String";
		char[] Converted = input.toCharArray();
		System.out.println(Converted);
		System.out.println("");
		//Simple Method
		for(int i=Converted.length-1;i>=0;i--)
		{
			System.out.print(Converted[i]);
		}
		
		//Using Built In Methods
		
		
		//Using StringBuffer
		StringBuffer NEW = new StringBuffer();
		NEW.append(input);
		System.out.println(NEW);
		NEW.reverse();
		System.out.println(NEW);
		
		//Using ARRAYLIST
		ArrayList<Character> Reversed= new ArrayList<>();
		
		for(char e:Converted)
		{
			Reversed.add(e);
		
			
		}
		System.out.println("");
		Collections.reverse(Reversed);//Using Build in REVERSE method to reverse
		
		//USING ADVANCED FOR LOOP TO PRINT
		for(int i=0;i<Reversed.size();i++)
		{
			System.out.print(Reversed.get(i));
		}
		System.out.println("");
		
		//USING ITERATOR TO PRINT
		Iterator li = Reversed.iterator(); 
        while (li.hasNext()) 
        	
            System.out.print(li.next());
		}
		
		
	
}
