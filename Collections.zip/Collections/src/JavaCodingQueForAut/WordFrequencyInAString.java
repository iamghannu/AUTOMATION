package JavaCodingQueForAut;

import java.util.HashMap;
import java.util.Map;
import java.util.Scanner;

public class WordFrequencyInAString {

	public static void main(String[] args) {
		 
		String input= null;
		System.out.println("Enter a String:\n");
		Scanner in= new Scanner(System.in);
		input=in.nextLine();
		Process(input);
	}
	
	public static void Process(String arg1)
	{
		String[] arr= arg1.split(" ");
		Map<String, Integer> Frequency= new HashMap<String, Integer>();
		for (int i=0;i<arr.length;i++)
		{
			if(!Frequency.containsKey(arr[i]))
			{
				Frequency.put(arr[i], 1);
			}
			else
			{
				int count=0;
				 count = Frequency.get(arr[i])+1;
				Frequency.put(arr[i], count);
			}
		}
		
		System.out.println(Frequency);
	}

}
