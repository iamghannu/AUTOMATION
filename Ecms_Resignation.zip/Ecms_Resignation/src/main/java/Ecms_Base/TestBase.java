package Ecms_Base;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.Calendar;
import java.util.List;
import java.util.Properties;
import java.util.Set;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.Alert;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.NoAlertPresentException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.ie.InternetExplorerDriver;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;

import Ecms_Utility.TestUtils;

public class TestBase  {


		public static WebDriver driver;
		public static Properties prop;
		public static Properties or;
		public static Properties Log;
		static String mail_url;
		 private static WebElement element = null;
		 private static List<WebElement> elements = null;

		public TestBase() {

			try {
				prop = new Properties();
				FileInputStream ip = new FileInputStream(System.getProperty("user.dir")
						+ "\\src\\main\\java\\Ecms_Configuration\\Config.Properties");
				prop.load(ip);

				FileInputStream fs = new FileInputStream(System.getProperty("user.dir")
						+ "\\src\\main\\java\\Ecms_Configuration\\Locators.Properties");
				or = new Properties();
				or.load(fs);
			
				
				
				
				

			} catch (FileNotFoundException e) {
				e.printStackTrace();
			} catch (IOException e) {
				e.printStackTrace();
			}

		}
//to open browser
		public static void Initialization() {

			String browsername = prop.getProperty("browser");
			if (browsername.equals("chrome")) {
				String chromepath = System.getProperty("user.dir") + "\\src\\main\\java\\Browser_Drivers\\chromedriver.exe";
				System.setProperty("webdriver.chrome.driver", chromepath);
				driver = new ChromeDriver();
			} else if (browsername.equals("Firefox")) {
				String IEpath = System.getProperty("user.dir") + "\\src\\main\\java\\Browser_Drivers\\geckodriver.exe";
				System.setProperty("webdriver.firefox.driver", IEpath);
				driver = new FirefoxDriver();
			}
			else if (browsername.equals("InternetExplorer")){
				String IEpath = System.getProperty("user.dir") + "\\src\\main\\java\\Browser_Drivers\\IEDriverServer.exe";
				System.setProperty("webdriver.ie.driver", IEpath);
				driver = new InternetExplorerDriver();
			}

			driver.manage().window().maximize();
			driver.manage().deleteAllCookies();
			driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
			//driver.manage().timeouts().pageLoadTimeout(TestUtil.PAGE_LOAD_TIMEOUT, TimeUnit.SECONDS);
			//driver.manage().timeouts().implicitlyWait(TestUtils.PAGE_IMPLICIT_WAIT, TimeUnit.SECONDS);

			driver.get(prop.getProperty("url"));
			

		}
		public static void mail_initialization() throws Throwable{
			String chromepath = System.getProperty("user.dir") + "\\src\\main\\java\\Browser_Drivers\\chromedriver.exe";
			System.setProperty("webdriver.chrome.driver", chromepath);	
			  driver = new ChromeDriver();		 			
			  mail_url=prop.getProperty("file_html");
			  String file_html = System.getProperty("user.dir")+mail_url;
				driver.get(file_html);
				
				
		}
		// findelement method
		public WebElement findelement(String locatorkey) {

			return driver.findElement(By.xpath(or.getProperty(locatorkey)));

		}

		//Findelement by class name
		public WebElement findelement_classname(String locatorkey) {

			return driver.findElement(By.className(or.getProperty(locatorkey)));

		}
		// findelements method

		public List<WebElement> findelements(String locatorkey) {

			return driver.findElements(By.xpath(or.getProperty(locatorkey)));

		}

		// click method
		public void Click(String locatorkey) {
			driver.findElement(By.xpath(or.getProperty(locatorkey))).click();
		}

		// send data method
		public void SendData(String locatorkey, String data) {
			driver.findElement(By.xpath(or.getProperty(locatorkey))).sendKeys(data);
		}

		// get text method
		public String gettext(String locatorkey) {

			return driver.findElement(By.xpath(or.getProperty(locatorkey))).getText();
			

		}
		
		// Vertical scroll - down by 150 pixels
		public void scrollpage() {
			JavascriptExecutor js = (JavascriptExecutor) driver;

			js.executeScript("scroll(0,900)");
		}

		// Vertical scroll - up by 150 pixels
		public void scrollpageup() {
			JavascriptExecutor js = (JavascriptExecutor) driver;

			js.executeScript("scroll(400,0)");
		}

		// Scroll bottom of the page
		public void scrollpagebottom() {
			((JavascriptExecutor) driver).executeScript("window.scrollTo(0, document.body.scrollHeight)");

		}

		// validate for link present
		public boolean isLinkPresent(String xpahtKey) {
			try {
				driver.findElement(By.xpath(or.getProperty(xpahtKey)));
				return true;
			} catch (Exception e) {
				e.printStackTrace();
				return false;
			}

		}

		

		// explicit wait in seconds
		public void explicitwait(String Shridevi) {
			WebDriverWait wait = new WebDriverWait(driver, 20);
			WebElement Element;
			Element = wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath(or.getProperty(Shridevi))));
		}

		// Dropdown
		public void Dropdown(String xpahtKey, String text) {
			Select dropdown = new Select(driver.findElement(By.xpath(or.getProperty(xpahtKey))));
			dropdown.selectByVisibleText(text);
			

		}

		public List<WebElement> Dropdown_list(String xpahtKey, String text) {
			Select dropdown = new Select(driver.findElement(By.xpath(or.getProperty(xpahtKey))));
			dropdown.selectByVisibleText(text);
			List<WebElement> a = dropdown.getOptions();
			return a;

		}
		
		
		//dropdown by index
		public void Dropdown_index(String xpahtKey, int index) {
			Select dropdown = new Select(driver.findElement(By.xpath(or.getProperty(xpahtKey))));
			dropdown.selectByIndex(index);
		}
		
		//popupclose			
		public void popupclose() throws Throwable
		{
			String handle = driver.getWindowHandle();
			
			Set<String> handles = driver.getWindowHandles();
			
			//switch to other window
			for (String handle1 : driver.getWindowHandles())
			{
				
				driver.switchTo().window(handle1);Thread.sleep(1000);
				driver.findElement(By.xpath(or.getProperty("popup_close"))).click();
				driver.switchTo().window(handle);

				}
			
		}

		public String  popupacceptandclose() throws Throwable{
			String message=null;
				String handle = driver.getWindowHandle();
				
				Set<String> handles = driver.getWindowHandles();
				
				//switch to other window
				for (String handle1 : driver.getWindowHandles())
				{
					
					driver.switchTo().window(handle1);
					driver.findElement(By.xpath(or.getProperty("popup_yes"))).click();
					this.explicitwait("popup_close");
					/*message=this.validation_Success_message_onpopupwindow();
					driver.findElement(By.xpath(or.getProperty("popup_close"))).click();*/
					driver.switchTo().window(handle);
					}
				return message;
				
				
			}
		public void popuprejectandclose(){
			String handle = driver.getWindowHandle();
			
			Set<String> handles = driver.getWindowHandles();
			
			//switch to other window
			for (String handle1 : driver.getWindowHandles())
			{
				
				driver.switchTo().window(handle1);
				driver.findElement(By.xpath(or.getProperty("popup_no"))).click();
				this.explicitwait("popup_close");
				driver.findElement(By.xpath(or.getProperty("popup_close"))).click();
				driver.switchTo().window(handle);
				}
		}
		
		public String validation_Success_message_onpopupwindow() throws Throwable{
			String messageonpopup=null;
			String handle = driver.getWindowHandle();
			
			Set<String> handles = driver.getWindowHandles();
			
			//switch to other window
			for (String handle1 : driver.getWindowHandles())
			{
				
				driver.switchTo().window(handle1);
				Thread.sleep(1000);
				 messageonpopup = this.gettext("popup");
				System.out.println(messageonpopup);
				Thread.sleep(1000);
				driver.switchTo().window(handle);		
			}
			return messageonpopup;		
			
			
		}
		//select employee from search box
		//check for sleep time
		public void Employee_Dropdown_Select(String Employeename_Nt_Userid) throws InterruptedException{
			WebElement employeesearch = this.findelement("Employee_Name");
			employeesearch.sendKeys(Employeename_Nt_Userid);
			Thread.sleep(5000);	
			employeesearch.sendKeys(Keys.ARROW_DOWN);
			Thread.sleep(1000);
			employeesearch.sendKeys(Keys.ENTER);
			
			
		}
		
		//Select Employee by Passing XPAth And DATA
		
		public void Dropdown_Select_employee(String Xpath,String Employeename_Nt_Userid) throws InterruptedException{
			WebElement employeesearch = this.findelement(Xpath);
			employeesearch.sendKeys(Employeename_Nt_Userid);
			Thread.sleep(5000);	
			employeesearch.sendKeys(Keys.ARROW_DOWN);
			Thread.sleep(1000);
			employeesearch.sendKeys(Keys.ENTER);
			
			
		}
		
		
		
		public void setup() throws InterruptedException {
			Initialization();
		}
		
		
		public void PopupAccept() throws Throwable
		{
			String handle = driver.getWindowHandle();
			
			Set<String> handles = driver.getWindowHandles();
			
			//switch to other window
			for (String handle1 : driver.getWindowHandles())
			{
				
				driver.switchTo().window(handle1);Thread.sleep(1000);
				driver.findElement(By.xpath(or.getProperty("popupYes"))).click();
				driver.switchTo().window(handle);

				}
			
		}
			
		//Mouse hover using javascript and click
	public void mousehoverclick(String Xpatha, String Xpathb) {
		WebElement a = this.findelement(Xpatha);
		WebElement b = this.findelement(Xpathb);
		try {
			String mouseOverScript = "if(document.createEvent){var evObj = document.createEvent('MouseEvents');evObj.initEvent('mouseover',true, false); arguments[0].dispatchEvent(evObj);} else if(document.createEventObject) { arguments[0].fireEvent('onmouseover');}";
			((JavascriptExecutor) driver).executeScript(mouseOverScript, a);
			Thread.sleep(1000);
			((JavascriptExecutor) driver).executeScript(mouseOverScript, b);
			Thread.sleep(1000);
			((JavascriptExecutor) driver).executeScript("arguments[0].click();", b);

		} catch (Exception e) {

		}
	}
	//Select two items  using normal
			
		public void controlclick(String Xpath1 , String Xpath2){
			WebElement first_webelement = this.findelement(Xpath1);
			WebElement second_WebElement = this.findelement(Xpath2);
			Actions actions = new Actions(driver);
			actions.keyDown(Keys.LEFT_CONTROL).click(first_webelement).click(second_WebElement).keyUp(Keys.LEFT_CONTROL).build().perform();
			
		}
		
		//Calender code ECMS
		
		//pass the locator for Calender and date from excel
		public void datepicker(String date,String locatorDay) throws InterruptedException{
			int k = 0;
			int j= 0;
			WebElement calElement=this.findelement(locatorDay);
			  calElement.click();
			 String spilitter[]=date.split("-");
			  String eday = spilitter[0];
			  String emonth = spilitter[1];
			  String eYear = spilitter[2];
			  String oMonth=this.gettext("Month1");
			  String oYear=this.gettext("Year");
			  int year = Integer.parseInt(eYear);
			  int year_web = Integer.parseInt(oYear);
			  String[] monthName = { "January", "February",
		                "March", "April", "May", "June", "July",
		                "August", "September", "October", "November",
		                "December"};
		        Calendar cal = Calendar.getInstance();
		        String month = monthName[cal.get(Calendar.MONTH)];
		        
		        for(int i = 0;i<monthName.length;i++){
		        	  String name = monthName[i];
		        	if(name.equals(month)){
		        		 k = i;
		        		 
		        	}
		        		if(emonth.equals(name)){
		        			 j = i;
		        			
		        		}
		        		
		        		 }
		       
		       
		       WebElement Next = this.findelement("next");
		 	  
		 	  
		 	  while(!((eYear.contentEquals(oYear)) && (emonth.contentEquals(oMonth))))
		 	  {
		 	    Thread.sleep(2000);
		 	    
		 	   //for year
		 	    
		 	    if(year>year_web){
		 	    	 Next.click();
		 	    }
		 	    	else if (year <year_web){
		 	    		WebElement Previous = this.findelement("Previous");	
			 	    	Previous.click();
		 	    		
		 	    	}
		 	    	else if(year ==year_web){
		 	    
		 	    
		 	    
		 	    if(k < j){
		 	    	
		 	    Next.click();
		 	    }
		 	    else
		 	    {
		 	    	WebElement Previous = this.findelement("Previous");	
		 	    	Previous.click();
		 	    }
		 	    	}
		 	    oMonth=this.gettext("Month1");
		 	    oYear=this.gettext("Year");
		 	    Next = this.findelement("next");
		 	  }
		 	
		 	  List<WebElement> tRow = this.findelements("tr");
		 	  
		 	  for (WebElement tRow1 : tRow) {

		 			String date1 = tRow1.getText();

		 			// Thread.sleep(1000);

		 			 if(eday.equals(date1)) {
		 				System.out.println(date);
		 				tRow1.click();
		 				break;
		 	  
		 	  }
		 	  }}     
		
		//Alert Accept
		public void alert(){
	
		try {

		   // Check the presence of alert
		   Alert alert = driver.switchTo().alert();

		   // if present consume the alert
		   alert.accept();

		  } catch (NoAlertPresentException ex) {
		     //code to do if not exist.
		  }
}
		//Click on selected employee
		public  WebElement Clickonlink_Selected (String Xpath ,String Text){
			elements = this.findelements(Xpath);
			for (WebElement element : elements){
        if(element.getText().contains(Text))
        {
        	element.click();
            return element;
        }
    }    
			return null;
		}


public void file_Upload(){
	
	this.SendData("choose_File", System.getProperty("user.dir")+ "\\src\\main\\java\\Ecms_TestData\\Acceptable_IT_Usage_Policy_v_4.5.pdf");
	this.Click("Upload_Button");
}

	
}

		
	
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		


	
	

