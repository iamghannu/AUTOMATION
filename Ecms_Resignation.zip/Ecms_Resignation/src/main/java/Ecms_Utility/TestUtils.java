package Ecms_Utility;

import java.io.IOException;
import java.io.FileInputStream;
import java.io.FileNotFoundException;

import org.apache.poi.openxml4j.exceptions.InvalidFormatException;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.ss.usermodel.WorkbookFactory;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

public class TestUtils {
	
	
	public static long PAGE_LOAD_TIMEOUT = 50;
	public static long PAGE_IMPLICIT_WAIT = 10;

	
	public static String TESTDATA_SHEET_PATH = System.getProperty("user.dir")+ "\\src\\main\\java\\Ecms_TestData\\ECMS_Resign.xlsx";
	

	static Workbook book;
	static Sheet sheet;

	public static Object[][] getTestdata(String SheetName) {
		FileInputStream file = null;
		try {
			file = new FileInputStream(TESTDATA_SHEET_PATH);

		} catch (FileNotFoundException e) {
			e.printStackTrace();
		}
		try {
			book = WorkbookFactory.create(file);
		} catch (InvalidFormatException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		}
		sheet = book.getSheet(SheetName);

		

		Object[][] data = new Object[sheet.getLastRowNum()][sheet.getRow(0).getLastCellNum()];

		for (int i = 0; i < sheet.getLastRowNum(); i++) {

			for (int j = 0; j < sheet.getRow(i).getLastCellNum(); j++) {
				data[i][j] = sheet.getRow(i + 1).getCell(j).toString();
			}
		}
		return data;

	}

	public static String readexcel( int i ,int j,int lastrow,String sheetname) throws IOException{
		

		// Load the file

		 FileInputStream fis = new FileInputStream(TESTDATA_SHEET_PATH);

		// load the workbook

		XSSFWorkbook wb = new XSSFWorkbook(fis);

		// get the sheet which you want to modify or create

		XSSFSheet sh1 = wb.getSheet(sheetname);
		lastrow=sh1.getLastRowNum();
		 String data = sh1.getRow(i).getCell(j).getStringCellValue();
		 return data;
	}
	
	

	

}
