package Ecms_Utility;

import java.io.File;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import org.openqa.selenium.WebDriver;

import Ecms_Base.TestBase;



public class database_Connection extends TestBase {

	Statement stmt;
	String text;
	String request_Id;
	String Buhr_NtuserId;
	Connection conn = null;
	WebDriver driver;
	String file_txt = System.getProperty("user.dir")+"\\File\\a.txt";
 	File newTextFile;
 	String mail_list;
 	String Leavetype=null;
 	String databse =  prop.getProperty("databse");
 	String database_name = prop.getProperty("database_name");
 	String userName = prop.getProperty("userName");
    String password = prop.getProperty("password");
 	
	// public static final String path1 = System.getProperty("user.dir")+"\\resource\\File\\Mail_data.xlsx";
	 public void testdb() throws ClassNotFoundException, SQLException, Throwable{
	     	//Class.forName("com.microsoft.sqlserver.jdbc.SQLServerDriver");
			 //Class.forName("sun.jdbc.odbc.JdbcOdbcDriver");
	     	System.out.println("driver loaded");
	     	
	     	//Db Connection
	      String url = "jdbc:jtds:sqlserver://10.102.22.136:1433;database="+databse+";integratedSecurity=true";
	        String driver = "com.microsoft.sqlserver.jdbc.SQLServerDriver";
	        
	       /* String userName = "Test_Ecms"; 
	        String password = "Test_Ecms";*/
	        
	      
	        Class.forName(driver);//.newInstance();
	        conn = DriverManager.getConnection(url,userName,password);
	       
	        System.out.println("CONNECTION SUCCESS");
	        Thread.sleep(1000);
	       
		 }
	
	 public String Supervisor_Nt_UserId(String Employeerecordid) throws Throwable{
			
		//[ECMS_SIT].[dbo].[tblmstEmployee]
		 
		 stmt = conn.createStatement();  
        String sqlStr = "Select Sup.NTuserid from "+database_name+".[dbo].[tblmstEmployee] Em inner join "+database_name+".[dbo].[tblmstEmployee] Sup  on sup.EmployeeID= Em.SupervisorID and sup.GlobalGroupID = Em.SupervisorGlobalGroupID where em.EmployeeID="+"'"+Employeerecordid+"'";
        System.out.println(sqlStr);
        //where createdby= "+"'"+Employeerecordid+"'"+"
     	ResultSet rs=stmt.executeQuery(sqlStr);
     	
     	while (rs.next()){
     		//System.out.println("mail subject is :"+rs.getString("MailBody"));
     		     
     text = rs.getString("NTuserid");
     	}   	
 // System.out.println(text);
		return text;
	 }
	 
	 public String request_Id(String Employeerecordid) throws Throwable{
		 stmt = conn.createStatement();   
		 String sqlStr = "select top 1 RequestId from "+database_name+".[dbo].[tbltxnSeparationRequest] where EmployeeID="+"'"+Employeerecordid+"' order by RequestId desc";
		 System.out.println(sqlStr);
		 ResultSet rs=stmt.executeQuery(sqlStr);
	     	
	     	while (rs.next()){
	     		//System.out.println("mail subject is :"+rs.getString("MailBody"));
	     		     
	     request_Id = rs.getString("requestid");
	     	}
			return request_Id;   	
			
		 }

	public void Supervisor_Approval(String request_Id) throws Throwable {
		 stmt = conn.createStatement();
		 
		 
		/* StringBuffer sql = new StringBuffer( "SET rowcount 5" );
		 sql.append( "DECLARE @return_value�int,@ErrorMsg�int EXEC�� @return_value�=�[ECMS_SIT].[dbo].[uspInsSupervisorClearance] @RequestID�="+ request_Id +",@ProjectRelatedMaterialReturned�=�N'yes',@ProjectRelatedMaterialDueAmount�=�NULL,@ProjectRelatedMaterialReturnedComments�=�NULL,@AllTimeSheetsApproved�=�N'yes',@AllTimeSheetsApprovedComments�=�NULL,@ExpenseApproved�=�N'yes',@ExpenseApprovedComments�=�NULL,@ClientAccessRevoked�=�N'yes',@ReplacementSupervisorId�=�NULL,@ProxyCreatedBy�=�NULL,@CreatedBy�=�N'ECMS00_FS',@StatusName�=�N'SupervisorClearanceCleared',@RecoveryOnTravelContract�=�N'yes',@ShiftAllowance�=�N'no',@ShiftAllowanceAmount�=�NULL,@ShiftAllowanceComments�=�NULL,@IsEmployeeMissingTimeCard�=�0,@Flag�=�N'0',@ErrorMsg�=�@ErrorMsg�OUTPUT SELECT�@ErrorMsg�as�N'@ErrorMsg' SELECT�'Return Value'�=�@return_value " );
		 sql.append( " ; " );

	  stmt = (Statement) conn.prepareStatement( sql.toString() ).executeQuery();*/
		 //stmt.executeQuery(sql);

String sqlStr = "DECLARE @return_value�int,@ErrorMsg�int EXEC�� @return_value�=�"+database_name+".[dbo].[uspInsSupervisorClearance] @RequestID�="+ request_Id +",@ProjectRelatedMaterialReturned�=�N'yes',@ProjectRelatedMaterialDueAmount�=�NULL,@ProjectRelatedMaterialReturnedComments�=�NULL,@AllTimeSheetsApproved�=�N'yes',@AllTimeSheetsApprovedComments�=�NULL,@ExpenseApproved�=�N'yes',@ExpenseApprovedComments�=�NULL,@ClientAccessRevoked�=�N'yes',@ReplacementSupervisorId�=�NULL,@ProxyCreatedBy�=�NULL,@CreatedBy�=�N'ECMS00_FS',@StatusName�=�N'SupervisorClearanceCleared',@RecoveryOnTravelContract�=�N'yes',@ShiftAllowance�=�N'no',@ShiftAllowanceAmount�=�NULL,@ShiftAllowanceComments�=�NULL,@IsEmployeeMissingTimeCard�=�0,@Flag�=�N'0',@ErrorMsg�=�@ErrorMsg�OUTPUT SELECT�@ErrorMsg�as�N'@ErrorMsg' SELECT�'Return Value'�=�@return_value"
		+ " ;";
		System.out.println(sqlStr);
		 stmt.executeQuery(sqlStr);

		
		}
	public String Buhr_EmployeeId(String Employee_NtuserId) throws SQLException{
		
		 stmt = conn.createStatement();
		 
		 String sqlStr  = "select BD.BUHRGlobalGroupID,BD.BUHREmployeeID,BD.DataSource,BD.IsActive from "+database_name+".[dbo].[tbltxnBUHRDetails] BD inner join [ECMS_SIT].[dbo].[tblmstemployee] ME on ME.BUID = BD.BUId and ME.DataSource=BD.DataSource where ME.EmployeeID ="+"'"+Employee_NtuserId+"'"+"and BD.IsActive = 1";
		 System.out.println(sqlStr);
	 ResultSet rs = stmt.executeQuery(sqlStr);
	 while (rs.next()){
		 text = rs.getString("BUHREmployeeID");
		 System.out.println(text);
		 return text;
	 }
	return sqlStr;
	 
}
	public String BUHR_Ntuserid(String Employee_NtuserId) throws Throwable{
		String userid = this.Buhr_EmployeeId(Employee_NtuserId);
		 stmt = conn.createStatement();
		 String sqlStr1 = "select ntuserid from "+database_name+".[dbo].[tblmstemployee] where EmployeeID like "+"'"+"%"+userid+"%"+"'";
		 System.out.println(sqlStr1);
		 ResultSet rs1 = stmt.executeQuery(sqlStr1);
		 while (rs1.next()){
			 text = rs1.getString("NTUserID");
			 //System.out.println(text);
			 return text;
		 }
		
		return sqlStr1;
		
		
	}
	
}
	
	
	




