package pages;

import java.sql.SQLException;

import org.openqa.selenium.JavascriptExecutor;

import Ecms_Base.TestBase;
import Ecms_Utility.database_Connection;

public class All_Clearance extends TestBase{
	LoginPage loginpage;
	database_Connection database;
	int lastrow = 1;
	
	
	
	public All_Clearance() {
		
		loginpage = new LoginPage();
		database = new database_Connection();
		
		
	}
	
	public void Supervisor_Approval(String User_id,String Password_Remarks,String Employee_name ) throws Throwable {
		database.testdb();
		String Text = database.Supervisor_Nt_UserId(User_id);
		System.out.println(Text);
		
		
		loginpage.dologin(Text, Password_Remarks);
		Thread.sleep(1000);
		this.mousehoverclick("Approval_Process", "supervisor_Approval");
		
		
		if (isLinkPresent("No_records_found") == true) {

			System.out.println("Record not found");

		}

		else if (isLinkPresent("table") == true) {

		System.out.println(this.gettext("table"));
		this.Clickonlink_Selected("table", Employee_name);
		Thread.sleep(1000);
		if(this.findelement("Waiver_of_Notice_Period").isEnabled()==true){
			this.Dropdown("Waiver_of_Notice_Period", "No");
			Thread.sleep(500);
			this.Dropdown("Waiver_of_Notice_Type", "Recover from Employee");
			}
		else{
			System.out.println("Waiver_of_Notice_Period not applicable");
		}
		this.SendData("Message_to_HRSS_team", Password_Remarks);
		this.Dropdown("My_assessment_of_the_Employee", "Catalysts");
		this.SendData("According_to_me_the_reason_for_resignation_is", "Password_Remarks");
		this.Dropdown("Can_Breach_Agreement", "Yes");
		this.file_Upload();
		if(this.findelement("Waiver_of_Notice_Period").isEnabled()==true){
			this.Dropdown("Waiver_of_Notice_Period", "No");
			Thread.sleep(500);
			this.Dropdown("Waiver_of_Notice_Type", "Recover from Employee");
			}
		else{
			System.out.println("Waiver_of_Notice_Period not applicable");
		}
		this.Click("initiate_button");
		Thread.sleep(1000);
		this.Click("ok");
		Thread.sleep(1000);
		}
		this.Click("logout");

	}
	public void Hrss_Confirmation(String Clearance_Admin,String Password_Remarks,String User_id,String Employee_name) throws InterruptedException {
		loginpage.dologin(Clearance_Admin, Password_Remarks);
		Thread.sleep(1000);
		this.mousehoverclick("Dues_clearance_process", "Hrss_confirmation");
		Thread.sleep(1000);
		this.Employee_Dropdown_Select(User_id);
		this.Click("Search_button");
		if(this.isLinkPresent("no_records_found")==true){
			System.out.println("No employee found for HRSS confirmation");
			
		}
		
		else if(this.isLinkPresent("table")==true){
		this.Clickonlink_Selected("table", Employee_name);
		Thread.sleep(1000);
		this.SendData("comments_hrss",Password_Remarks);
		this.Click("initiate_button");
		Thread.sleep(1000);
		this.Click("ok");
		Thread.sleep(1000);
		}
		this.Click("logout");
	
	}
	
	public void Asset_Managment_clearance(String Clearance_Admin,String Password_Remarks,String User_id,String Employee_name ) throws Throwable {
		loginpage.dologin(Clearance_Admin, Password_Remarks);
		Thread.sleep(1000);
		this.mousehoverclick("Dues_clearance_process", "Asset_Managment");
		Thread.sleep(1000);
		this.Employee_Dropdown_Select(User_id);
		this.Click("Search_button");
		if (isLinkPresent("No_records_found") == true) {

			System.out.println("Record not found");

		}

		else if (isLinkPresent("table") == true) {

		this.Clickonlink_Selected("table", Employee_name);
		Thread.sleep(1000);
		this.Dropdown("Desktop", "Returned");
		this.Dropdown("laptop_with_Accessories", "Returned");
		this.Dropdown("hardware", "Returned");
		this.Dropdown("Software", "Returned");
		Thread.sleep(1000);
		this.file_Upload();
		this.Click("initiate_button");
		Thread.sleep(1000);
		this.Click("ok");
		Thread.sleep(1000);
		}
		this.Click("logout");
		
	}
	public void EISDues_clearance(String Clearance_Admin,String Password_Remarks,String User_id,String Employee_name ) throws Throwable {
		loginpage.dologin(Clearance_Admin, Password_Remarks);
		Thread.sleep(1000);
		this.mousehoverclick("Dues_clearance_process", "EIS_clearance");
		this.Employee_Dropdown_Select(User_id);
		this.Click("Search_button");
		if (isLinkPresent("No_records_found") == true) {

			System.out.println("Record not found");

		}

		else if (isLinkPresent("table") == true) {

		
		this.Clickonlink_Selected("table", Employee_name);
		Thread.sleep(1000);
		this.scrollpagebottom();
		Thread.sleep(1000);
		this.SendData("Salary_Payable", "01");
		this.SendData("EIS_Ammount", "100");
		this.SendData("EIS_Comments", "Password_Remarks");
		Thread.sleep(1000);
		this.file_Upload();
		this.SendData("Salary_Payable", "01");
		this.Click("initiate_button");
		Thread.sleep(1000);
		this.Click("ok");
		Thread.sleep(1000);
		}
		this.Click("logout");
		
		
		
	}
	
	public void Supervisor_clearance(String User_id ) throws Throwable {
		database.testdb();
		String request_Id = database.request_Id(User_id);
		System.out.println(request_Id);
		database.testdb();
		database.Supervisor_Approval(request_Id);
	}
	
	public void finance_clearance(String Clearance_Admin,String Password_Remarks,String User_id,String Employee_name ) throws Throwable {
		loginpage.dologin(Clearance_Admin, Password_Remarks);
		Thread.sleep(1000);
		this.mousehoverclick("Dues_clearance_process", "Finance_clearance");
		this.Employee_Dropdown_Select(User_id);
		this.Click("Search_button");
		if (isLinkPresent("No_records_found") == true) {

			System.out.println("Record not found");

		}

		else if (isLinkPresent("table") == true) {

		this.Clickonlink_Selected("table", Employee_name);
		Thread.sleep(1000);
		this.scrollpage();
		this.Dropdown("Kit_Allowance_Cost_Recovery", "Yes");
		Thread.sleep(1000);
		this.SendData("kit_Amount", "50");

		this.SendData("LTA", "Yes");
		Thread.sleep(1000);
		this.SendData("Lta_Amount", "70");
		this.Dropdown("Telephone_Recovery", "Yes");
		Thread.sleep(1000);
		this.SendData("Telephone_Amount", "80");
		this.Dropdown("Deduction_Others", "Yes");
		Thread.sleep(1000);
		this.SendData("Deduction_other_amount", "20");
		this.Dropdown("Housing_Advance", "Yes");
		Thread.sleep(1000);
		this.SendData("Housing_Advance_Amount", "40");
		this.Dropdown("Foreign_Exchange", "Yes");
		Thread.sleep(1000);
		this.SendData("Foreign_Exchange_Amount", "45");
		if (this.findelement("Relocation_cost_finance").isEnabled()) {
			this.Dropdown("Relocation_cost_finance", "Yes");
			Thread.sleep(1000);
			this.SendData("Relocation_cost_finance_Amount", "45");
		}

		else {

			System.out.println("Relocation cost finance bonus field is disabled");
		}

		this.Dropdown("Relocation_Cost", "Yes");
		Thread.sleep(1000);
		this.SendData("Relocation_Cost_Amount", "15");
		this.Dropdown("Outstanding_Prepaid_Variable_Bonus", "Yes");
		Thread.sleep(500);
		this.SendData("Outstanding_Prepaid_Variable_Bonus_Amount", "40");
		JavascriptExecutor js = (JavascriptExecutor) driver;
		js.executeScript("scroll(0,1200)");
		if (this.findelement("Joining_Bonus_Recovery").isEnabled()) {
			this.Dropdown("Joining_Bonus_Recovery", "Yes");
			Thread.sleep(1000);
			this.SendData("Joining_Bonus_Recovery_Amount", "35");
		}

		else {

			System.out.println("Joining bonus field is disabled");
		}

		this.Dropdown("Overpayment_Salary", "Yes");
		Thread.sleep(500);
		this.SendData("Overpayment_Salary_Amount", "47");
		this.Dropdown("Advance_Salary", "Yes");
		Thread.sleep(500);
		this.SendData("Advance_Salary_Amount", "20");

		this.Dropdown("OAAR", "Yes");
		Thread.sleep(500);
		this.SendData("OAAR_Amount", "26");
		this.Dropdown("Reimbursement", "Yes");
		Thread.sleep(500);
		this.SendData("Reimbursement_Amount", "36");
		if(this.findelement("Hot_Skill").isEnabled()==true){
			this.Dropdown("Hot_Skill", "None");
			}
		else{
			System.out.println("Hot Skill bonous not applicable");
		}
		if(this.findelement("HotSkillBonusRecoveryAmount").isEnabled()==true){
			this.SendData("HotSkillBonusRecoveryAmount", "50");
		}
		else{
			System.out.println("HotSkillBonusRecoveryAmount not applicable");
		}
		if(this.findelement("RetentionBonusRecovery").isEnabled()==true){
			this.Dropdown("RetentionBonusRecovery", "None");
			}
		else{
			System.out.println("RetentionBonusRecovery bonous not applicable");
		}
		if(this.findelement("RetentionBonusRecoveryAmount").isEnabled()==true){
			this.SendData("RetentionBonusRecoveryAmount", "50");
		}
		else{
			System.out.println("RetentionBonusRecoveryAmount not applicable");
		}
		
		if(this.findelement("AdvanceVariablePayout").isEnabled()==true){
			this.Dropdown("AdvanceVariablePayout", "None");
			}
		else{
			System.out.println("AdvanceVariablePayout bonous not applicable");
		}
		if(this.findelement("AdvanceVariablePayoutAmount").isEnabled()==true){
			this.SendData("AdvanceVariablePayoutAmount", "50");
		}
		else{
			System.out.println("AdvanceVariablePayoutAmount not applicable");
		}
		if(this.findelement("OneTimeBonus").isEnabled()==true){
			this.Dropdown("OneTimeBonus", "None");
			}
		else{
			System.out.println("OneTimeBonus bonous not applicable");
		}
		if(this.findelement("OneTimeBonusAmount").isEnabled()==true){
			this.SendData("OneTimeBonusAmount", "50");
		}
		else{
			System.out.println("OneTimeBonusAmount not applicable");
		}
		if(this.findelement("SpecialBonus").isEnabled()==true){
			this.Dropdown("SpecialBonus", "None");
			}
		else{
			System.out.println("SpecialBonus bonous not applicable");
		}
		if(this.findelement("SpecialBonusAmount").isEnabled()==true){
			this.SendData("SpecialBonusAmount", "50");
		}
		else{
			System.out.println("SpecialBonusAmount not applicable");
		}
		if(this.findelement("NoticePay").isEnabled()==true){
			this.Dropdown("NoticePay", "None");
			}
		else{
			System.out.println("NoticePay bonous not applicable");
		}
		if(this.findelement("NoticePayAmount").isEnabled()==true){
			this.SendData("NoticePayAmount", "50");
		}
		else{
			System.out.println("NoticePayAmount not applicable");
		}
		
		this.scrollpagebottom();
		this.Click("initiate_button");
		Thread.sleep(1000);
		this.Click("ok");
		Thread.sleep(1000);
		}
		this.Click("logout");
	}
	
	public void Icres_clearance(String Clearance_Admin,String Password_Remarks,String User_id,String Employee_name) throws Throwable {
		loginpage.dologin(Clearance_Admin, Password_Remarks);
		Thread.sleep(1000);
		this.mousehoverclick("Dues_clearance_process", "Icres_clearance");
		this.Employee_Dropdown_Select(User_id);
		this.Click("Search_button");
		if (isLinkPresent("No_records_found") == true) {

			System.out.println("Record not found");

		}

		else if (isLinkPresent("table") == true) {

		this.Clickonlink_Selected("table", Employee_name);
		Thread.sleep(1000);
		this.Dropdown("Bus_Pass", "Returned");
		this.SendData("Bus_Pass_Amount", "100");
		this.Click("BusPass_check_Box");
		this.scrollpagebottom();
		
		
		
		if(this.findelement("Drawer_Key").isEnabled()==true){
			this.Dropdown("Drawer_Key", "Not Applicable");
			}
		else{
			System.out.println("Drawer_Key  not applicable");
		}
		this.Click("Drawer_key_checkbox");
		
		
		if(this.findelement("Access_Card").isEnabled()==true){
			this.Dropdown("Access_Card", "Not Applicable");
			}
		else{
			System.out.println("Access_Card  not applicable");
		}
		
		
		this.Click("Access_Card_checkbox");
		
		
		if(this.findelement("Amex_Card").isDisplayed()==true && this.findelement("Amex_Card").isEnabled()==true){
			this.Dropdown("Amex_Card", "Not Applicable");
			}
		else{
			System.out.println("Amex_Card  not applicable");
		}
		this.Click("Amex_card_checkbox");

		//this.file_Upload();
		this.Click("initiate_button");
		Thread.sleep(1000);
		this.Click("ok");
		Thread.sleep(1000);
		}
		this.Click("logout");
	}
	
	public void LEARNING_DEVELOPMENT_CLEARANCE(String Clearance_Admin,String Password_Remarks,String User_id,String Employee_name ) throws Throwable {
		loginpage.dologin(Clearance_Admin, Password_Remarks);
		Thread.sleep(1000);
		this.mousehoverclick("Dues_clearance_process", "LEARNING_DEVELOPMENT_CLEARANCE");
		this.Employee_Dropdown_Select(User_id);
		this.Click("Search_button");
		if (isLinkPresent("No_records_found") == true) {

			System.out.println("Record not found");

		}

		else if (isLinkPresent("table") == true) {

		this.Clickonlink_Selected("table", Employee_name);
		Thread.sleep(1000);
		this.scrollpagebottom();

		if (this.findelement("Library_books").isDisplayed()) {
			this.Dropdown("Library_books", "Not Applicable");
		}

		else {

			System.out.println("Record not found");
		}

		if (this.findelement("Certification").isDisplayed()) {
			this.Dropdown("Certification", "Not Applicable");
		}

		else {

			System.out.println("Certification clearance not aplicable");
		}
		
		this.Click("initiate_button");
		Thread.sleep(1000);
		this.Click("ok");
		Thread.sleep(1000);
		}
		this.Click("logout");

	}
	public void TIME_HELPDESK_CLEARANCECLEARANCE(String Clearance_Admin,String Password_Remarks,String User_id,String Employee_name) throws Throwable {
		loginpage.dologin(Clearance_Admin, Password_Remarks);
		Thread.sleep(1000);
		this.mousehoverclick("Dues_clearance_process", "timehelpDesk_Clearance");
		this.Employee_Dropdown_Select(User_id);
		this.Click("Search_button");

		if (isLinkPresent("No_records_found") == true) {

			System.out.println("Record not found");

		}

		else if (isLinkPresent("table") == true) {

			this.Clickonlink_Selected("table", Employee_name);
			Thread.sleep(1000);
			this.Dropdown("Timecard_Approval", "Approved");
			this.Click("initiate_button");
			Thread.sleep(1000);
			this.Click("ok");
			Thread.sleep(1000);
		}

		this.Click("logout");

		
		
		
		
	}
	public void PEOPLE_PROCESS_CLEARANCE(String Clearance_Admin,String Password_Remarks,String User_id,String Employee_name ) throws Throwable {
		loginpage.dologin(Clearance_Admin, Password_Remarks);
		Thread.sleep(1000);
		this.mousehoverclick("Dues_clearance_process", "People_Process");
		this.Employee_Dropdown_Select(User_id);
		this.Click("Search_button");
		if (isLinkPresent("No_records_found") == true) {

			System.out.println("Record not found");

		}

		else if (isLinkPresent("table") == true) {

		this.Clickonlink_Selected("table", Employee_name);
		Thread.sleep(1000);
		this.Dropdown("Shift_Allowance", "Not Applicable");
		Thread.sleep(1000);
		this.scrollpagebottom();
		Thread.sleep(1000);
		this.findelement("Leave_Encashment_days").clear();
		this.SendData("Leave_Encashment_days", "10");
		this.findelement("Leave_Without_pay").clear();
		this.SendData("Leave_Without_pay", "2");
		this.findelement("Comments_Peopleprocess").clear();
		this.SendData("Comments_Peopleprocess", "test");
		this.Click("initiate_button");
		Thread.sleep(1000);
		this.Click("ok");
		Thread.sleep(1000);
		}
		this.Click("logout");
		
		
		
		
		
	}
	
	public void Mobility_CLEARANCE(String Clearance_Admin,String Password_Remarks,String User_id,String Employee_name) throws Throwable {
		loginpage.dologin(Clearance_Admin, Password_Remarks);
		Thread.sleep(1000);
		this.mousehoverclick("Dues_clearance_process", "Mobility_clearance");
		this.Employee_Dropdown_Select(User_id);
		this.Click("Search_button");
		if (isLinkPresent("No_records_found") == true) {

			System.out.println("Record not found");

		}

		else if (isLinkPresent("table") == true) {

		this.Clickonlink_Selected("table", Employee_name);
		Thread.sleep(1000);
		this.scrollpagebottom();
		this.Dropdown("Work_Permit", "No");
		this.Dropdown("Recovery_against_Loa", "Yes");
		this.SendData("Recovery_against_loa_Amount", "1000");
		this.SendData("Mobility_comments", Password_Remarks);
		this.Click("initiate_button");
		Thread.sleep(1000);
		this.Click("ok");
		Thread.sleep(1000);
		}
		this.Click("logout");
	}
	
	public void BUHR_Clearance(String User_id,String Password_Remarks,String Employee_name ) throws Exception, SQLException, Throwable{
		

		
		database.testdb();
		String BUHR_Ntuserid = database.BUHR_Ntuserid(User_id);
		System.out.println(BUHR_Ntuserid);
		loginpage.dologin(BUHR_Ntuserid, Password_Remarks);
		Thread.sleep(1000);
		this.mousehoverclick("Dues_clearance_process", "BUHR_clearance");
		this.Employee_Dropdown_Select(User_id);
		this.Click("Search_button");
		if (isLinkPresent("No_records_found") == true) {

			System.out.println("Record not found");

		}

		else if (isLinkPresent("table") == true) {

		this.Clickonlink_Selected("table", Employee_name);
		Thread.sleep(1000);
		this.scrollpagebottom();
		this.Dropdown("BU_HR_assessment", "Regretted");
		this.Dropdown("Reason_as_Per_BUHR", "Voluntary");
		Thread.sleep(500);
		this.Dropdown("Sub_Reason", "Resignation");
		this.Dropdown("Last_Rating", "Not Available");
		this.Dropdown("Eligible_For_Rehire", "Yes");
		this.SendData("Comments_BUHR", Password_Remarks);
		this.Click("initiate_button");
		Thread.sleep(1000);
		this.Click("ok");
		Thread.sleep(1000);
		}
		this.Click("logout");
		}
	public void Final_clearance(String Clearance_Admin,String Password_Remarks,String User_id,String Employee_name) throws Throwable{
		loginpage.dologin(Clearance_Admin, Password_Remarks);
		Thread.sleep(1000);
		this.mousehoverclick("Dues_clearance_process", "Final_clearance");
		this.Employee_Dropdown_Select(User_id);
		this.Click("Search_button");
		if (isLinkPresent("No_records_found") == true) {

			System.out.println("Record not found");

		}

		else if (isLinkPresent("table") == true) {

		this.Clickonlink_Selected("table", Employee_name);
		Thread.sleep(1000);
		this.Dropdown("Recovered", "Not Applicable");
		this.scrollpagebottom();
		this.Click("SendEmail");
		Thread.sleep(1000);
		this.Click("ok_button");
		Thread.sleep(1000);
		this.Click("submit_button");
		this.Click("ok");
		Thread.sleep(1000);
		}
		this.Click("logout");
		}
	
	
 

	
	 public void Performance_CLEARANCE(String Clearance_Admin,String Password_Remarks,String User_id,String Employee_name, String Project_Exit_Interview_date
			 ) throws Throwable {
	
			 
	loginpage.dologin(Clearance_Admin, Password_Remarks);
	Thread.sleep(1000);
	this.mousehoverclick("Dues_clearance_process", "performance_clearance");
	this.Employee_Dropdown_Select(User_id);
	this.Click("Search_button");
	this.Clickonlink_Selected("table", Employee_name);
	Thread.sleep(1000);
	this.scrollpagebottom();
	this.Dropdown("Reason_For_Completing_Project", "Self Only");
	this.datepicker(Project_Exit_Interview_date, "Project_Exit_Interview_date");
	this.SendData("performance_Comments", "test");
	this.Click("initiate_button");
	Thread.sleep(1000);
	this.Click("ok");
	Thread.sleep(1000);
	this.Click("logout");
	
	 }
	 
 

	
	}

	
	
	

