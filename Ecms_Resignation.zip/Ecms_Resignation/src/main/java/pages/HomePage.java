package pages;

import Ecms_Base.TestBase;

public class HomePage extends TestBase {
	
	public void usermanagment(){
		this.explicitwait("System_Administrator");
		
		this.mousehoverclick("System_Administrator", "user_managment");
		
		
		
	}
	

}
