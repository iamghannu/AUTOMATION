package pages;

import Ecms_Base.TestBase;

public class LoginPage extends TestBase {
	
	public void dologin(String Username,String Password) throws InterruptedException{

	this.SendData("Userid", Username);
	this.SendData("password", Password);
	this.Click("login");
	Thread.sleep(1000);
	
	
	}
	
}
