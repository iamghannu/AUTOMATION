package Resignation_Flow;

import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import pages.All_Clearance;
import pages.LoginPage;
import Ecms_Base.TestBase;
import Ecms_Utility.TestUtils;
import Ecms_Utility.database_Connection;

public class Resignation_ByAdmin_Flow extends TestBase {
	
	int lastrow = 1;
	LoginPage loginpage;
	database_Connection database;
	All_Clearance clearance;
	int i;

	
	@BeforeTest
	public void browseropen(){
		
		loginpage = new LoginPage();
		database = new database_Connection();
		clearance = new All_Clearance();
		Initialization();
		
		
		
	}
	
	@Test(priority = 1, enabled = false, description = "Resignation by Admin")
	public void Admin_Resignation() throws Throwable{
		for(int i =(Integer.parseInt(TestUtils.readexcel(1, 1, lastrow, "Resign_By_Admin")));i<=(Integer.parseInt(TestUtils.readexcel(2, 1, lastrow, "Resign_By_Admin")));i++){
		String AdminNtUserID = TestUtils.readexcel(i, 0, lastrow, "Resign_By_Admin");
		String Password_Remarks = TestUtils.readexcel(i, 1, lastrow, "Resign_By_Admin");
		String Seperation_type = TestUtils.readexcel(i, 3, lastrow, "Resign_By_Admin");
		String Resignation_Date = TestUtils.readexcel(i, 4, lastrow, "Resign_By_Admin");
		String LastWorking_date = TestUtils.readexcel(i, 5, lastrow, "Resign_By_Admin");
		String Mobile_Number = TestUtils.readexcel(i, 12, lastrow, "Resign_By_Admin");
		String Personal_Email_Address = TestUtils.readexcel(i, 13, lastrow, "Resign_By_Admin");
		String amex_card = TestUtils.readexcel(i, 15, lastrow, "Resign_By_Admin");
		String User_id = TestUtils.readexcel(i, 2, lastrow, "Resign_By_Admin");
		String SubReason= TestUtils.readexcel(i, 10, lastrow, "Resign_By_Admin");
		String Reason= TestUtils.readexcel(i, 9, lastrow, "Resign_By_Admin");
		loginpage.dologin(AdminNtUserID, Password_Remarks);
		this.mousehoverclick("admin", "initiate_Seperation");
		this.Employee_Dropdown_Select(User_id);
		this.Dropdown("Seperation_type", Seperation_type);
		this.Click("submit_button1");
		this.datepicker(Resignation_Date, "Resignation_date");
		Thread.sleep(1000);
		this.Click("select");
		this.datepicker(LastWorking_date,"LastWorkin_Day");
		
		if(this.findelement("select").isEnabled()){
			this.Dropdown("select", "No");
			Thread.sleep(1000);
			this.Dropdown("Wavier_NP", "Recover from Employee");
			Thread.sleep(1000);
			}
		
		else{
			
			System.out.println("Resignation initiated for 90 or more than 90 days");
			
		}
		Thread.sleep(1000);
		this.scrollpagebottom();
		this.Dropdown("Reason", Reason);
		Thread.sleep(1000);
		this.Dropdown("Subreason", SubReason);
		Thread.sleep(1000);
		this.findelement("landlinenumber").clear();
		this.findelement("Mobile_Number").clear();
		this.SendData("Mobile_Number", Mobile_Number);
		Thread.sleep(1000);
		this.findelement("Personal_Email_Address").clear();
		this.SendData("Personal_Email_Address", Personal_Email_Address);
		Thread.sleep(1000);
		this.SendData("comments_resignbyadmin", "Test");
		Thread.sleep(1000);
		this.Dropdown("amex_card", "No");
		Thread.sleep(1000);
		this.file_Upload();
		Thread.sleep(1000);
		this.Click("initiate_button");
		this.alert();
		Thread.sleep(1000);
		this.Click("ok_button");
		Thread.sleep(1000);
		this.Click("logout");
	
	}
	}
	
	@Test(priority = 2, enabled = false, description = "Approval by supervisor")
	public void Supervisor_Approval() throws Throwable {
		for(int i =(Integer.parseInt(TestUtils.readexcel(1, 1, lastrow, "Resign_By_Admin")));i<=(Integer.parseInt(TestUtils.readexcel(2, 1, lastrow, "Resign_By_Admin")));i++){
		String User_id = TestUtils.readexcel(i, 2, lastrow, "Resign_By_Admin");
		String Employee_name = TestUtils.readexcel(i, 16, lastrow, "Resign_By_Admin");
		String Password_Remarks = TestUtils.readexcel(i, 1, lastrow, "Resign_By_Admin");
		clearance.Supervisor_Approval(User_id, Password_Remarks, Employee_name);

	}
	}

	@Test(priority = 3, enabled = false, description = "Hrss confirmation")
	public void Hrss_Confirmation() throws Throwable {
		for(int i =(Integer.parseInt(TestUtils.readexcel(1, 1, lastrow, "Resign_By_Admin")));i<=(Integer.parseInt(TestUtils.readexcel(2, 1, lastrow, "Resign_By_Admin")));i++){
		String Clearance_Admin = TestUtils.readexcel(i, 17, lastrow, "Resign_By_Admin");
		String Password_Remarks = TestUtils.readexcel(i, 1, lastrow, "Resign_By_Admin");
		String User_id = TestUtils.readexcel(i, 2, lastrow, "Resign_By_Admin");
		String Employee_name = TestUtils.readexcel(i, 16, lastrow, "Resign_By_Admin");
		clearance.Hrss_Confirmation(Clearance_Admin, Password_Remarks, User_id, Employee_name);
	}
	}

	@Test(priority = 4, enabled = false, description = "Asset managment clearance")
	public void Asset_Managment_clearance() throws Throwable {
		for(int i =(Integer.parseInt(TestUtils.readexcel(1, 1, lastrow, "Resign_By_Admin")));i<=(Integer.parseInt(TestUtils.readexcel(2, 1, lastrow, "Resign_By_Admin")));i++){
		String Clearance_Admin = TestUtils.readexcel(i, 17, lastrow, "Resign_By_Admin");
		String Password_Remarks = TestUtils.readexcel(i, 1, lastrow, "Resign_By_Admin");
		String User_id = TestUtils.readexcel(i, 2, lastrow, "Resign_By_Admin");
		String Employee_name = TestUtils.readexcel(i, 16, lastrow, "Resign_By_Admin");
		clearance.Asset_Managment_clearance(Clearance_Admin, Password_Remarks, User_id, Employee_name);
	}
	}

	@Test(priority = 5, enabled = false, description = "EISDues clearance")
	public void EISDues_clearance() throws Throwable {
		for(int i =(Integer.parseInt(TestUtils.readexcel(1, 1, lastrow, "Resign_By_Admin")));i<=(Integer.parseInt(TestUtils.readexcel(2, 1, lastrow, "Resign_By_Admin")));i++){
		String Clearance_Admin = TestUtils.readexcel(i, 17, lastrow, "Resign_By_Admin");
		String Password_Remarks = TestUtils.readexcel(i, 1, lastrow, "Resign_By_Admin");
		String User_id = TestUtils.readexcel(i, 2, lastrow, "Resign_By_Admin");
		String Employee_name = TestUtils.readexcel(i, 16, lastrow, "Resign_By_Admin");
		clearance.EISDues_clearance(Clearance_Admin, Password_Remarks, User_id, Employee_name);
	}
	}

	@Test(priority = 6, enabled = false, description = "Supervisor clearance")
	public void Supervisor_clearance() throws Throwable {
		for(int i =(Integer.parseInt(TestUtils.readexcel(1, 1, lastrow, "Resign_By_Admin")));i<=(Integer.parseInt(TestUtils.readexcel(2, 1, lastrow, "Resign_By_Admin")));i++){

		String User_id = TestUtils.readexcel(i, 2, lastrow, "Resign_By_Admin");
		clearance.Supervisor_clearance(User_id);
	}
	}

	@Test(priority = 7, enabled = false, description = "Finance clearance")
	public void finance_clearance() throws Throwable {
		for(int i =(Integer.parseInt(TestUtils.readexcel(1, 1, lastrow, "Resign_By_Admin")));i<=(Integer.parseInt(TestUtils.readexcel(2, 1, lastrow, "Resign_By_Admin")));i++){

		String Clearance_Admin = TestUtils.readexcel(i, 17, lastrow, "Resign_By_Admin");
		String Password_Remarks = TestUtils.readexcel(i, 1, lastrow, "Resign_By_Admin");
		String User_id = TestUtils.readexcel(i, 2, lastrow, "Resign_By_Admin");
		String Employee_name = TestUtils.readexcel(i, 16, lastrow, "Resign_By_Admin");
		clearance.finance_clearance(Clearance_Admin, Password_Remarks, User_id, Employee_name);
	}
	}
	@Test(priority = 8, enabled = true, description = "ICRES clearance")
	public void Icres_clearance() throws Throwable {
		for(int i =(Integer.parseInt(TestUtils.readexcel(1, 1, lastrow, "Resign_By_Admin")));i<=(Integer.parseInt(TestUtils.readexcel(2, 1, lastrow, "Resign_By_Admin")));i++){

		String Clearance_Admin = TestUtils.readexcel(i, 17, lastrow, "Resign_By_Admin");
		String Password_Remarks = TestUtils.readexcel(i, 1, lastrow, "Resign_By_Admin");
		String User_id = TestUtils.readexcel(i, 2, lastrow, "Resign_By_Admin");
		String Employee_name = TestUtils.readexcel(i, 16, lastrow, "Resign_By_Admin");
		clearance.Icres_clearance(Clearance_Admin, Password_Remarks, User_id, Employee_name);
	}
	}

	@Test(priority = 9, enabled = true, description = "LEARNING & DEVELOPMENT CLEARANCE")
	public void LEARNING_DEVELOPMENT_CLEARANCE() throws Throwable {
		for(int i =(Integer.parseInt(TestUtils.readexcel(1, 1, lastrow, "Resign_By_Admin")));i<=(Integer.parseInt(TestUtils.readexcel(2, 1, lastrow, "Resign_By_Admin")));i++){
	

		String Clearance_Admin = TestUtils.readexcel(i, 17, lastrow, "Resign_By_Admin");
		String Password_Remarks = TestUtils.readexcel(i, 1, lastrow, "Resign_By_Admin");
		String User_id = TestUtils.readexcel(i, 2, lastrow, "Resign_By_Admin");
		String Employee_name = TestUtils.readexcel(i, 16, lastrow, "Resign_By_Admin");
		clearance.LEARNING_DEVELOPMENT_CLEARANCE(Clearance_Admin, Password_Remarks, User_id, Employee_name);
	}
}

	@Test(priority = 10, enabled = true, description = "TIME HELPDESK CLEARANCE")
	public void TIME_HELPDESK_CLEARANCECLEARANCE() throws Throwable {
		for(int i =(Integer.parseInt(TestUtils.readexcel(1, 1, lastrow, "Resign_By_Admin")));i<=(Integer.parseInt(TestUtils.readexcel(2, 1, lastrow, "Resign_By_Admin")));i++){
		String Clearance_Admin = TestUtils.readexcel(i, 17, lastrow, "Resign_By_Admin");
		String Password_Remarks = TestUtils.readexcel(i, 1, lastrow, "Resign_By_Admin");
		String User_id = TestUtils.readexcel(i, 2, lastrow, "Resign_By_Admin");
		String Employee_name = TestUtils.readexcel(i, 16, lastrow, "Resign_By_Admin");
		clearance.TIME_HELPDESK_CLEARANCECLEARANCE(Clearance_Admin, Password_Remarks, User_id, Employee_name);
	}
	}

	@Test(priority = 11, enabled = true, description = " PEOPLE PROCESS/HR CLEARANCE")
	public void PEOPLE_PROCESS_CLEARANCE() throws Throwable {
		for(int i =(Integer.parseInt(TestUtils.readexcel(1, 1, lastrow, "Resign_By_Admin")));i<=(Integer.parseInt(TestUtils.readexcel(2, 1, lastrow, "Resign_By_Admin")));i++){
		String Clearance_Admin = TestUtils.readexcel(i, 17, lastrow, "Resign_By_Admin");
		String Password_Remarks = TestUtils.readexcel(i, 1, lastrow, "Resign_By_Admin");
		String User_id = TestUtils.readexcel(i, 2, lastrow, "Resign_By_Admin");
		String Employee_name = TestUtils.readexcel(i, 16, lastrow, "Resign_By_Admin");
		clearance.PEOPLE_PROCESS_CLEARANCE(Clearance_Admin, Password_Remarks, User_id, Employee_name);
		}
	}

	@Test(priority = 12, enabled = true, description = " Mobility CLEARANCE")
	public void Mobility_CLEARANCE() throws Throwable {
		for(int i =(Integer.parseInt(TestUtils.readexcel(1, 1, lastrow, "Resign_By_Admin")));i<=(Integer.parseInt(TestUtils.readexcel(2, 1, lastrow, "Resign_By_Admin")));i++){
		String Clearance_Admin = TestUtils.readexcel(i, 17, lastrow, "Resign_By_Admin");
		String Password_Remarks = TestUtils.readexcel(i, 1, lastrow, "Resign_By_Admin");
		String User_id = TestUtils.readexcel(i, 2, lastrow, "Resign_By_Admin");
		String Employee_name = TestUtils.readexcel(i, 16, lastrow, "Resign_By_Admin");
		clearance.Mobility_CLEARANCE(Clearance_Admin, Password_Remarks, User_id, Employee_name);
		}
	}
	}

	

