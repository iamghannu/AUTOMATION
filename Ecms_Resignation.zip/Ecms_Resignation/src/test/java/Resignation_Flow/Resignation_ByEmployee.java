package Resignation_Flow;

import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import pages.All_Clearance;
import pages.LoginPage;
import Ecms_Base.TestBase;
import Ecms_Utility.TestUtils;
import Ecms_Utility.database_Connection;

public class Resignation_ByEmployee extends TestBase {

	int lastrow = 1;
	LoginPage loginpage;
	database_Connection database;
	All_Clearance clearance;
int i;
	@BeforeTest
	public void browseropen() {

		loginpage = new LoginPage();
		database = new database_Connection();
		clearance = new All_Clearance();
		Initialization();

	}

	


	@Test(priority = 1, enabled = false, description = "Resignation by employee")
	public void resignation() throws Throwable {
		for(int i =(Integer.parseInt(TestUtils.readexcel(1, 1, lastrow, "Resign_By_Employee")));i<=(Integer.parseInt(TestUtils.readexcel(2, 1, lastrow, "Resign_By_Employee")));i++){
	
		String EmployeeNtUserID = TestUtils.readexcel(i, 0, lastrow, "Resign_By_Employee");
		String Password_Remarks = TestUtils.readexcel(i, 1, lastrow, "Resign_By_Employee");
		String Reason = TestUtils.readexcel(i, 2, lastrow, "Resign_By_Employee");
		String Subreason = TestUtils.readexcel(i, 3, lastrow, "Resign_By_Employee");
		String Mobile_Number = TestUtils.readexcel(i, 4, lastrow, "Resign_By_Employee");
		String Personal_Email_Address = TestUtils.readexcel(i, 5, lastrow, "Resign_By_Employee");
		String holding_amex_card = TestUtils.readexcel(i, 6, lastrow, "Resign_By_Employee");
		//String Amex_Card_Number = TestUtils.readexcel(i, 7, lastrow, "Resign_By_Employee");

		loginpage.dologin(EmployeeNtUserID, Password_Remarks);
		this.mousehoverclick("Resignation_Process", "Resignation_Form");
		this.scrollpagebottom();
		this.Dropdown("Reason", Reason);
		Thread.sleep(1000);
		this.Dropdown("Subreason", Subreason);
		Thread.sleep(1000);
		this.findelement("Landline_Number").clear();
		this.findelement("Mobile_Number").clear();
		this.SendData("Mobile_Number", Mobile_Number);
		Thread.sleep(1000);
		this.findelement("Personal_Email_Address").clear();
		this.SendData("Personal_Email_Address", Personal_Email_Address);
		Thread.sleep(1000);
		this.Dropdown("amex_card", holding_amex_card);
		Thread.sleep(1000);
		/*
		 * this.findelement("Amex_Card_Number").clear();
		 * this.SendData("Amex_Card_Number", Amex_Card_Number);
		 */
		this.Click("Employee_feedback");
		Thread.sleep(1000);
		this.Click("general");
		Thread.sleep(1000);
		this.SendData("primary_reason", Password_Remarks);
		this.Dropdown("satisfaction_levels", "1");
		this.Dropdown("N_Feedback", "a)Monthly");
		this.Dropdown("Supervisor_feedback", "a)Constructive and helpful");
		this.Dropdown("My_mobility_tool", "Yes");
		this.Dropdown("skill_set", "Yes");
		this.SendData("additional_responsibilities", "Yes");
		this.Dropdown("rate_your_know", "1");
		this.scrollpage();
		this.controlclick("1best_practices", "2best_practices");
		this.controlclick("1chane_capgemini", "2change_capgemini");
		this.Dropdown("Name2_trainings", "Yes");
		this.Dropdown("leadership_transparent", "Yes");
		this.Dropdown("performance_measured", "Yes");
		this.Dropdown("RnR_programs", "1");
		this.Dropdown("choice_in_Future", "Yes");
		this.Dropdown("career_progression", "Yes");
		this.Dropdown("impact_on_your_decision", "Yes");
		this.Dropdown("workplace_flexibility", "Yes");
		this.Dropdown("worklife_balance", "1");
		this.Click("compelling_factor");
		this.Click("future_employement");
		this.scrollpagebottom();
		Thread.sleep(1000);
		this.Dropdown("higher_grade", "Yes");
		this.Dropdown("different_Technology", "Yes");
		this.Dropdown("compensation_reason", "Yes");
		this.SendData("Organisation_joining", Password_Remarks);
		this.Click("Save_Button");
		Thread.sleep(1000);
		this.scrollpagebottom();
		Thread.sleep(1000);
		this.Click("submit_button");
		Thread.sleep(1000);
		this.Click("Agree_Button");
		this.Click("ok_button");
		Thread.sleep(1000);
		this.Click("logout");
	}
	}
	//resignation must be initiated
	@Test(priority = 2, enabled = false, description = "Approval by supervisor")
	public void Supervisor_Approval() throws Throwable {
		for(int i =(Integer.parseInt(TestUtils.readexcel(1, 1, lastrow, "Resign_By_Employee")));i<=(Integer.parseInt(TestUtils.readexcel(2, 1, lastrow, "Resign_By_Employee")));i++){
		String User_id = TestUtils.readexcel(i, 8, lastrow, "Resign_By_Employee");
		String Employee_name = TestUtils.readexcel(i, 9, lastrow, "Resign_By_Employee");
		String Password_Remarks = TestUtils.readexcel(i, 1, lastrow, "Resign_By_Employee");
		clearance.Supervisor_Approval(User_id, Password_Remarks, Employee_name);
		}
	}

	@Test(priority = 3, enabled = true, description = "Hrss confirmation")
	public void Hrss_Confirmation() throws Throwable {
		for(int i =(Integer.parseInt(TestUtils.readexcel(1, 1, lastrow, "Resign_By_Employee")));i<=(Integer.parseInt(TestUtils.readexcel(2, 1, lastrow, "Resign_By_Employee")));i++){
		String Clearance_Admin = TestUtils.readexcel(i, 10, lastrow, "Resign_By_Employee");
		String Password_Remarks = TestUtils.readexcel(i, 1, lastrow, "Resign_By_Employee");
		String User_id = TestUtils.readexcel(i, 8, lastrow, "Resign_By_Employee");
		String Employee_name = TestUtils.readexcel(i, 9, lastrow, "Resign_By_Employee");
		clearance.Hrss_Confirmation(Clearance_Admin, Password_Remarks, User_id, Employee_name);
	}
	}

	@Test(priority = 4, enabled = false, description = "Asset managment clearance")
	public void Asset_Managment_clearance() throws Throwable {
		for(int i =(Integer.parseInt(TestUtils.readexcel(1, 1, lastrow, "Resign_By_Employee")));i<=(Integer.parseInt(TestUtils.readexcel(2, 1, lastrow, "Resign_By_Employee")));i++){
		String Clearance_Admin = TestUtils.readexcel(i, 10, lastrow, "Resign_By_Employee");
		String Password_Remarks = TestUtils.readexcel(i, 1, lastrow, "Resign_By_Employee");
		String User_id = TestUtils.readexcel(i, 8, lastrow, "Resign_By_Employee");
		String Employee_name = TestUtils.readexcel(i, 9, lastrow, "Resign_By_Employee");
		clearance.Asset_Managment_clearance(Clearance_Admin, Password_Remarks, User_id, Employee_name);
	}
	}

	@Test(priority = 5, enabled = false, description = "EISDues clearance")
	public void EISDues_clearance() throws Throwable {
		for(int i =(Integer.parseInt(TestUtils.readexcel(1, 1, lastrow, "Resign_By_Employee")));i<=(Integer.parseInt(TestUtils.readexcel(2, 1, lastrow, "Resign_By_Employee")));i++){
		String Clearance_Admin = TestUtils.readexcel(i, 10, lastrow, "Resign_By_Employee");
		String Password_Remarks = TestUtils.readexcel(i, 1, lastrow, "Resign_By_Employee");
		String User_id = TestUtils.readexcel(i, 8, lastrow, "Resign_By_Employee");
		String Employee_name = TestUtils.readexcel(i, 9, lastrow, "Resign_By_Employee");
		clearance.EISDues_clearance(Clearance_Admin, Password_Remarks, User_id, Employee_name);
	}
	}

	@Test(priority = 6, enabled = false, description = "Supervisor clearance")
	public void Supervisor_clearance() throws Throwable {
		for(int i =(Integer.parseInt(TestUtils.readexcel(1, 1, lastrow, "Resign_By_Employee")));i<=(Integer.parseInt(TestUtils.readexcel(2, 1, lastrow, "Resign_By_Employee")));i++){

		String User_id = TestUtils.readexcel(i, 8, lastrow, "Resign_By_Employee");
		clearance.Supervisor_clearance(User_id);
	}
	}
	

	@Test(priority = 7, enabled = false, description = "Finance clearance")
	public void finance_clearance() throws Throwable {
		for(int i =(Integer.parseInt(TestUtils.readexcel(1, 1, lastrow, "Resign_By_Employee")));i<=(Integer.parseInt(TestUtils.readexcel(2, 1, lastrow, "Resign_By_Employee")));i++){

		String Clearance_Admin = TestUtils.readexcel(i, 10, lastrow, "Resign_By_Employee");
		String Password_Remarks = TestUtils.readexcel(i, 1, lastrow, "Resign_By_Employee");
		String User_id = TestUtils.readexcel(i, 8, lastrow, "Resign_By_Employee");
		String Employee_name = TestUtils.readexcel(i, 9, lastrow, "Resign_By_Employee");
		clearance.finance_clearance(Clearance_Admin, Password_Remarks, User_id, Employee_name);
	}
	}

	@Test(priority = 8, enabled = false, description = "ICRES clearance")
	public void Icres_clearance() throws Throwable {
		for(int i =(Integer.parseInt(TestUtils.readexcel(1, 1, lastrow, "Resign_By_Employee")));i<=(Integer.parseInt(TestUtils.readexcel(2, 1, lastrow, "Resign_By_Employee")));i++){

		String Clearance_Admin = TestUtils.readexcel(i, 10, lastrow, "Resign_By_Employee");
		String Password_Remarks = TestUtils.readexcel(i, 1, lastrow, "Resign_By_Employee");
		String User_id = TestUtils.readexcel(i, 8, lastrow, "Resign_By_Employee");
		String Employee_name = TestUtils.readexcel(i, 9, lastrow, "Resign_By_Employee");
		clearance.Icres_clearance(Clearance_Admin, Password_Remarks, User_id, Employee_name);
	}
	}

	@Test(priority = 9, enabled = false, description = "LEARNING & DEVELOPMENT CLEARANCE")
	public void LEARNING_DEVELOPMENT_CLEARANCE() throws Throwable {
		for(int i =(Integer.parseInt(TestUtils.readexcel(1, 1, lastrow, "Resign_By_Employee")));i<=(Integer.parseInt(TestUtils.readexcel(2, 1, lastrow, "Resign_By_Employee")));i++){

		String Clearance_Admin = TestUtils.readexcel(i, 10, lastrow, "Resign_By_Employee");
		String Password_Remarks = TestUtils.readexcel(i, 1, lastrow, "Resign_By_Employee");
		String User_id = TestUtils.readexcel(i, 8, lastrow, "Resign_By_Employee");
		String Employee_name = TestUtils.readexcel(i, 9, lastrow, "Resign_By_Employee");
		clearance.LEARNING_DEVELOPMENT_CLEARANCE(Clearance_Admin, Password_Remarks, User_id, Employee_name);
	}
	}

	@Test(priority = 10, enabled = false, description = "TIME HELPDESK CLEARANCE")
	public void TIME_HELPDESK_CLEARANCECLEARANCE() throws Throwable {
		for(int i =(Integer.parseInt(TestUtils.readexcel(1, 1, lastrow, "Resign_By_Employee")));i<=(Integer.parseInt(TestUtils.readexcel(2, 1, lastrow, "Resign_By_Employee")));i++){
		String Clearance_Admin = TestUtils.readexcel(i, 10, lastrow, "Resign_By_Employee");
		String Password_Remarks = TestUtils.readexcel(i, 1, lastrow, "Resign_By_Employee");
		String User_id = TestUtils.readexcel(i, 8, lastrow, "Resign_By_Employee");
		String Employee_name = TestUtils.readexcel(i, 9, lastrow, "Resign_By_Employee");
		clearance.TIME_HELPDESK_CLEARANCECLEARANCE(Clearance_Admin, Password_Remarks, User_id, Employee_name);
	}
	}

	@Test(priority = 11, enabled = false, description = " PEOPLE PROCESS/HR CLEARANCE")
	public void PEOPLE_PROCESS_CLEARANCE() throws Throwable {
		for(int i =(Integer.parseInt(TestUtils.readexcel(1, 1, lastrow, "Resign_By_Employee")));i<=(Integer.parseInt(TestUtils.readexcel(2, 1, lastrow, "Resign_By_Employee")));i++){
		String Clearance_Admin = TestUtils.readexcel(i, 10, lastrow, "Resign_By_Employee");
		String Password_Remarks = TestUtils.readexcel(i, 1, lastrow, "Resign_By_Employee");
		String User_id = TestUtils.readexcel(i, 8, lastrow, "Resign_By_Employee");
		String Employee_name = TestUtils.readexcel(i, 9, lastrow, "Resign_By_Employee");
		clearance.PEOPLE_PROCESS_CLEARANCE(Clearance_Admin, Password_Remarks, User_id, Employee_name);
		}
	}

	@Test(priority = 12, enabled = false, description = " Mobility CLEARANCE")
	public void Mobility_CLEARANCE() throws Throwable {
		for(int i =(Integer.parseInt(TestUtils.readexcel(1, 1, lastrow, "Resign_By_Employee")));i<=(Integer.parseInt(TestUtils.readexcel(2, 1, lastrow, "Resign_By_Employee")));i++){
		String Clearance_Admin = TestUtils.readexcel(i, 10, lastrow, "Resign_By_Employee");
		String Password_Remarks = TestUtils.readexcel(i, 1, lastrow, "Resign_By_Employee");
		String User_id = TestUtils.readexcel(i, 8, lastrow, "Resign_By_Employee");
		String Employee_name = TestUtils.readexcel(i, 9, lastrow, "Resign_By_Employee");
		clearance.Mobility_CLEARANCE(Clearance_Admin, Password_Remarks, User_id, Employee_name);
		}
	}
	@Test(priority = 13, enabled = true, description = "BuHr_Clearance")
	public void BuHr_Clearance() throws Throwable {
		for(int i =(Integer.parseInt(TestUtils.readexcel(1, 1, lastrow, "Resign_By_Employee")));i<=(Integer.parseInt(TestUtils.readexcel(2, 1, lastrow, "Resign_By_Employee")));i++){
		String User_id = TestUtils.readexcel(i, 8, lastrow, "Resign_By_Employee");
		String Password_Remarks = TestUtils.readexcel(i, 1, lastrow, "Resign_By_Employee");
		String Employee_name = TestUtils.readexcel(i, 9, lastrow, "Resign_By_Employee");
		clearance.BUHR_Clearance(User_id,Password_Remarks,Employee_name);
		}
		
	}
	
	@Test(priority = 14, enabled = true, description = "Final_Clearance")
	public void Final_Clearance() throws Throwable {
		for(int i =(Integer.parseInt(TestUtils.readexcel(1, 1, lastrow, "Resign_By_Employee")));i<=(Integer.parseInt(TestUtils.readexcel(2, 1, lastrow, "Resign_By_Employee")));i++){
		String User_id = TestUtils.readexcel(i, 8, lastrow, "Resign_By_Employee");
		String Password_Remarks = TestUtils.readexcel(i, 1, lastrow, "Resign_By_Employee");
		String Employee_name = TestUtils.readexcel(i, 9, lastrow, "Resign_By_Employee");
		String Clearance_Admin = TestUtils.readexcel(i, 10, lastrow, "Resign_By_Employee");
		clearance.Final_clearance(Clearance_Admin, Password_Remarks, User_id, Employee_name);
	}
	}
	
	@AfterTest
	public void closeBrowser() {
		// driver.quit();

	}
	}

