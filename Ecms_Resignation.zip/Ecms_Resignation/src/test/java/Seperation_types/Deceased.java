package Seperation_types;

import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import pages.All_Clearance;
import pages.LoginPage;
import Ecms_Base.TestBase;
import Ecms_Utility.TestUtils;
import Ecms_Utility.database_Connection;

public class Deceased extends TestBase {
	
	
	int lastrow = 1;
	LoginPage loginpage;
	database_Connection database;
	All_Clearance clearance;
	@BeforeTest
	public void browseropen(){
		
		loginpage = new LoginPage();
		database = new database_Connection();
		clearance = new All_Clearance();
		Initialization();
		
		
		
	}
	
	/*String AdminNtUserID = TestUtils.readexcel(i, 0, lastrow, "Deceased");
	String Password_Remarks = TestUtils.readexcel(i, 1, lastrow, "Deceased");
	String User_id = TestUtils.readexcel(i, 2, lastrow, "Deceased");
	String Seperation_type = TestUtils.readexcel(i, 3, lastrow, "Deceased");
	String Last_Working_date = TestUtils.readexcel(i, 4, lastrow, "Deceased");
	String Reason = TestUtils.readexcel(i, 5, lastrow, "Deceased");
	String SubReason = TestUtils.readexcel(i, 6, lastrow, "Deceased");
	String Address_for_Communication = TestUtils.readexcel(i, 7, lastrow, "Deceased");
	String Mobile_Number = TestUtils.readexcel(i, 8, lastrow, "Deceased");
	String Personal_Email_Address = TestUtils.readexcel(i, 9, lastrow, "Deceased");
	String holding_amex_card = TestUtils.readexcel(i, 10, lastrow, "Deceased");
	String Amex_Card_Number = TestUtils.readexcel(i, 11, lastrow, "Deceased");
	String Employee_name = TestUtils.readexcel(i, 12, lastrow, "Deceased");
	String Clearance_Admin = TestUtils.readexcel(i, 13, lastrow, "Deceased");
	*/
	
	int i;

	@Test(priority = 1, enabled = false, description = "Deceased by admin")
	public void Admin_Deceased() throws Throwable {
		for(int i =(Integer.parseInt(TestUtils.readexcel(1, 1, lastrow, "Deceased")));i<=(Integer.parseInt(TestUtils.readexcel(2, 1, lastrow, "Deceased")));i++){
		String AdminNtUserID = TestUtils.readexcel(i, 0, lastrow, "Deceased");
		String Password_Remarks = TestUtils.readexcel(i, 1, lastrow, "Deceased");
		String User_id = TestUtils.readexcel(i, 2, lastrow, "Deceased");
		String Seperation_type = TestUtils.readexcel(i, 3, lastrow, "Deceased");
		String Last_Working_date = TestUtils.readexcel(i, 4, lastrow, "Deceased");
		TestUtils.readexcel(i, 5, lastrow, "Deceased");
		String SubReason = TestUtils.readexcel(i, 6, lastrow, "Deceased");
		TestUtils.readexcel(i, 7, lastrow, "Deceased");
		String Mobile_Number = TestUtils.readexcel(i, 8, lastrow, "Deceased");
		String Personal_Email_Address = TestUtils.readexcel(i, 9, lastrow, "Deceased");
		loginpage.dologin(AdminNtUserID, Password_Remarks);
		this.mousehoverclick("admin", "initiate_Seperation");
		this.Employee_Dropdown_Select(User_id);
		this.Dropdown("Seperation_type", Seperation_type);
		this.Click("submit_button1");
		this.datepicker(Last_Working_date, "Resignation_date");
		Thread.sleep(1000);
		this.Dropdown("Reason", "Involuntary");
		Thread.sleep(1000);
		this.Dropdown("Subreason", SubReason);
		Thread.sleep(1000);
		this.findelement("landlinenumber").clear();
		this.findelement("Mobile_Number").clear();
		this.SendData("Mobile_Number", Mobile_Number);
		Thread.sleep(1000);
		this.findelement("Personal_Email_Address").clear();
		this.SendData("Personal_Email_Address", Personal_Email_Address);
		Thread.sleep(1000);
		this.file_Upload();
		Thread.sleep(1000);
		this.Click("initiate_button");
		this.alert();
		Thread.sleep(1000);
		this.Click("ok_button");
		Thread.sleep(1000);
		this.Click("logout");
		}
	}
	
	@Test(priority = 2, enabled = false, description = "Hrss confirmation")
	public void Hrss_Confirmation() throws Throwable {
		for(int i =(Integer.parseInt(TestUtils.readexcel(1, 1, lastrow, "Deceased")));i<=(Integer.parseInt(TestUtils.readexcel(2, 1, lastrow, "Deceased")));i++){
		String Clearance_Admin = TestUtils.readexcel(i, 13, lastrow, "Deceased");
		String Password_Remarks = TestUtils.readexcel(i, 1, lastrow, "Deceased");
		String User_id = TestUtils.readexcel(i, 2, lastrow, "Deceased");
		String Employee_name = TestUtils.readexcel(i, 12, lastrow, "Deceased");
		clearance.Hrss_Confirmation(Clearance_Admin, Password_Remarks, User_id, Employee_name);
	}
	}
	@Test(priority = 3, enabled = false, description = "Asset managment clearance")
	public void Asset_Managment_clearance() throws Throwable {
		for(int i =(Integer.parseInt(TestUtils.readexcel(1, 1, lastrow, "Deceased")));i<=(Integer.parseInt(TestUtils.readexcel(2, 1, lastrow, "Deceased")));i++){
		String Clearance_Admin = TestUtils.readexcel(i, 13, lastrow, "Deceased");
		String Password_Remarks = TestUtils.readexcel(i, 1, lastrow, "Deceased");
		String User_id = TestUtils.readexcel(i, 2, lastrow, "Deceased");
		String Employee_name = TestUtils.readexcel(i, 12, lastrow, "Deceased");
		clearance.Asset_Managment_clearance(Clearance_Admin, Password_Remarks, User_id, Employee_name);
	}
	}

	@Test(priority = 4, enabled = true, description = "EISDues clearance")
	public void EISDues_clearance() throws Throwable {
		for(int i =(Integer.parseInt(TestUtils.readexcel(1, 1, lastrow, "Deceased")));i<=(Integer.parseInt(TestUtils.readexcel(2, 1, lastrow, "Deceased")));i++){
		String Clearance_Admin = TestUtils.readexcel(i, 13, lastrow, "Deceased");
		String Password_Remarks = TestUtils.readexcel(i, 1, lastrow, "Deceased");
		String User_id = TestUtils.readexcel(i, 2, lastrow, "Deceased");
		String Employee_name = TestUtils.readexcel(i, 12, lastrow, "Deceased");
		clearance.EISDues_clearance(Clearance_Admin, Password_Remarks, User_id, Employee_name);
	}
	}

	@Test(priority = 5, enabled = false, description = "Supervisor clearance")
	public void Supervisor_clearance() throws Throwable {
		for(int i =(Integer.parseInt(TestUtils.readexcel(1, 1, lastrow, "Deceased")));i<=(Integer.parseInt(TestUtils.readexcel(2, 1, lastrow, "Deceased")));i++){

		String User_id = TestUtils.readexcel(i, 2, lastrow, "Deceased");
		clearance.Supervisor_clearance(User_id);
	}
	}

	@Test(priority = 6, enabled = true, description = "Finance clearance")
	public void finance_clearance() throws Throwable {
		for(int i =(Integer.parseInt(TestUtils.readexcel(1, 1, lastrow, "Deceased")));i<=(Integer.parseInt(TestUtils.readexcel(2, 1, lastrow, "Deceased")));i++){

		String Clearance_Admin = TestUtils.readexcel(i, 13, lastrow, "Deceased");
		String Password_Remarks = TestUtils.readexcel(i, 1, lastrow, "Deceased");
		String User_id = TestUtils.readexcel(i, 2, lastrow, "Deceased");
		String Employee_name = TestUtils.readexcel(i, 12, lastrow, "Deceased");
		clearance.finance_clearance(Clearance_Admin, Password_Remarks, User_id, Employee_name);
	}
	}

	@Test(priority = 7, enabled = false, description = "ICRES clearance")
	public void Icres_clearance() throws Throwable {
		for(int i =(Integer.parseInt(TestUtils.readexcel(1, 1, lastrow, "Deceased")));i<=(Integer.parseInt(TestUtils.readexcel(2, 1, lastrow, "Deceased")));i++){

		String Clearance_Admin = TestUtils.readexcel(i, 13, lastrow, "Deceased");
		String Password_Remarks = TestUtils.readexcel(i, 1, lastrow, "Deceased");
		String User_id = TestUtils.readexcel(i, 2, lastrow, "Deceased");
		String Employee_name = TestUtils.readexcel(i, 12, lastrow, "Deceased");
		clearance.Icres_clearance(Clearance_Admin, Password_Remarks, User_id, Employee_name);
	}
	}

	@Test(priority = 8, enabled = false, description = "LEARNING & DEVELOPMENT CLEARANCE")
	public void LEARNING_DEVELOPMENT_CLEARANCE() throws Throwable {
		for(int i =(Integer.parseInt(TestUtils.readexcel(1, 1, lastrow, "Deceased")));i<=(Integer.parseInt(TestUtils.readexcel(2, 1, lastrow, "Deceased")));i++){
		String Clearance_Admin = TestUtils.readexcel(i, 13, lastrow, "Deceased");
		String Password_Remarks = TestUtils.readexcel(i, 1, lastrow, "Deceased");
		String User_id = TestUtils.readexcel(i, 2, lastrow, "Deceased");
		String Employee_name = TestUtils.readexcel(i, 12, lastrow, "Deceased");
		clearance.LEARNING_DEVELOPMENT_CLEARANCE(Clearance_Admin, Password_Remarks, User_id, Employee_name);
	}
	}
	@Test(priority = 9, enabled = false, description = "TIME HELPDESK CLEARANCE")
	public void TIME_HELPDESK_CLEARANCECLEARANCE() throws Throwable {
		for(int i =(Integer.parseInt(TestUtils.readexcel(1, 1, lastrow, "Deceased")));i<=(Integer.parseInt(TestUtils.readexcel(2, 1, lastrow, "Deceased")));i++){
		String Clearance_Admin = TestUtils.readexcel(i, 13, lastrow, "Deceased");
		String Password_Remarks = TestUtils.readexcel(i, 1, lastrow, "Deceased");
		String User_id = TestUtils.readexcel(i, 2, lastrow, "Deceased");
		String Employee_name = TestUtils.readexcel(i, 12, lastrow, "Deceased");
		clearance.TIME_HELPDESK_CLEARANCECLEARANCE(Clearance_Admin, Password_Remarks, User_id, Employee_name);
	}
	}

	@Test(priority = 10, enabled = false, description = " PEOPLE PROCESS/HR CLEARANCE")
	public void PEOPLE_PROCESS_CLEARANCE() throws Throwable {
		for(int i =(Integer.parseInt(TestUtils.readexcel(1, 1, lastrow, "Deceased")));i<=(Integer.parseInt(TestUtils.readexcel(2, 1, lastrow, "Deceased")));i++){
		String Clearance_Admin = TestUtils.readexcel(i, 13, lastrow, "Deceased");
		String Password_Remarks = TestUtils.readexcel(i, 1, lastrow, "Deceased");
		String User_id = TestUtils.readexcel(i, 2, lastrow, "Deceased");
		String Employee_name = TestUtils.readexcel(i, 12, lastrow, "Deceased");
		clearance.PEOPLE_PROCESS_CLEARANCE(Clearance_Admin, Password_Remarks, User_id, Employee_name);

	}
	}

	@Test(priority = 11, enabled = false, description = " Mobility CLEARANCE")
	public void Mobility_CLEARANCE() throws Throwable {
		for(int i =(Integer.parseInt(TestUtils.readexcel(1, 1, lastrow, "Deceased")));i<=(Integer.parseInt(TestUtils.readexcel(2, 1, lastrow, "Deceased")));i++){
		String Clearance_Admin = TestUtils.readexcel(i, 13, lastrow, "Deceased");
		String Password_Remarks = TestUtils.readexcel(i, 1, lastrow, "Deceased");
		String User_id = TestUtils.readexcel(i, 2, lastrow, "Deceased");
		String Employee_name = TestUtils.readexcel(i, 12, lastrow, "Deceased");
		clearance.Mobility_CLEARANCE(Clearance_Admin, Password_Remarks, User_id, Employee_name);
		}
	}

	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	

}
