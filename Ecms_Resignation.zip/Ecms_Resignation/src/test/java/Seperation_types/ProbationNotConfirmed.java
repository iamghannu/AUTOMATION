package Seperation_types;

import java.io.IOException;

import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import pages.All_Clearance;
import pages.LoginPage;
import Ecms_Base.TestBase;
import Ecms_Utility.TestUtils;
import Ecms_Utility.database_Connection;

public class ProbationNotConfirmed extends TestBase {
	
	int lastrow = 1;
	LoginPage loginpage;
	database_Connection database;
	All_Clearance clearance;
	@BeforeTest
	public void browseropen(){
		
		loginpage = new LoginPage();
		database = new database_Connection();
		clearance = new All_Clearance();
		Initialization();
		
		
		
	}
	
	/*String AdminNtUserID = TestUtils.readexcel(i, 0, lastrow, "ProbationNotConfirmed");
	String Password_Remarks = TestUtils.readexcel(i, 1, lastrow, "ProbationNotConfirmed");
	String User_id = TestUtils.readexcel(i, 2, lastrow, "ProbationNotConfirmed");
	String Seperation_type = TestUtils.readexcel(i, 3, lastrow, "ProbationNotConfirmed");
	String Resignation_Date = TestUtils.readexcel(i, 4, lastrow, "ProbationNotConfirmed");
	String Last_Working_Date = TestUtils.readexcel(i, 5, lastrow, "ProbationNotConfirmed");
	String Reason = TestUtils.readexcel(i, 6, lastrow, "ProbationNotConfirmed");
	String SubReason = TestUtils.readexcel(i, 7, lastrow, "ProbationNotConfirmed");
	String Address_for_Communication = TestUtils.readexcel(i, 8, lastrow, "ProbationNotConfirmed");
	String Mobile_Number = TestUtils.readexcel(i, 9, lastrow, "ProbationNotConfirmed");
	String Personal_Email_Address = TestUtils.readexcel(i, 10, lastrow, "ProbationNotConfirmed");
	String holding_amex_card = TestUtils.readexcel(i, 11, lastrow, "ProbationNotConfirmed");
	String Amex_Card_Number = TestUtils.readexcel(i, 12, lastrow, "ProbationNotConfirmed");
	String Employee_name = TestUtils.readexcel(i, 13, lastrow, "ProbationNotConfirmed");
	String Clearance_Admin = TestUtils.readexcel(i, 14, lastrow, "ProbationNotConfirmed");
	*/
	
	 int i;
		
		
		@Test(priority = 1, enabled = false, description = "ProbationNotConfirmed by Admin")
		public void Admin_ProbationNotConfirmed() throws IOException, InterruptedException{
			for(int i =(Integer.parseInt(TestUtils.readexcel(1, 1, lastrow, "ProbationNotConfirmed")));i<=(Integer.parseInt(TestUtils.readexcel(2, 1, lastrow, "ProbationNotConfirmed")));i++){
			
			String AdminNtUserID = TestUtils.readexcel(i, 0, lastrow, "ProbationNotConfirmed");
			String Password_Remarks = TestUtils.readexcel(i, 1, lastrow, "ProbationNotConfirmed");
			String User_id = TestUtils.readexcel(i, 2, lastrow, "ProbationNotConfirmed");
			String Seperation_type = TestUtils.readexcel(i, 3, lastrow, "ProbationNotConfirmed");
			String Last_Working_date = TestUtils.readexcel(i, 4, lastrow, "ProbationNotConfirmed");
			TestUtils.readexcel(i, 5, lastrow, "ProbationNotConfirmed");
			String SubReason = TestUtils.readexcel(i, 6, lastrow, "ProbationNotConfirmed");
			TestUtils.readexcel(i, 7, lastrow, "ProbationNotConfirmed");
			String Mobile_Number = TestUtils.readexcel(i, 9, lastrow, "ProbationNotConfirmed");
			String Personal_Email_Address = TestUtils.readexcel(i, 10, lastrow, "ProbationNotConfirmed");
			loginpage.dologin(AdminNtUserID, Password_Remarks);
			this.mousehoverclick("admin", "initiate_Seperation");
			this.Employee_Dropdown_Select(User_id);
			this.Dropdown("Seperation_type", Seperation_type);
			this.Click("submit_button1");
			this.datepicker(Last_Working_date, "Resignation_date");
			Thread.sleep(1000);
			this.Dropdown("Reason", "Involuntary");
			Thread.sleep(1000);
			this.Dropdown("Subreason", "Non-confirmation");
			Thread.sleep(1000);
			this.findelement("landlinenumber").clear();
			this.findelement("Mobile_Number").clear();
			this.SendData("Mobile_Number", Mobile_Number);
			Thread.sleep(1000);
			this.findelement("Personal_Email_Address").clear();
			this.SendData("Personal_Email_Address", Personal_Email_Address);
			Thread.sleep(1000);
			this.file_Upload();
			Thread.sleep(1000);
			this.Click("initiate_button");
			this.alert();
			Thread.sleep(1000);
			this.Click("ok_button");
			Thread.sleep(1000);
			this.Click("logout");
			}
		}
		@Test(priority = 2, enabled = true, description = "Approval by supervisor")
		public void Supervisor_Approval() throws Throwable {
			for(int i =(Integer.parseInt(TestUtils.readexcel(1, 1, lastrow, "ProbationNotConfirmed")));i<=(Integer.parseInt(TestUtils.readexcel(2, 1, lastrow, "ProbationNotConfirmed")));i++){
			String User_id = TestUtils.readexcel(i, 2, lastrow, "ProbationNotConfirmed");
			String Employee_name = TestUtils.readexcel(i, 13, lastrow, "ProbationNotConfirmed");
			String Password_Remarks = TestUtils.readexcel(i, 1, lastrow, "ProbationNotConfirmed");
			database.testdb();
			String Text = database.Supervisor_Nt_UserId(User_id);
			System.out.println(Text);
			loginpage.dologin(Text, Password_Remarks);
			Thread.sleep(1000);
			this.mousehoverclick("Approval_Process", "supervisor_Approval");
			System.out.println(this.gettext("table"));
			this.Clickonlink_Selected("table", Employee_name);
			this.SendData("Message_to_HRSS_team", Password_Remarks);
			this.Dropdown("My_assessment_of_the_Employee", "Catalysts");
			this.SendData("According_to_me_the_reason_for_resignation_is", "Password_Remarks");
			this.Dropdown("Can_Breach_Agreement", "Yes");
			this.file_Upload();
			this.Click("initiate_button");
			Thread.sleep(1000);
			this.Click("ok");
			Thread.sleep(1000);
			this.Click("logout");

		}
		}

		@Test(priority = 3, enabled = true, description = "Hrss confirmation")
		public void Hrss_Confirmation() throws Throwable {
			for(int i =(Integer.parseInt(TestUtils.readexcel(1, 1, lastrow, "ProbationNotConfirmed")));i<=(Integer.parseInt(TestUtils.readexcel(2, 1, lastrow, "ProbationNotConfirmed")));i++){
			String Clearance_Admin = TestUtils.readexcel(i, 14, lastrow, "ProbationNotConfirmed");
			String Password_Remarks = TestUtils.readexcel(i, 1, lastrow, "ProbationNotConfirmed");
			String User_id = TestUtils.readexcel(i, 2, lastrow, "ProbationNotConfirmed");
			String Employee_name = TestUtils.readexcel(i, 13, lastrow, "ProbationNotConfirmed");
			clearance.Hrss_Confirmation(Clearance_Admin, Password_Remarks, User_id, Employee_name);
		}
		}
			
		@Test(priority = 4, enabled = true, description = "Asset managment clearance")
		public void Asset_Managment_clearance() throws Throwable {
			for(int i =(Integer.parseInt(TestUtils.readexcel(1, 1, lastrow, "ProbationNotConfirmed")));i<=(Integer.parseInt(TestUtils.readexcel(2, 1, lastrow, "ProbationNotConfirmed")));i++){
			String Clearance_Admin = TestUtils.readexcel(i, 14, lastrow, "ProbationNotConfirmed");
			String Password_Remarks = TestUtils.readexcel(i, 1, lastrow, "ProbationNotConfirmed");
			String User_id = TestUtils.readexcel(i, 2, lastrow, "ProbationNotConfirmed");
			String Employee_name = TestUtils.readexcel(i, 13, lastrow, "ProbationNotConfirmed");
			clearance.Asset_Managment_clearance(Clearance_Admin, Password_Remarks, User_id, Employee_name);
		}
		}

		@Test(priority = 5, enabled = true, description = "EISDues clearance")
		public void EISDues_clearance() throws Throwable {
			for(int i =(Integer.parseInt(TestUtils.readexcel(1, 1, lastrow, "ProbationNotConfirmed")));i<=(Integer.parseInt(TestUtils.readexcel(2, 1, lastrow, "ProbationNotConfirmed")));i++){
			String Clearance_Admin = TestUtils.readexcel(i, 14, lastrow, "ProbationNotConfirmed");
			String Password_Remarks = TestUtils.readexcel(i, 1, lastrow, "ProbationNotConfirmed");
			String User_id = TestUtils.readexcel(i, 2, lastrow, "ProbationNotConfirmed");
			String Employee_name = TestUtils.readexcel(i, 13, lastrow, "ProbationNotConfirmed");
			clearance.EISDues_clearance(Clearance_Admin, Password_Remarks, User_id, Employee_name);
		}
		}

		@Test(priority = 6, enabled = true, description = "Supervisor clearance")
		public void Supervisor_clearance() throws Throwable {
			for(int i =(Integer.parseInt(TestUtils.readexcel(1, 1, lastrow, "ProbationNotConfirmed")));i<=(Integer.parseInt(TestUtils.readexcel(2, 1, lastrow, "ProbationNotConfirmed")));i++){

			String User_id = TestUtils.readexcel(i, 2, lastrow, "ProbationNotConfirmed");
			clearance.Supervisor_clearance(User_id);
		}
		}

		@Test(priority = 6, enabled = true, description = "Finance clearance")
		public void finance_clearance() throws Throwable {
			for(int i =(Integer.parseInt(TestUtils.readexcel(1, 1, lastrow, "ProbationNotConfirmed")));i<=(Integer.parseInt(TestUtils.readexcel(2, 1, lastrow, "ProbationNotConfirmed")));i++){

			String Clearance_Admin = TestUtils.readexcel(i, 14, lastrow, "ProbationNotConfirmed");
			String Password_Remarks = TestUtils.readexcel(i, 1, lastrow, "ProbationNotConfirmed");
			String User_id = TestUtils.readexcel(i, 2, lastrow, "ProbationNotConfirmed");
			String Employee_name = TestUtils.readexcel(i, 13, lastrow, "ProbationNotConfirmed");
			clearance.finance_clearance(Clearance_Admin, Password_Remarks, User_id, Employee_name);
		}
		}

		@Test(priority = 7, enabled = true, description = "ICRES clearance")
		public void Icres_clearance() throws Throwable {
			for(int i =(Integer.parseInt(TestUtils.readexcel(1, 1, lastrow, "ProbationNotConfirmed")));i<=(Integer.parseInt(TestUtils.readexcel(2, 1, lastrow, "ProbationNotConfirmed")));i++){
			String Clearance_Admin = TestUtils.readexcel(i, 14, lastrow, "ProbationNotConfirmed");
			String Password_Remarks = TestUtils.readexcel(i, 1, lastrow, "ProbationNotConfirmed");
			String User_id = TestUtils.readexcel(i, 2, lastrow, "ProbationNotConfirmed");
			String Employee_name = TestUtils.readexcel(i, 13, lastrow, "ProbationNotConfirmed");
			clearance.Icres_clearance(Clearance_Admin, Password_Remarks, User_id, Employee_name);
		}
		}
		@Test(priority = 8, enabled = true, description = "LEARNING & DEVELOPMENT CLEARANCE")
		public void LEARNING_DEVELOPMENT_CLEARANCE() throws Throwable {
			for(int i =(Integer.parseInt(TestUtils.readexcel(1, 1, lastrow, "ProbationNotConfirmed")));i<=(Integer.parseInt(TestUtils.readexcel(2, 1, lastrow, "ProbationNotConfirmed")));i++){
			String Clearance_Admin = TestUtils.readexcel(i, 14, lastrow, "ProbationNotConfirmed");
			String Password_Remarks = TestUtils.readexcel(i, 1, lastrow, "ProbationNotConfirmed");
			String User_id = TestUtils.readexcel(i, 2, lastrow, "ProbationNotConfirmed");
			String Employee_name = TestUtils.readexcel(i, 13, lastrow, "ProbationNotConfirmed");
			clearance.LEARNING_DEVELOPMENT_CLEARANCE(Clearance_Admin, Password_Remarks, User_id, Employee_name);
		}
		}

		@Test(priority = 9, enabled = true, description = "TIME HELPDESK CLEARANCE")
		public void TIME_HELPDESK_CLEARANCECLEARANCE() throws Throwable {
			for(int i =(Integer.parseInt(TestUtils.readexcel(1, 1, lastrow, "ProbationNotConfirmed")));i<=(Integer.parseInt(TestUtils.readexcel(2, 1, lastrow, "ProbationNotConfirmed")));i++){
			String Clearance_Admin = TestUtils.readexcel(i, 14, lastrow, "ProbationNotConfirmed");
			String Password_Remarks = TestUtils.readexcel(i, 1, lastrow, "ProbationNotConfirmed");
			String User_id = TestUtils.readexcel(i, 2, lastrow, "ProbationNotConfirmed");
			String Employee_name = TestUtils.readexcel(i, 13, lastrow, "ProbationNotConfirmed");
			clearance.TIME_HELPDESK_CLEARANCECLEARANCE(Clearance_Admin, Password_Remarks, User_id, Employee_name);
		}
		}
		@Test(priority = 10, enabled = true, description = " PEOPLE PROCESS/HR CLEARANCE")
		public void PEOPLE_PROCESS_CLEARANCE() throws Throwable {
			for(int i =(Integer.parseInt(TestUtils.readexcel(1, 1, lastrow, "ProbationNotConfirmed")));i<=(Integer.parseInt(TestUtils.readexcel(2, 1, lastrow, "ProbationNotConfirmed")));i++){
			String Clearance_Admin = TestUtils.readexcel(i, 14, lastrow, "ProbationNotConfirmed");
			String Password_Remarks = TestUtils.readexcel(i, 1, lastrow, "ProbationNotConfirmed");
			String User_id = TestUtils.readexcel(i, 2, lastrow, "ProbationNotConfirmed");
			String Employee_name = TestUtils.readexcel(i, 13, lastrow, "ProbationNotConfirmed");
			clearance.PEOPLE_PROCESS_CLEARANCE(Clearance_Admin, Password_Remarks, User_id, Employee_name);
			}
		}

		@Test(priority = 11, enabled = true, description = " Mobility CLEARANCE")
		public void Mobility_CLEARANCE() throws Throwable {
			for(int i =(Integer.parseInt(TestUtils.readexcel(1, 1, lastrow, "ProbationNotConfirmed")));i<=(Integer.parseInt(TestUtils.readexcel(2, 1, lastrow, "ProbationNotConfirmed")));i++){
			String Clearance_Admin = TestUtils.readexcel(i, 14, lastrow, "ProbationNotConfirmed");
			String Password_Remarks = TestUtils.readexcel(i, 1, lastrow, "ProbationNotConfirmed");
			String User_id = TestUtils.readexcel(i, 2, lastrow, "ProbationNotConfirmed");
			String Employee_name = TestUtils.readexcel(i, 13, lastrow, "ProbationNotConfirmed");
			clearance.Mobility_CLEARANCE(Clearance_Admin, Password_Remarks, User_id, Employee_name);
	
			}
		}

}
