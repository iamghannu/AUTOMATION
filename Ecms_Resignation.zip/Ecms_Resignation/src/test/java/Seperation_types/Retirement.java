package Seperation_types;

import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import pages.All_Clearance;
import pages.LoginPage;
import Ecms_Base.TestBase;
import Ecms_Utility.TestUtils;
import Ecms_Utility.database_Connection;

public class Retirement extends TestBase {

	int lastrow = 1;
	LoginPage loginpage;
	database_Connection database;
	All_Clearance clearance;
	@BeforeTest
	public void browseropen(){
		
		loginpage = new LoginPage();
		database = new database_Connection();
		clearance = new All_Clearance();
		Initialization();
		
		
		
	}
	
	/*String AdminNtUserID = TestUtils.readexcel(i, 0, lastrow, "Retirement");
	String Password_Remarks = TestUtils.readexcel(i, 1, lastrow, "Retirement");
	String User_id = TestUtils.readexcel(i, 2, lastrow, "Retirement");
	String Seperation_type = TestUtils.readexcel(i, 3, lastrow, "Retirement");
	String Retirement_Date = TestUtils.readexcel(i, 4, lastrow, "Retirement");
	String Last_Working_Date = TestUtils.readexcel(i, 5, lastrow, "Retirement");
	String Reason = TestUtils.readexcel(i, 6, lastrow, "Retirement");
	String SubReason = TestUtils.readexcel(i, 7, lastrow, "Retirement");
	String Address_for_Communication = TestUtils.readexcel(i, 8, lastrow, "Retirement");
	String Mobile_Number = TestUtils.readexcel(i, 9, lastrow, "Retirement");
	String Personal_Email_Address = TestUtils.readexcel(i, 10, lastrow, "Retirement");
	String holding_amex_card = TestUtils.readexcel(i, 11, lastrow, "Retirement");
	String Amex_Card_Number = TestUtils.readexcel(i, 12, lastrow, "Retirement");
	String Employee_name = TestUtils.readexcel(i, 13, lastrow, "Retirement");
	String Clearance_Admin = TestUtils.readexcel(i, 14, lastrow, "Retirement");
	*/
	
	int i ;

	@Test(priority = 1, enabled = true, description = "Retirement by admin")
	public void Admin_Retirement() throws Throwable {
		for(int i =(Integer.parseInt(TestUtils.readexcel(1, 1, lastrow, "Retirement")));i<=(Integer.parseInt(TestUtils.readexcel(2, 1, lastrow, "Retirement")));i++){
		String AdminNtUserID = TestUtils.readexcel(i, 0, lastrow, "Retirement");
		String Password_Remarks = TestUtils.readexcel(i, 1, lastrow, "Retirement");
		String User_id = TestUtils.readexcel(i, 2, lastrow, "Retirement");
		String Seperation_type = TestUtils.readexcel(i, 3, lastrow, "Retirement");
		String Last_Working_date = TestUtils.readexcel(i, 4, lastrow, "Retirement");
		TestUtils.readexcel(i, 5, lastrow, "Retirement");
		String SubReason = TestUtils.readexcel(i, 6, lastrow, "Retirement");
		TestUtils.readexcel(i, 7, lastrow, "Retirement");
		String Mobile_Number = TestUtils.readexcel(i, 9, lastrow, "Retirement");
		String Personal_Email_Address = TestUtils.readexcel(i, 10, lastrow, "Retirement");
		loginpage.dologin(AdminNtUserID, Password_Remarks);
		this.mousehoverclick("admin", "initiate_Seperation");
		this.Employee_Dropdown_Select(User_id);
		this.Dropdown("Seperation_type", Seperation_type);
		this.Click("submit_button1");
		this.datepicker(Last_Working_date, "Resignation_date");
		Thread.sleep(1000);
		this.Dropdown("Reason", "Retirement");
		Thread.sleep(1000);
		this.Dropdown("Subreason", "Retirement");
		Thread.sleep(1000);
		this.findelement("landlinenumber").clear();
		this.findelement("Mobile_Number").clear();
		this.SendData("Mobile_Number", Mobile_Number);
		Thread.sleep(1000);
		this.findelement("Personal_Email_Address").clear();
		this.SendData("Personal_Email_Address", Personal_Email_Address);
		Thread.sleep(1000);
		this.file_Upload();
		Thread.sleep(1000);
		this.Click("initiate_button");
		this.alert();
		Thread.sleep(1000);
		this.Click("ok_button");
		Thread.sleep(1000);
		this.Click("logout");
		}
	}
	
	@Test(priority = 2, enabled = true, description = "Approval by supervisor")
	public void Supervisor_Approval() throws Throwable {
		for(int i =(Integer.parseInt(TestUtils.readexcel(1, 1, lastrow, "Retirement")));i<=(Integer.parseInt(TestUtils.readexcel(2, 1, lastrow, "Retirement")));i++){
		String User_id = TestUtils.readexcel(i, 2, lastrow, "Retirement");
		String Employee_name = TestUtils.readexcel(i, 13, lastrow, "Retirement");
		String Password_Remarks = TestUtils.readexcel(i, 1, lastrow, "Retirement");
		
		clearance.Supervisor_Approval(User_id, Password_Remarks, Employee_name);
		}
	}
	
	@Test(priority = 3, enabled = true, description = "Hrss confirmation")
	public void Hrss_Confirmation() throws Throwable {
		for(int i =(Integer.parseInt(TestUtils.readexcel(1, 1, lastrow, "Retirement")));i<=(Integer.parseInt(TestUtils.readexcel(2, 1, lastrow, "Retirement")));i++){
		String Clearance_Admin = TestUtils.readexcel(i, 14, lastrow, "Retirement");
		String User_id = TestUtils.readexcel(i, 2, lastrow, "Retirement");
		String Employee_name = TestUtils.readexcel(i, 13, lastrow, "Retirement");
		String Password_Remarks = TestUtils.readexcel(i, 1, lastrow, "Retirement");
		clearance.Hrss_Confirmation(Clearance_Admin, Password_Remarks, User_id, Employee_name);
		}
	}
	
	
	@Test(priority = 4, enabled = true, description = "Asset managment clearance")
	public void Asset_Managment_clearance() throws Throwable {
		for(int i =(Integer.parseInt(TestUtils.readexcel(1, 1, lastrow, "Retirement")));i<=(Integer.parseInt(TestUtils.readexcel(2, 1, lastrow, "Retirement")));i++){
		String Clearance_Admin = TestUtils.readexcel(i, 14, lastrow, "Retirement");
		String User_id = TestUtils.readexcel(i, 2, lastrow, "Retirement");
		String Employee_name = TestUtils.readexcel(i, 13, lastrow, "Retirement");
		String Password_Remarks = TestUtils.readexcel(i, 1, lastrow, "Retirement");
		clearance.Asset_Managment_clearance(Clearance_Admin, Password_Remarks, User_id, Employee_name);
	
		}
	
	}
	@Test(priority = 5, enabled = true, description = "EISDues clearance")
	public void EISDues_clearance() throws Throwable {
		for(int i =(Integer.parseInt(TestUtils.readexcel(1, 1, lastrow, "Retirement")));i<=(Integer.parseInt(TestUtils.readexcel(2, 1, lastrow, "Retirement")));i++){
		String Clearance_Admin = TestUtils.readexcel(i, 14, lastrow, "Retirement");
		String User_id = TestUtils.readexcel(i, 2, lastrow, "Retirement");
		String Employee_name = TestUtils.readexcel(i, 13, lastrow, "Retirement");
		String Password_Remarks = TestUtils.readexcel(i, 1, lastrow, "Retirement");
		clearance.EISDues_clearance(Clearance_Admin, Password_Remarks, User_id, Employee_name);
	}
	}
	
	@Test(priority = 6, enabled = true, description = "Supervisor clearance")
	public void Supervisor_clearance() throws Throwable {
		for(int i =(Integer.parseInt(TestUtils.readexcel(1, 1, lastrow, "Retirement")));i<=(Integer.parseInt(TestUtils.readexcel(2, 1, lastrow, "Retirement")));i++){
		String User_id = TestUtils.readexcel(i, 2, lastrow, "Retirement");
		clearance.Supervisor_clearance(User_id);
	}
	}
	
	@Test(priority = 7, enabled = true, description = "Finance clearance")
	public void finance_clearance() throws Throwable {
		for(int i =(Integer.parseInt(TestUtils.readexcel(1, 1, lastrow, "Retirement")));i<=(Integer.parseInt(TestUtils.readexcel(2, 1, lastrow, "Retirement")));i++){

		String Clearance_Admin = TestUtils.readexcel(i, 14, lastrow, "Retirement");
		String User_id = TestUtils.readexcel(i, 2, lastrow, "Retirement");
		String Employee_name = TestUtils.readexcel(i, 13, lastrow, "Retirement");
		String Password_Remarks = TestUtils.readexcel(i, 1, lastrow, "Retirement");
		clearance.finance_clearance(Clearance_Admin, Password_Remarks, User_id, Employee_name);
	}
	}
	@Test(priority = 8, enabled = true, description = "ICRES clearance")
	public void Icres_clearance() throws Throwable {
		for(int i =(Integer.parseInt(TestUtils.readexcel(1, 1, lastrow, "Retirement")));i<=(Integer.parseInt(TestUtils.readexcel(2, 1, lastrow, "Retirement")));i++){
		String Clearance_Admin = TestUtils.readexcel(i, 14, lastrow, "Retirement");
		String User_id = TestUtils.readexcel(i, 2, lastrow, "Retirement");
		String Employee_name = TestUtils.readexcel(i, 13, lastrow, "Retirement");
		String Password_Remarks = TestUtils.readexcel(i, 1, lastrow, "Retirement");
		clearance.Icres_clearance(Clearance_Admin, Password_Remarks, User_id, Employee_name);
	}
	}
	
	@Test(priority = 9, enabled = true, description = "LEARNING & DEVELOPMENT CLEARANCE")
	public void LEARNING_DEVELOPMENT_CLEARANCE() throws Throwable {
		for(int i =(Integer.parseInt(TestUtils.readexcel(1, 1, lastrow, "Retirement")));i<=(Integer.parseInt(TestUtils.readexcel(2, 1, lastrow, "Retirement")));i++){
		String Clearance_Admin = TestUtils.readexcel(i, 14, lastrow, "Retirement");
		String User_id = TestUtils.readexcel(i, 2, lastrow, "Retirement");
		String Employee_name = TestUtils.readexcel(i, 13, lastrow, "Retirement");
		String Password_Remarks = TestUtils.readexcel(i, 1, lastrow, "Retirement");
		clearance.LEARNING_DEVELOPMENT_CLEARANCE(Clearance_Admin, Password_Remarks, User_id, Employee_name);
	}
	}
	
	@Test(priority = 10, enabled = false, description = "TIME HELPDESK CLEARANCE")
	public void TIME_HELPDESK_CLEARANCECLEARANCE() throws Throwable {
		for(int i =(Integer.parseInt(TestUtils.readexcel(1, 1, lastrow, "Retirement")));i<=(Integer.parseInt(TestUtils.readexcel(2, 1, lastrow, "Retirement")));i++){
		String Clearance_Admin = TestUtils.readexcel(i, 14, lastrow, "Retirement");
		String User_id = TestUtils.readexcel(i, 2, lastrow, "Retirement");
		String Employee_name = TestUtils.readexcel(i, 13, lastrow, "Retirement");
		String Password_Remarks = TestUtils.readexcel(i, 1, lastrow, "Retirement");
		clearance.TIME_HELPDESK_CLEARANCECLEARANCE(Clearance_Admin, Password_Remarks, User_id, Employee_name);
	}
	}
	
	@Test(priority = 11, enabled = true, description = " PEOPLE PROCESS/HR CLEARANCE")
	public void PEOPLE_PROCESS_CLEARANCE() throws Throwable {
		for(int i =(Integer.parseInt(TestUtils.readexcel(1, 1, lastrow, "Retirement")));i<=(Integer.parseInt(TestUtils.readexcel(2, 1, lastrow, "Retirement")));i++){
		String Clearance_Admin = TestUtils.readexcel(i, 14, lastrow, "Retirement");
		String User_id = TestUtils.readexcel(i, 2, lastrow, "Retirement");
		String Employee_name = TestUtils.readexcel(i, 13, lastrow, "Retirement");
		String Password_Remarks = TestUtils.readexcel(i, 1, lastrow, "Retirement");
		clearance.PEOPLE_PROCESS_CLEARANCE(Clearance_Admin, Password_Remarks, User_id, Employee_name);
		}
	}

	@Test(priority = 12, enabled = true, description = " Mobility CLEARANCE")
	public void Mobility_CLEARANCE() throws Throwable {
		for(int i =(Integer.parseInt(TestUtils.readexcel(1, 1, lastrow, "Retirement")));i<=(Integer.parseInt(TestUtils.readexcel(2, 1, lastrow, "Retirement")));i++){
		String Clearance_Admin = TestUtils.readexcel(i, 14, lastrow, "Retirement");
		String User_id = TestUtils.readexcel(i, 2, lastrow, "Retirement");
		String Employee_name = TestUtils.readexcel(i, 13, lastrow, "Retirement");
		String Password_Remarks = TestUtils.readexcel(i, 1, lastrow, "Retirement");
		clearance.Mobility_CLEARANCE(Clearance_Admin, Password_Remarks, User_id, Employee_name);
		}
	}

	
}
