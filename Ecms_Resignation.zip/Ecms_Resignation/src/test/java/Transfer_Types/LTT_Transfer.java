package Transfer_Types;

import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import pages.All_Clearance;
import pages.LoginPage;
import Ecms_Base.TestBase;
import Ecms_Utility.TestUtils;
import Ecms_Utility.database_Connection;

public class LTT_Transfer extends TestBase {

	int lastrow = 1;
	LoginPage loginpage;
	database_Connection database;
	All_Clearance clearance;

	@BeforeTest
	public void browseropen() {

		loginpage = new LoginPage();
		database = new database_Connection();
		clearance = new All_Clearance();
		Initialization();

	}

	int i;
	
	/*String AdminNtUserID = TestUtils.readexcel(i, 0, lastrow, "LTT");
	String Password_Remarks = TestUtils.readexcel(i, 1, lastrow, "LTT");
	String User_id = TestUtils.readexcel(i, 2, lastrow, "LTT");
	String Transfer_type = TestUtils.readexcel(i, 3, lastrow, "LTT");
	String Last_Working_date = TestUtils.readexcel(i, 4, lastrow, "LTT");
	String Reason = TestUtils.readexcel(i, 5, lastrow, "LTT");
	String SubReason = TestUtils.readexcel(i, 6, lastrow, "LTT");
	String Address_for_Communication = TestUtils.readexcel(i, 7, lastrow, "LTT");
	String Mobile_Number = TestUtils.readexcel(i, 8, lastrow, "LTT");
	String Personal_Email_Address = TestUtils.readexcel(i, 9, lastrow, "LTT");
	String holding_amex_card = TestUtils.readexcel(i, 10, lastrow, "LTT");
	String Amex_Card_Number = TestUtils.readexcel(i, 11, lastrow, "LTT");
	String Employee_name = TestUtils.readexcel(i, 12, lastrow, "LTT");
	String Clearance_Admin = TestUtils.readexcel(i, 13, lastrow, "LTT");
	String Transfer_location = TestUtils.readexcel(i, 14, lastrow, "LTT");
	*/

	@Test(priority = 1, enabled = true, description = "Ltt initiated by admin")
	public void Ltt_Transfer() throws Throwable {
		for(int i =(Integer.parseInt(TestUtils.readexcel(1, 1, lastrow, "LTT")));i<=(Integer.parseInt(TestUtils.readexcel(2, 1, lastrow, "LTT")));i++){
		String AdminNtUserID = TestUtils.readexcel(i, 0, lastrow, "LTT");
		String Password_Remarks = TestUtils.readexcel(i, 1, lastrow, "LTT");
		String User_id = TestUtils.readexcel(i, 2, lastrow, "LTT");
		String Transfer_type = TestUtils.readexcel(i, 3, lastrow, "LTT");
		String Reason = TestUtils.readexcel(i, 5, lastrow, "LTT");
		String Last_Working_date = TestUtils.readexcel(i, 4, lastrow, "LTT");
		String SubReason = TestUtils.readexcel(i, 6, lastrow, "LTT");
		String Mobile_Number = TestUtils.readexcel(i, 8, lastrow, "LTT");
		String Personal_Email_Address = TestUtils.readexcel(i, 9, lastrow, "LTT");
		String Transfer_location = TestUtils.readexcel(i, 14, lastrow, "LTT");
		loginpage.dologin(AdminNtUserID, Password_Remarks);
		this.mousehoverclick("admin", "initiate_transfer");
		this.Employee_Dropdown_Select(User_id);
		this.Dropdown("transfer_type", Transfer_type);
		this.Click("submit_button1");
		Thread.sleep(1000);
		this.datepicker(Last_Working_date, "LastWorkin_Day");
		Thread.sleep(1000);
		this.Dropdown("Reason", Reason);
		Thread.sleep(1000);
		this.Dropdown("Subreason", SubReason);
		Thread.sleep(1000);
		this.findelement("landlinenumber").clear();
		this.findelement("Mobile_Number").clear();
		this.SendData("Mobile_Number", Mobile_Number);
		Thread.sleep(1000);
		this.findelement("Personal_Email_Address").clear();
		this.SendData("Personal_Email_Address", Personal_Email_Address);
		this.Dropdown("Location", Transfer_location);
		Thread.sleep(1000);
		this.file_Upload();
		Thread.sleep(1000);
		this.Click("initiate_button");
		this.alert();
		Thread.sleep(1000);
		this.Click("ok_Ltt");
		Thread.sleep(1000);
		this.Click("logout");
		}
	}
	@Test(priority = 2, enabled = true, description = "Hrss confirmation")
	public void Hrss_Confirmation() throws Throwable {
		for(int i =(Integer.parseInt(TestUtils.readexcel(1, 1, lastrow, "LTT")));i<=(Integer.parseInt(TestUtils.readexcel(2, 1, lastrow, "LTT")));i++){
		String Clearance_Admin = TestUtils.readexcel(i, 13, lastrow, "LTT");
		String Password_Remarks = TestUtils.readexcel(i, 1, lastrow, "LTT");
		String User_id = TestUtils.readexcel(i, 2, lastrow, "LTT");
		String Employee_name = TestUtils.readexcel(i, 12, lastrow, "LTT");
		clearance.Hrss_Confirmation(Clearance_Admin, Password_Remarks, User_id, Employee_name);
	}
	}
	@Test(priority = 3, enabled = true, description = "Asset managment clearance")
	public void Asset_Managment_clearance() throws Throwable {
		for(int i =(Integer.parseInt(TestUtils.readexcel(1, 1, lastrow, "LTT")));i<=(Integer.parseInt(TestUtils.readexcel(2, 1, lastrow, "LTT")));i++){
		String Clearance_Admin = TestUtils.readexcel(i, 13, lastrow, "LTT");
		String Password_Remarks = TestUtils.readexcel(i, 1, lastrow, "LTT");
		String User_id = TestUtils.readexcel(i, 2, lastrow, "LTT");
		String Employee_name = TestUtils.readexcel(i, 12, lastrow, "LTT");
		clearance.Asset_Managment_clearance(Clearance_Admin, Password_Remarks, User_id, Employee_name);
	}
	}

	@Test(priority = 4, enabled = true, description = "EISDues clearance")
	public void EISDues_clearance() throws Throwable {
		for(int i =(Integer.parseInt(TestUtils.readexcel(1, 1, lastrow, "LTT")));i<=(Integer.parseInt(TestUtils.readexcel(2, 1, lastrow, "LTT")));i++){
		String Clearance_Admin = TestUtils.readexcel(i, 13, lastrow, "LTT");
		String Password_Remarks = TestUtils.readexcel(i, 1, lastrow, "LTT");
		String User_id = TestUtils.readexcel(i, 2, lastrow, "LTT");
		String Employee_name = TestUtils.readexcel(i, 12, lastrow, "LTT");
		clearance.EISDues_clearance(Clearance_Admin, Password_Remarks, User_id, Employee_name);
	}
	}

	@Test(priority = 5, enabled = true, description = "Supervisor clearance")
	public void Supervisor_clearance() throws Throwable {
		for(int i =(Integer.parseInt(TestUtils.readexcel(1, 1, lastrow, "LTT")));i<=(Integer.parseInt(TestUtils.readexcel(2, 1, lastrow, "LTT")));i++){
		String User_id = TestUtils.readexcel(i, 2, lastrow, "LTT");
		clearance.Supervisor_clearance(User_id);
	}
	}
	@Test(priority = 6, enabled = true, description = "Finance clearance")
	public void finance_clearance() throws Throwable {
		for(int i =(Integer.parseInt(TestUtils.readexcel(1, 1, lastrow, "LTT")));i<=(Integer.parseInt(TestUtils.readexcel(2, 1, lastrow, "LTT")));i++){
		String Clearance_Admin = TestUtils.readexcel(i, 13, lastrow, "LTT");
		String Password_Remarks = TestUtils.readexcel(i, 1, lastrow, "LTT");
		String User_id = TestUtils.readexcel(i, 2, lastrow, "LTT");
		String Employee_name = TestUtils.readexcel(i, 12, lastrow, "LTT");
		clearance.finance_clearance(Clearance_Admin, Password_Remarks, User_id, Employee_name);
	}
	}
	@Test(priority = 7, enabled = true, description = "ICRES clearance")
	public void Icres_clearance() throws Throwable {
		for(int i =(Integer.parseInt(TestUtils.readexcel(1, 1, lastrow, "LTT")));i<=(Integer.parseInt(TestUtils.readexcel(2, 1, lastrow, "LTT")));i++){
		String Clearance_Admin = TestUtils.readexcel(i, 13, lastrow, "LTT");
		String Password_Remarks = TestUtils.readexcel(i, 1, lastrow, "LTT");
		String User_id = TestUtils.readexcel(i, 2, lastrow, "LTT");
		String Employee_name = TestUtils.readexcel(i, 12, lastrow, "LTT");
		clearance.Icres_clearance(Clearance_Admin, Password_Remarks, User_id, Employee_name);
	}
	}
	@Test(priority = 8, enabled = true, description = "LEARNING & DEVELOPMENT CLEARANCE")
	public void LEARNING_DEVELOPMENT_CLEARANCE() throws Throwable {
		for(int i =(Integer.parseInt(TestUtils.readexcel(1, 1, lastrow, "LTT")));i<=(Integer.parseInt(TestUtils.readexcel(2, 1, lastrow, "LTT")));i++){
		String Clearance_Admin = TestUtils.readexcel(i, 13, lastrow, "LTT");
		String Password_Remarks = TestUtils.readexcel(i, 1, lastrow, "LTT");
		String User_id = TestUtils.readexcel(i, 2, lastrow, "LTT");
		String Employee_name = TestUtils.readexcel(i, 12, lastrow, "LTT");
		clearance.LEARNING_DEVELOPMENT_CLEARANCE(Clearance_Admin, Password_Remarks, User_id, Employee_name);
	}
	}

	@Test(priority = 10, enabled = true, description = "TIME HELPDESK CLEARANCE")
	public void TIME_HELPDESK_CLEARANCECLEARANCE() throws Throwable {
		for(int i =(Integer.parseInt(TestUtils.readexcel(1, 1, lastrow, "LTT")));i<=(Integer.parseInt(TestUtils.readexcel(2, 1, lastrow, "LTT")));i++){
		String Clearance_Admin = TestUtils.readexcel(i, 13, lastrow, "LTT");
		String Password_Remarks = TestUtils.readexcel(i, 1, lastrow, "LTT");
		String User_id = TestUtils.readexcel(i, 2, lastrow, "LTT");
		String Employee_name = TestUtils.readexcel(i, 12, lastrow, "LTT");
		clearance.TIME_HELPDESK_CLEARANCECLEARANCE(Clearance_Admin, Password_Remarks, User_id, Employee_name);
	}
	}

	@Test(priority = 9, enabled = true, description = " PEOPLE PROCESS/HR CLEARANCE")
	public void PEOPLE_PROCESS_CLEARANCE() throws Throwable {
		for(int i =(Integer.parseInt(TestUtils.readexcel(1, 1, lastrow, "LTT")));i<=(Integer.parseInt(TestUtils.readexcel(2, 1, lastrow, "LTT")));i++){
		String Clearance_Admin = TestUtils.readexcel(i, 13, lastrow, "LTT");
		String Password_Remarks = TestUtils.readexcel(i, 1, lastrow, "LTT");
		String User_id = TestUtils.readexcel(i, 2, lastrow, "LTT");
		String Employee_name = TestUtils.readexcel(i, 12, lastrow, "LTT");
		clearance.PEOPLE_PROCESS_CLEARANCE(Clearance_Admin, Password_Remarks, User_id, Employee_name);
		}
	}

	@Test(priority = 11, enabled = true, description = " Mobility CLEARANCE")
	public void Mobility_CLEARANCE() throws Throwable {
		for(int i =(Integer.parseInt(TestUtils.readexcel(1, 1, lastrow, "LTT")));i<=(Integer.parseInt(TestUtils.readexcel(2, 1, lastrow, "LTT")));i++){
		String Clearance_Admin = TestUtils.readexcel(i, 13, lastrow, "LTT");
		String Password_Remarks = TestUtils.readexcel(i, 1, lastrow, "LTT");
		String User_id = TestUtils.readexcel(i, 2, lastrow, "LTT");
		String Employee_name = TestUtils.readexcel(i, 12, lastrow, "LTT");
		clearance.Mobility_CLEARANCE(Clearance_Admin, Password_Remarks, User_id, Employee_name);
		}
	}
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	}
	

