package admin_feature;

import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import pages.All_Clearance;
import pages.HomePage;
import pages.LoginPage;
import Ecms_Base.TestBase;
import Ecms_Utility.TestUtils;
import Ecms_Utility.database_Connection;

public class User_managment extends TestBase {
	
	int lastrow = 1;
	LoginPage loginpage;
	database_Connection database;
	All_Clearance clearance;
	HomePage home;
	@BeforeTest
	public void browseropen(){
		
		loginpage = new LoginPage();
		database = new database_Connection();
		clearance = new All_Clearance();
		home = new HomePage();
		
		}

	 

	
	@Test(priority = 1,description = "Assign role for india Acis employee",enabled = false)
	public void Role_Acis() throws Throwable{
		
		Initialization();
		int i = 1;
		String Username = TestUtils.readexcel(i, 0, lastrow, "User_managment");
		String Password = TestUtils.readexcel(i, 1, lastrow, "User_managment");
		String User_id = TestUtils.readexcel(i, 2, lastrow, "User_managment");
		loginpage.dologin(Username, Password);
		home.usermanagment();
		for(int j = 1;j<=27;j++){	
		this.Dropdown_index("Role", j);
		this.Click("Select_country");
		this.Click("Country_india");
		this.Click("Select_country");
		this.Click("location");
		this.Click("Location_all");
		this.Click("location");
		if (this.findelement("Business_area").isEnabled() == true) {
		this.Dropdown_index("Business_area", 1);
		} else {
					System.out.println("role already granted");
				}
				
				this.findelement("Employee_name").clear();
				this.Dropdown_Select_employee("Employee_name", User_id);
				this.Click("Select_yes");
				this.file_Upload();
				this.Click("grant");
				Thread.sleep(6000);
				this.explicitwait("popup_close");
				this.Click("popup_close");
			
		}
		driver.close();

	}
	
	
	@Test(priority = 2,description = "Assign role for india BSV employee",enabled = false)
	public void Role_BSV() throws Throwable{
		
		Initialization();
		int i = 2;
		String Username = TestUtils.readexcel(i, 0, lastrow, "User_managment");
		String Password = TestUtils.readexcel(i, 1, lastrow, "User_managment");
		String User_id = TestUtils.readexcel(i, 2, lastrow, "User_managment");
		loginpage.dologin(Username, Password);
		home.usermanagment();
		for(int j = 1;j<=27;j++){	
		this.Dropdown_index("Role", j);
		this.Click("Select_country");
		this.Click("Country_india");
		this.Click("Select_country");
		this.Click("location");
		this.Click("Location_all");
		this.Click("location");
		if (this.findelement("Business_area").isEnabled() == true) {
		this.Dropdown_index("Business_area", 2);
		} else {
					System.out.println("role already granted");
				}
				
				this.findelement("Employee_name").clear();
				this.Dropdown_Select_employee("Employee_name", User_id);
				this.Click("Select_yes");
				this.file_Upload();
				this.Click("grant");
				Thread.sleep(6000);
				this.explicitwait("popup_close");
				this.Click("popup_close");
			
		}
		driver.close();
	}
	
	@Test(priority = 3,description = "Assign role for india FSSBU employee",enabled = true)
	public void Role_FSSBU() throws Throwable{
		
		Initialization();
		int i = 3;
		String Username = TestUtils.readexcel(i, 0, lastrow, "User_managment");
		String Password = TestUtils.readexcel(i, 1, lastrow, "User_managment");
		String User_id = TestUtils.readexcel(i, 2, lastrow, "User_managment");
		loginpage.dologin(Username, Password);
		home.usermanagment();
		for(int j = 1;j<=27;j++){	
		this.Dropdown_index("Role", j);
		this.Click("Select_country");
		this.Click("Country_india");
		this.Click("Select_country");
		this.Click("location");
		this.Click("Location_all");
		this.Click("location");
		if (this.findelement("Business_area").isEnabled() == true) {
		this.Dropdown_index("Business_area", 3);
		} else {
					System.out.println("role already granted");
				}
				
				this.findelement("Employee_name").clear();
				this.Dropdown_Select_employee("Employee_name", User_id);
				this.Click("Select_yes");
				this.file_Upload();
				this.Click("grant");
				Thread.sleep(6000);
				this.explicitwait("popup_close");
				this.Click("popup_close");
			
		}
		driver.close();
	}
	
	
	
	@Test(priority = 4,description = "Assign role for india ACISLHI employee",enabled = false)
	public void Role_ACISLHI() throws Throwable{
		
		Initialization();
		int i = 4;
		String Username = TestUtils.readexcel(i, 0, lastrow, "User_managment");
		String Password = TestUtils.readexcel(i, 1, lastrow, "User_managment");
		String User_id = TestUtils.readexcel(i, 2, lastrow, "User_managment");
		loginpage.dologin(Username, Password);
		home.usermanagment();
		for(int j = 1;j<=27;j++){	
		this.Dropdown_index("Role", j);
		this.Click("Select_country");
		this.Click("Country_india");
		this.Click("Select_country");
		this.Click("location");
		this.Click("Location_all");
		this.Click("location");
		if (this.findelement("Business_area").isEnabled() == true) {
		this.Dropdown_index("Business_area", 4);
		} else {
					System.out.println("role already granted");
				}
				
				this.findelement("Employee_name").clear();
				this.Dropdown_Select_employee("Employee_name", User_id);
				this.Click("Select_yes");
				this.file_Upload();
				this.Click("grant");
				Thread.sleep(6000);
				this.explicitwait("popup_close");
				this.Click("popup_close");
			
		}
		driver.close();
	}
	

	@Test(priority = 5,description = "Assign role for india ACISLHA employee",enabled = false)
	public void Role_ACISLHA() throws Throwable{
		
		Initialization();
		int i = 5;
		String Username = TestUtils.readexcel(i, 0, lastrow, "User_managment");
		String Password = TestUtils.readexcel(i, 1, lastrow, "User_managment");
		String User_id = TestUtils.readexcel(i, 2, lastrow, "User_managment");
		loginpage.dologin(Username, Password);
		home.usermanagment();
		for(int j = 1;j<=27;j++){	
		this.Dropdown_index("Role", j);
		this.Click("Select_country");
		this.Click("Country_india");
		this.Click("Select_country");
		this.Click("location");
		this.Click("Location_all");
		this.Click("location");
		if (this.findelement("Business_area").isEnabled() == true) {
		this.Dropdown_index("Business_area", 5);
		} else {
					System.out.println("role already granted");
				}
				
				this.findelement("Employee_name").clear();
				this.Dropdown_Select_employee("Employee_name", User_id);
				this.Click("Select_yes");
				this.file_Upload();
				this.Click("grant");
				Thread.sleep(6000);
				this.explicitwait("popup_close");
				this.Click("popup_close");
			
		}
		driver.close();
	}
	
	@Test(priority = 6,description = "Assign role for india BSVCHCS employee",enabled = false)
	public void Role_BSVCHCS() throws Throwable{
		
		Initialization();
		int i = 6;
		String Username = TestUtils.readexcel(i, 0, lastrow, "User_managment");
		String Password = TestUtils.readexcel(i, 1, lastrow, "User_managment");
		String User_id = TestUtils.readexcel(i, 2, lastrow, "User_managment");
		loginpage.dologin(Username, Password);
		home.usermanagment();
		for(int j = 1;j<=27;j++){	
		this.Dropdown_index("Role", j);
		this.Click("Select_country");
		this.Click("Country_india");
		this.Click("Select_country");
		this.Click("location");
		this.Click("Location_all");
		this.Click("location");
		if (this.findelement("Business_area").isEnabled() == true) {
		this.Dropdown_index("Business_area", 6);
		} else {
					System.out.println("role already granted");
				}
				
				this.findelement("Employee_name").clear();
				this.Dropdown_Select_employee("Employee_name", User_id);
				this.Click("Select_yes");
				this.file_Upload();
				this.Click("grant");
				Thread.sleep(6000);
				this.explicitwait("popup_close");
				this.Click("popup_close");
			
		}
		driver.close();
	}
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	}
	
	
