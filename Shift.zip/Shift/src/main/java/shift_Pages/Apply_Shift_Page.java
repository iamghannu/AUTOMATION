package shift_Pages;

import java.io.IOException;
import java.util.Calendar;

import org.openqa.selenium.support.Color;





import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebElement;
import org.testng.Assert;






import shift_Testbase.TestBase;
import utilities.Read_Excel;

public class Apply_Shift_Page extends TestBase {
	Read_Excel excel_read = new Read_Excel();
	
	
	public static  String[] months = new String[] { " ", "January", "February", "March", "April", "May", "June", "July", "August",
			"September", "October", "November", "December" };
	String[] NoOfDaysInMonth = new String[] { "", "31", "28", "31", "30", "31", "30", "31", "31", "30", "31", "30",
			"31" };
	Calendar now = Calendar.getInstance();
	int CuurentMonth = now.get(Calendar.MONTH) + 1; // Fetching the current month												// month
	String FirstMonth;
	String SecondMonth;
	String ThirdMonth;
	public int MonthInput;
	public String MonthToBeChecked;
	


	public Boolean MonthsSequence() throws Throwable {
		Boolean isLastThreeMonthsCalendarPresent;
		 MonthInput = Integer.parseInt(excel_read.getData("EmpulseAttendance", 2, 23));
		/*String MonthToBeChecked = months[MonthInput];
		String TotaldaysInMonthToBeChecked = NoOfDaysInMonth[MonthInput];
		String totaldays = NoOfDaysInMonth[MonthInput];*/
		Calendar now = Calendar.getInstance();
		int CuurentMonth = now.get(Calendar.MONTH) + 1; // Fetching the current
														// month
		
		if (CuurentMonth > 3) {
			FirstMonth = months[CuurentMonth - 3];
			SecondMonth = months[CuurentMonth - 2];
			ThirdMonth = months[CuurentMonth - 1];
			isLastThreeMonthsCalendarPresent = true;

		}
		else if (CuurentMonth == 3) {
			FirstMonth = months[12];
			SecondMonth = months[1];
			ThirdMonth = months[2];
			isLastThreeMonthsCalendarPresent = true;
		}
		else if (CuurentMonth == 2) {
			FirstMonth = months[11];
			SecondMonth = months[12];
			ThirdMonth = months[1];
			isLastThreeMonthsCalendarPresent = true;
		} else if (CuurentMonth == 1) {
			FirstMonth = months[10];
			SecondMonth = months[11];
			ThirdMonth = months[12];
			isLastThreeMonthsCalendarPresent = true;
		} 
		else {
			isLastThreeMonthsCalendarPresent = false;
		}
		return isLastThreeMonthsCalendarPresent;
	}

	
	
	public Boolean MonthToBeClicked() throws Throwable {
		MonthsSequence();
		Boolean isMonthToBeCheckedPresnt;
		 MonthToBeChecked = months[MonthInput];	
		if (MonthToBeChecked.equalsIgnoreCase(FirstMonth)) {
			this.Click("FirstMonth");
			isMonthToBeCheckedPresnt = true;
		} else if (MonthToBeChecked.equalsIgnoreCase(SecondMonth)) {
			this.Click("SecondMonth");
			isMonthToBeCheckedPresnt = true;
		} else if (MonthToBeChecked.equalsIgnoreCase(ThirdMonth)) {
			this.Click("ThirdMonth");
			isMonthToBeCheckedPresnt = true;
		} else {
			System.out.println(MonthToBeChecked + "\t Calendar is not displayed");
			System.out.println("");
			isMonthToBeCheckedPresnt = false;
		}

		return isMonthToBeCheckedPresnt;
	}

	
	
	
	public String ExtractColour(String DateInput) throws Throwable
	{
		String Date=null;
		String ActualColour=null;
	   for(int i=1;i<=5;i++){
	   for(int j=1;j<=7;j++){
	   if(driver.findElements (By.xpath("//*[@id='gvgriddetails']/tbody/tr["+i+"]/td["+j+"]//div[@class='Cdate']")).size() != 0)
	   {
	    Date= driver.findElement (By.xpath("//*[@id='gvgriddetails']/tbody/tr["+i+"]/td["+j+"]//div[@class='Cdate']")).getText();
	    if(Date.equalsIgnoreCase(DateInput))
	    {
		 String color =driver.findElement(By.xpath("//*[@id='gvgriddetails']/tbody/tr["+i+"]/td["+j+"]/div")).getCssValue("background-color");
		 ActualColour = Color.fromString(color).asHex();		
		 break;
	     }
		 else{continue; }	
		}	
		 else{continue; }	   
	    }
	   if(Date.equalsIgnoreCase(DateInput))
	   {
		   break;
	   } 
	   }
	     return ActualColour;
	   }
	
	
	
	
	
	public Boolean ClickPlusSign(String DateInput)
	{
		//Boolean isPlusSignPresnt=false;
		Boolean isPlusAndCancelSignPresnt=false;
		String  DateBeingDisplayed=null;
		for(int i=1; i<=5; i++)
		{
		for(int j=1;j<=7;j++)
		{
		if(driver.findElement(By.xpath("//table[@class='table']/tbody/tr["+i+"]/td["+j+"]//div[@class='Cdate']")).isDisplayed())
		{
		DateBeingDisplayed = driver.findElement(By.xpath("//table[@class='table']/tbody/tr["+i+"]/td["+j+"]//div[@class='Cdate']")).getText();
        if(DateBeingDisplayed.equals(DateInput))
        {
        isPlusAndCancelSignPresnt=driver.findElements(By.xpath("//table[@class='table']/tbody/tr["+i+"]/td["+j+"]//*[@class='Cadd']")).size()!=0;
        if(isPlusAndCancelSignPresnt)
        {
        WebElement PlusSign= driver.findElement(By.xpath("//table[@class='table']/tbody/tr["+i+"]/td["+j+"]//*[@id='imgMon']"));
    	JavascriptExecutor executor = (JavascriptExecutor)driver;
    	executor.executeScript("arguments[0].click();", PlusSign);
    	break;
        }
        else{
        	isPlusAndCancelSignPresnt=false;
       // System.out.println("The date displayed is same as the date input but the Plus and Cancel sign is not displayed");
        break;
        }
        }
        else{
       // System.out.println("The Date being displayed is not same as the Date input");                 
        }
	    }
		else{
			//System.out.println("The Date is not Displayed");
			continue;}				
		}
		if(DateBeingDisplayed.equals(DateInput))
		{
		break;
		}
			 else{continue;}
		}
		return isPlusAndCancelSignPresnt;
	   }
	
	
	
	
	
	public Boolean isPlusCancelSignPresentOnAllDays() throws Throwable
	{
		int index=0;
		String[] date= new String[] { "", "1", "2", "3", "4", "5", "6", "7", "8", "9", "10", "11","12","13","14","15","16","17","18","19","20","21","22","23","24","25","26","27","28","29","30","31" };
		for (int i=1;i<=31;i++)
		{
		    Boolean isPlusSignPresent= ClickPlusSign(date[i]);
			if(isPlusSignPresent)
			{
			index++;
			isPlusSignPresent=null;
			this.explicitwait("Cross");
			this.explicitwaitClick("Cross");
			this.Click("Cross");
			continue;
		    }
			else
			{
				continue;
			}
		}
		if(index == Integer.parseInt( NoOfDaysInMonth[MonthInput]))
		{
			//System.out.println("No of plus sign present is " +index );
			return true;
		}
		else
		{
			//System.out.println("No of plus sign present is " +index );
			return false;
		}
   }
	
	
	
	public String IndividualApply(String DateTaken, String ProjectName, String TaskName) throws Throwable
	{
		ClickPlusSign(DateTaken);
		this.explicitwait("Shift");
		Select select = new Select(this.findelement("Shift"));
		WebElement option = select.getFirstSelectedOption();
		String ShiftType = option.getText();
		this.explicitwaitClick("Project");
		this.Dropdown("Project", ProjectName);
		this.explicitwait("Task");
		this.explicitwaitClick("Task");
		this.Dropdown("Task", TaskName);
		if(this.isDisplayed("AddID"))
		{
				this.explicitwaitClick("AddID");
				this.Click("AddID");
				//System.out.println("Submitted for on call");
		}
		else{
			this.Click("Update");
			//System.out.println("Submitted for roaster shift");				
			}	
		/*this.scrollpagebottom();
		this.explicitwait("Submit");
		this.Click("Submit");
		this.explicitwaitClick("OKButton");
		this.Click("OKButton");
		this.explicitwaitClick("SubmitOkButton");
		this.Click("SubmitOkButton");*/
		return ShiftType;
	}
	
	
	public void ChooseStartDate(String StartDateTobeSelected) throws Throwable
	{
		String StartDate=null;
		this.scrollpageToView("StartDateCalendarImage");
		this.explicitwait("StartDateCalendarImage");
		this.Click("StartDateCalendarImage");
		this.explicitwait("datepicker");
		for (int i = 1; i <= 6; i++) {
		for (int j = 1; j <= 7; j++) {
		try {
		this.Click("StartDateCalendarImage");
		this.explicitwait("datepicker");
	    Boolean days = driver.findElement( By.xpath("//*[@id='ui-datepicker-div']/table/tbody/tr[" + i + "]/td[" + j + "]")).isDisplayed();
	    if (days){
	     WebElement element1 = driver.findElement(By.xpath("//*[@id='ui-datepicker-div']/table/tbody/tr[" + i + "]/td[" + j + "]/a"));
	     StartDate = element1.getText();
		if (StartDate.equals(StartDateTobeSelected)) {
		//System.out.println(StartDateTobeSelected+" is PRESENT IN (ROW,COL)\t" + i + "," + j);
		((JavascriptExecutor) driver).executeScript("arguments[0].click();", element1);
		}
		} else {
		//System.out.println("ELEMENT NOT Displayed");
		continue;}
		} catch (Exception e) {
	    	continue;}
		if (StartDate.equals(StartDateTobeSelected)) {
		break;
		} else {
		continue;}
		}
		if (StartDate.equals(StartDateTobeSelected)) {
				break;
		} else {
		continue;
			}
		}
	}
	
	
	public void ChooseEndDate(String EndDateTobeSelected) throws Throwable
	{
		String EndDate = null;
		Assert.assertTrue(this.isDisplayed("EndDateCalendarImage"));
		this.Click("EndDateCalendarImage");
		if (driver.findElement(By.xpath("//*[@id='myModalPopUp']/div/div")).isDisplayed()) {
		((JavascriptExecutor) driver).executeScript("arguments[0].click();",
		driver.findElement(By.xpath("//*[@id='btnModalpopupOK']")));
		}
		this.Click("EndDateCalendarImage");
		this.explicitwait("datepicker");
		for (int i = 1; i <= 6; i++) {
		for (int j = 1; j <= 7; j++) {
		try {
		this.explicitwait("datepicker");
		this.explicitwait("datepicker");
		Boolean days = driver.findElement(By.xpath("//*[@id='ui-datepicker-div']/table/tbody/tr[" + i + "]/td[" + j + "]")).isDisplayed();
		if (days) {
		WebElement element2 = driver.findElement(By.xpath("//*[@id='ui-datepicker-div']/table/tbody/tr[" + i + "]/td[" + j + "]/a"));
		EndDate = element2.getText();
        if (EndDate.equals(EndDateTobeSelected)) {
		//System.out.println("LAST DATE OF THE CALENDAR IS\t" + EndDate);
		//System.out.println("End Date of Calendar is prsent at (row,col)\t" + i + "," + j);
		((JavascriptExecutor) driver).executeScript("arguments[0].click();", element2);
			break;
		}
		} else {
		//System.out.println("ELEMENT NOT Displayed");
		continue;
		}
		} catch (Exception e) {
		continue;
		}
         if(EndDate.equals(EndDateTobeSelected))
         {break;
         }else{continue;}
		}if(EndDate.equals(EndDateTobeSelected))
        {break;
        }else{continue;}
		}if (driver.findElement(By.xpath("//*[@id='myModalPopUp']/div/div")).isDisplayed()) {

			((JavascriptExecutor) driver).executeScript("arguments[0].click();",
			driver.findElement(By.xpath("//*[@id='btnModalpopupOK']")));// Clicking on the pop up that says  end date should be greater than start date
		}
	}
	
	
	
	
	public void ProjectToBeSelected(String ProjectName)
	{
		this.Dropdown("ProjectBulkUpload",ProjectName);
		
	}
	
	
	
	public void TaskToBeSelected(String TaskName)
	{
		this.Dropdown("TaskBulkUpload", TaskName);

	}
	
	
	
	
	public void ClickAddButton() throws Throwable
	{
		this.Click("ADD");
	}
	
	
	
	
	public void ClickSubmitButton() throws Throwable
	{
		this.Click("SUBMIT");
		//System.out.println("Submit Button Clicked");
	}
	
	
	
	public Boolean ClickPopUps() throws Throwable
	{
		this.explicitwait("OKButton");
		this.Click("OKButton");//// clicking on the first(asking  whether do u want to submit request) OK button that comes after clicking SUBMIT button
		Boolean RequestSubmitted = this.isDisplayed("Shift Details Submitted Successfully."); // this.isTextDisplayed("Shift Details Submitted Successfully.");
		Assert.assertTrue(RequestSubmitted);
		this.explicitwait("SubmitOkButton");
		this.Click("SubmitOkButton");// clicking on 2nd submit button that comes after clicking submit
		return (RequestSubmitted);
	}
	
	
	
	public Boolean BulkUpload(String StartDate, String EndDate,String ProjectName,String TaskName) throws Throwable {
		ChooseStartDate(StartDate);
		ChooseEndDate(EndDate);
		ProjectToBeSelected(ProjectName);
		TaskToBeSelected(TaskName);
		ClickAddButton();
		ClickSubmitButton();
		Boolean isSubmitted= ClickPopUps();
		return isSubmitted;
	}
	
	
	public Boolean VerifyEmailFormatOfShiftRequest() throws NumberFormatException, Throwable
	{
		Boolean Verified= false;
		String From=null;String ActualSubject=null; String ExpectedSubject=null;
		String EmployeeId=excel_read.getData("EmpulseAttendance", 2, 0);
		String Year = excel_read.getData("EmpulseAttendance", 2, 22); String MonthName= Apply_Shift_Page.months[Integer.parseInt(excel_read.getData("EmpulseAttendance", 2, 23))]; 
		String EmployeeEmailId = PersonalDetails(EmployeeId)[0];
		EmployeeId= PersonalDetails(EmployeeId)[1];
		String	EmployeeFirstName= PersonalDetails(EmployeeId)[2];
		String	EmployeeLastName= PersonalDetails(EmployeeId)[3];
		String SupervisorEmployeeId= PersonalDetails(EmployeeId)[4];
		String SupervisorEmailId = PersonalDetails(SupervisorEmployeeId)[0];
		String SupervisorFirstName= PersonalDetails(SupervisorEmployeeId)[2];
		String SupervisorLastName= PersonalDetails(SupervisorEmployeeId)[3];
		From = ReadEmailFromDB()[0];
		ActualSubject= ReadEmailFromDB()[1];
		//System.out.println(ActualSubject); 
		ExpectedSubject="Shift Allowance pending for approval for : "+EmployeeFirstName+" "+EmployeeLastName+" ("+EmployeeId+")";
		//System.out.println(ExpectedSubject);

		try {
			MailInitialiser();
			String ActualBody= driver.findElement(By.xpath("/html/body")).getText();
			String ExpectedBody="Actual receipeints="+SupervisorEmailId+"\n"
					+ "Actual CCs="+EmployeeEmailId+"\n"
					+ "Actual BCCs=\n"
					+ "Dear " +SupervisorFirstName+" "+SupervisorLastName+",\n\n"
					+ "Kindly note the shift allowance submitted by " +EmployeeFirstName+" "+EmployeeLastName+" ("+EmployeeId+") for the month of "+MonthName+" - "+Year+" is waiting for your approval.\n\n"
					+ "Please follow below path to Approve / Reject.\n\n\n"
					+ "https://shiftallowance.in.capgemini.com -> Approvals -> Supervisor approval Thanks and Regards,\n"
					+ "Shift Allowance Admin\n\n"
					+ "Please do not response to this email. For any technical/functional issues,Kindly raise your service request using: BMC Remedy Service desk portal (Finance Application > Shift Allowance).";
			Assert.assertTrue(From.equalsIgnoreCase("noreply.shiftallowance.hr@capgemini.com"));
			Assert.assertTrue(ActualSubject.equalsIgnoreCase(ExpectedSubject));
			Assert.assertTrue(ActualBody.equals(ExpectedBody));
			Verified=true;

		} catch(IOException e){
			System.out.println("exception");
		}
		finally{
			HtmlToTxt();
		}
		return Verified;
		
	}
	
	
	
	
	
}

	

	
	
	
	
	
