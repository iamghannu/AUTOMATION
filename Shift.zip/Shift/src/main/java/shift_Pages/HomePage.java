package shift_Pages;

import shift_Testbase.TestBase;


public class HomePage extends TestBase {

	
	public void Shift() throws Throwable
	{
	    this.explicitwait("ShiftButton");
		this.Click("ShiftButton");
		this.explicitwait("ApplyShiftButton");
		this.Click("ApplyShiftButton");		
		if(!driver.getTitle().equalsIgnoreCase("Apply Shift"))
		{
			this.Click("Home");
			Shift();
		}
	}

	public void LogOff() throws Throwable
	{
		this.explicitwaitClick("LogOff");
		this.Click("LogOff");	
		if(!driver.getTitle().equalsIgnoreCase("Login"))
		{
			this.Click("Home");
			LogOff();
		}
	}
	
	
	public void Reopen() throws Throwable
	{
	   this.explicitwait("ShiftButton");
		this.Click("ShiftButton");
		this.explicitwait("Reopen");
		this.Click("Reopen");	
		if(!driver.getTitle().equalsIgnoreCase("ReopenShiftRequest"))
		{
			this.Click("Home");
			Reopen();
		}
	}
	

	//Method to Navigate to SUPERVISOR APPROVAL page
	public void GoSupApprovalPage() throws Throwable
	{
		this.explicitwait("Approval");
	    this.hover("Approval");
		this.explicitwait("SupervisorApproval");
		this.explicitwaitClick("SupervisorApproval");
		this.Click("SupervisorApproval");	
		Thread.sleep(0050);
	//	String title= driver.getTitle();
		if(!driver.getTitle().equalsIgnoreCase("Supervisor Approval"))
		{
			this.Click("Home");
			GoSupApprovalPage();
		}
		
	}	
		
	public void GoSupReopenApprovalPage() throws Throwable
	{
		this.explicitwait("Approval");
	    this.hover("Approval");
		this.explicitwait("SupervisorReopen");
		this.explicitwaitClick("SupervisorReopen");
		this.Click("SupervisorReopen");	
		Thread.sleep(0050);
		//String title= driver.getTitle();
		if(!driver.getTitle().equalsIgnoreCase("Reopen Approval"))
		{
			this.Click("Home");
			GoSupReopenApprovalPage();
		}
		
	}	
	
	public void GoPMApprovalPage() throws Throwable
	{
		this.explicitwait("Approval");
	    this.hover("Approval");
		this.explicitwait("PMApproval");
		this.Click("PMApproval");
		Thread.sleep(0050);
		//this.explicitwait("PMPageTitle");
		if(!driver.getTitle().equals("Project Manager Approval"))
		{
			GoPMApprovalPage();
		}
		
	}	
	
	public void GoSupDelegatePage() throws Throwable
	{
		this.explicitwait("Delegate");
	    this.Click("Delegate");
	    Thread.sleep(0050);
		if(!driver.getTitle().equals("Delegate Supervisor Form"))
		{
			GoSupDelegatePage();
		}
		
	}	
	
	
}
