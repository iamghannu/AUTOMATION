package shift_Pages;

import shift_Testbase.TestBase;



public class LoginPage extends TestBase{
	
 
	public void LogIn(String username, String Password) throws Throwable
	{
		this.explicitwait("username");
		this.SendData("username", username);
		this.SendData("Password", Password);
		this.Click("LoginButton");
		}
	

}
