package shift_Pages;

import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

import org.openqa.selenium.By;
import org.testng.Assert;

import shift_Testbase.TestBase;
import utilities.DB_Operation;
import utilities.Read_Excel;

public class PMApprovalPage extends TestBase {
	
	Apply_Shift_Page apply= new Apply_Shift_Page();Read_Excel Data= new Read_Excel();
	DB_Operation DB= new DB_Operation(); SupervisorApprovalPage SUP= new SupervisorApprovalPage();
	HomePage home= new HomePage();
	
	
	public void PMShiftApproval() throws Throwable
	{
		home.GoPMApprovalPage();		
		SUP.FindEmpVerifyDetails("Approve");
				
	}
	public void PMShiftRejection() throws Throwable
	{
		home.GoPMApprovalPage();		
		SUP.FindEmpVerifyDetails("Reject");
				
	}
	
	public Boolean VerifyEmailFormatOnAppByPM() throws Throwable
	{
		Boolean Verified=false;
		String From= null; String ActualSubject=null; String ExpectedSubject=null;
		String ProjectManagerEmployeeId=null;
		String EmployeeId=Data.getData("EmpulseAttendance", 2, 0);
		String Year = Data.getData("EmpulseAttendance", 2, 22); String MonthName= Apply_Shift_Page.months[Integer.parseInt(Data.getData("EmpulseAttendance", 2, 23))]; 
		String EmployeeEmailId = PersonalDetails(EmployeeId)[0];
		EmployeeId= PersonalDetails(EmployeeId)[1];
		String	EmployeeFirstName= PersonalDetails(EmployeeId)[2];
		String	EmployeeLastName= PersonalDetails(EmployeeId)[3];
		String SupervisorEmployeeId= PersonalDetails(EmployeeId)[4];
		String SupervisorEmailId = PersonalDetails(SupervisorEmployeeId)[0];
		ProjectManagerEmployeeId=DB.PMEMPID();
		String ProjectManagerEmailId=PersonalDetails(ProjectManagerEmployeeId)[0];
		String ProjectManagerFirstName= PersonalDetails(ProjectManagerEmployeeId)[2];
		String ProjectManagerLastName= PersonalDetails(ProjectManagerEmployeeId)[3];

		From = ReadEmailFromDB()[0];
		ActualSubject= ReadEmailFromDB()[1];
		//System.out.println(ActualSubject); 
		ExpectedSubject="Shift Allowance Approved for : "+EmployeeFirstName+" "+EmployeeLastName+" ("+EmployeeId+")";
		//System.out.println(ExpectedSubject);
		
		try {
			MailInitialiser();
			String ActualBody= driver.findElement(By.xpath("/html/body")).getText();
			//System.out.println(ActualBody);
			String ExpectedBody="Actual receipeints="+EmployeeEmailId +"\n"
					+ "Actual CCs="+SupervisorEmailId+";"+ProjectManagerEmailId+"\n"
					+ "Actual BCCs=\n"
					+ "Dear " +EmployeeFirstName+" "+EmployeeLastName+" ("+EmployeeId+"),\n\n"
					+ "Kindly note the shift allowance submitted by " +EmployeeFirstName+" "+EmployeeLastName+" ("+EmployeeId+") for the month of "+MonthName+" - "+Year+" is Approved by "+ProjectManagerFirstName +" "+ProjectManagerLastName+".\n\n"
					+ "Thanks and Regards,\n"
					+ "Shift Allowance Admin\n\n"
					+ "Please do not response to this email. For any technical/functional issues,Kindly raise your service request using: BMC Remedy Service desk portal (Finance Application > Shift Allowance).";
			Assert.assertTrue(From.equalsIgnoreCase("noreply.shiftallowance.hr@capgemini.com"));
			Assert.assertTrue(ActualSubject.equalsIgnoreCase(ExpectedSubject));
			//System.out.println("Actual Body is:\n "+ActualBody);
		    //System.out.println("Expected Body is:\n "+ExpectedBody);
			Assert.assertTrue(ActualBody.equalsIgnoreCase(ExpectedBody));
			Verified=true;

		} catch(IOException e){
			System.out.println("exception");
		}
		finally{
			HtmlToTxt();
		}
		return Verified;
	}

	public Boolean VerifyEmailFormatOnRejectionByPM() throws Throwable
	{
		Boolean Verified=false;
		String From=null;String ActualSubject=null; String ExpectedSubject=null;
		String ProjectManagerEmployeeId=null;
		String EmployeeId=Data.getData("EmpulseAttendance", 2, 0);
		String Year = Data.getData("EmpulseAttendance", 2, 22); String MonthName= Apply_Shift_Page.months[Integer.parseInt(Data.getData("EmpulseAttendance", 2, 23))]; 
		String EmployeeEmailId = PersonalDetails(EmployeeId)[0];
		EmployeeId= PersonalDetails(EmployeeId)[1];
		String	EmployeeFirstName= PersonalDetails(EmployeeId)[2];
		String	EmployeeLastName= PersonalDetails(EmployeeId)[3];
		String SupervisorEmployeeId= PersonalDetails(EmployeeId)[4];
		String SupervisorEmailId = PersonalDetails(SupervisorEmployeeId)[0];
		ProjectManagerEmployeeId=DB.PMEMPID();
		String ProjectManagerEmailId=PersonalDetails(ProjectManagerEmployeeId)[0];
		String ProjectManagerFirstName= PersonalDetails(ProjectManagerEmployeeId)[2];
		String ProjectManagerLastName= PersonalDetails(ProjectManagerEmployeeId)[3];
		From = ReadEmailFromDB()[0];
		ActualSubject= ReadEmailFromDB()[1];
		//System.out.println(ActualSubject); 
		ExpectedSubject="Shift Allowance Rejected by : "+ProjectManagerFirstName+" "+ProjectManagerLastName+"";
		//System.out.println(ExpectedSubject);
		
		try {
			MailInitialiser();
			String ActualBody= driver.findElement(By.xpath("/html/body")).getText();
			String ExpectedBody="Actual receipeints="+EmployeeEmailId+"\n"
					+ "Actual CCs="+SupervisorEmailId+";"+ProjectManagerEmailId+"\n"
					+ "Actual BCCs=\n"
					+ "Dear " +EmployeeFirstName+" "+EmployeeLastName+" "+"("+EmployeeId+"),\n\n"
					+ "Kindly note the shift allowance submitted by " +EmployeeFirstName+" "+EmployeeLastName+" ("+EmployeeId+") for the month of "+MonthName+" - "+Year+" is Rejected by "+ProjectManagerFirstName +" "+ProjectManagerLastName+".\n\n"
					+ "Rejection Remarks: TESTING\n"
					+ "Note: The Shift request would be rejected for the whole month, employee can fill the roaster and resubmit the request again. Thanks and Regards,\n"
					+ "Shift Allowance Admin\n\n"
					+ "Please do not response to this email. For any technical/functional issues,Kindly raise your service request using: BMC Remedy Service desk portal (Finance Application > Shift Allowance).";
			//System.out.println("Actual body is\n "+ActualBody);
		   //System.out.println("Expected body is\n "+ExpectedBody);
			Assert.assertTrue(From.equalsIgnoreCase("noreply.shiftallowance.hr@capgemini.com"));
			Assert.assertTrue(ActualSubject.equalsIgnoreCase(ExpectedSubject));
			Assert.assertTrue(ActualBody.equals(ExpectedBody));
			Verified=true;

		} catch(IOException e){
			System.out.println("exception");
		}
		finally{
			HtmlToTxt();
		}
		return Verified;
	}
}
