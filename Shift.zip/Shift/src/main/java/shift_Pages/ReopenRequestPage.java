package shift_Pages;

import java.io.IOException;

import org.openqa.selenium.By;
import org.testng.Assert;

import shift_Testbase.TestBase;
import utilities.DB_Operation;
import utilities.Read_Excel;

public class ReopenRequestPage extends TestBase {
	
	Read_Excel Data = new Read_Excel();DB_Operation DB= new DB_Operation();
	
	public void RaiseReopenRequest(String Status) throws Throwable
	{
		this.explicitwait("EmployeeID");
		Assert.assertTrue(this.findelement("EmployeeID").getText().contains(Data.getData("EmpulseAttendance", 2, 0)));
		this.Click("MonthYear");
		this.Dropdown("MonthYear", Apply_Shift_Page.months[Integer.parseInt(Data.getData("EmpulseAttendance", 2, 23))]);
		this.explicitwait("ShiftStatus");
		Assert.assertTrue(this.findelement("ShiftStatus").getText().contains(Status));
		this.explicitwait("Comments");
		this.SendData("Comments", "Testing");
		this.explicitwaitClick("ReopenRequestSubmit");
		this.Click("ReopenRequestSubmit");
		this.explicitwait("MessagePopUp");
		this.explicitwaitClick("ReopenSubmitOK");
		this.Click("ReopenSubmitOK");				
	}
	
	public Boolean VerifyEmailFormatOfReopenRequest() throws Throwable
	{

		Boolean Verified= false;
		String From=null;String ActualSubject=null; String ExpectedSubject=null;String ProjectManagerEmployeeId=null;
		String EmployeeId=Data.getData("EmpulseAttendance", 2, 0);
		String Year = Data.getData("EmpulseAttendance", 2, 22); String MonthName= Apply_Shift_Page.months[Integer.parseInt(Data.getData("EmpulseAttendance", 2, 23))]; 
		String EmployeeEmailId = PersonalDetails(EmployeeId)[0];
		EmployeeId= PersonalDetails(EmployeeId)[1];
		String	EmployeeFirstName= PersonalDetails(EmployeeId)[2];
		String	EmployeeLastName= PersonalDetails(EmployeeId)[3];
		String SupervisorEmployeeId= PersonalDetails(EmployeeId)[4];
		String SupervisorEmailId = PersonalDetails(SupervisorEmployeeId)[0];
		String SupervisorFirstName= PersonalDetails(SupervisorEmployeeId)[2];
		String SupervisorLastName= PersonalDetails(SupervisorEmployeeId)[3];
		ProjectManagerEmployeeId = DB.PMEMPID();		
		String ProjectManagerEmailId=PersonalDetails(ProjectManagerEmployeeId)[0];
		From = ReadEmailFromDB()[0];
		ActualSubject= ReadEmailFromDB()[1];
		//System.out.println("Actual Subject is:\n"+ActualSubject); 
		ExpectedSubject="Shift Reopen request from  "+EmployeeFirstName+" "+EmployeeLastName +" by "+SupervisorFirstName +" "+SupervisorLastName+"";
		//System.out.println(ExpectedSubject);

		try {
			MailInitialiser();
			String ActualBody= driver.findElement(By.xpath("/html/body")).getText();
			//System.out.println("Actual Body is:\n "+ActualBody);
			String ExpectedBody="Actual receipeints="+SupervisorEmailId+"\n"
					+ "Actual CCs="+EmployeeEmailId+","+ProjectManagerEmailId+",,\n"
					+ "Actual BCCs=\n"
					+ "Dear " +SupervisorFirstName+" "+SupervisorLastName+",\n\n"
					+ "Kindly note the reopen request is sent by the Employee " +EmployeeFirstName+" "+EmployeeLastName+" ("+EmployeeId+") for the following month is waiting for your approval :\n\n"
					+ "Employee Name Employee Id Month Year\n"
					+ ""+EmployeeFirstName+" "+EmployeeLastName+" "+EmployeeId+" "+MonthName+" "+Year+"\n\n"
					+ "Please follow below path to Approve / Reject.\n\n"
					+ "https://shiftallowance.in.capgemini.com -> Approvals -> Reopen\n\n"
					+ "Thanks and Regards,\n"
					+ "Shift Allowance Admin";
			//System.out.println("Expected Body is:\n "+ExpectedBody);
			Assert.assertTrue(From.equalsIgnoreCase("noreply.shiftallowance.hr@capgemini.com"));
			Assert.assertTrue(ActualSubject.equalsIgnoreCase(ExpectedSubject));
			Assert.assertTrue(ActualBody.equals(ExpectedBody));
			Verified=true;

		} catch(IOException e){
			System.out.println("exception");
		}
		finally{
			HtmlToTxt();
		}
		return Verified;
		
		
		
		
	}
	
	
	
	

}
