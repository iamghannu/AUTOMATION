package shift_Pages;



import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.testng.Assert;

import shift_Testbase.TestBase;
import utilities.DB_Operation;
import utilities.Read_Excel;

    public class SupervisorApprovalPage extends TestBase {

	Apply_Shift_Page apply= new Apply_Shift_Page();Read_Excel Data= new Read_Excel();
	DB_Operation DB= new DB_Operation();Connection conn;
	HomePage home= new HomePage();
	
	
	
	//Mrthod to verify rates and take action on Pending Request
	public void FindEmpVerifyDetails(String Action) throws Throwable
	{
		List<WebElement> li = this.findelements("MonthList");
        for(WebElement Month:li)
        {      
     	   if(Month.getText().contains((Apply_Shift_Page.months[Integer.parseInt(Data.getData("EmpulseAttendance", 2, 23))])))
     	   {
     		   this.explicitwait("MonthList");
     		  Month.click();
     		  break;
     	   }
        }    
        //System.out.println("Reached the table");
        this.explicitwait("TbleGrid");
        //System.out.println("Crossed the table");
        List<WebElement> Rows= this.findelements("EmployeeRow");
        for(WebElement DesiredEmp: Rows)
        {
        	int x=1;
        	List<WebElement>Columns= DesiredEmp.findElements(By.tagName("td"));
        	for(WebElement EmpPresent :Columns)
        	{    
        		String EmpName=null;
        		
           // System.out.println("Finding employee");
        		if(x!=2){
        	
        	    EmpName=EmpPresent.getText();
        		}
        		else
        		{
        			      			
        			 EmpName= EmpPresent.findElement(By.tagName("a")).getAttribute("innerText");      			
        			// System.out.println(EmpName);       			 
        			 Assert.assertTrue(EmpName.contains(Data.getData("EmpulseAttendance", 2, 0)),""+EmpName+" Not Found Here As Well");
             	    //System.out.println("Found Here");
        		}
        	x=x+1;
        	//System.out.println(EmpName);
        	if(EmpName.contains(Data.getData("EmpulseAttendance", 2, 0)))
        	{
        		//System.out.println("Employee Found");
        	Boolean isRatesAndCountCorrect = false;       		
        	List RatesInDB= DB.VerifyShiftRatesAndCount();
        	int k=0;int l=1;   			
        	for(int i=0;i<RatesInDB.size();i++)        		
        	{      		      				
        				List <WebElement>Count= DesiredEmp.findElements(By.tagName("label"));
        				List <WebElement>Rates= DesiredEmp.findElements(By.tagName("input"));
        				String ActualRates = "";
        				Object ShiftCount=0;       			
        			   while(k<6 || l<6)
        			   {
					   if(i%2==0)
					   {
								ShiftCount=Count.get(k).getText();
								if(k==5)
								{
									ShiftCount=ShiftCount+".00";
								}
								if(RatesInDB.get(i).equals(ShiftCount))
		        				 {
		        					 isRatesAndCountCorrect=true;	
		        					 Assert.assertTrue(isRatesAndCountCorrect);
		        					 k++;
									break;
		        				 }
								else
								{
									System.out.println("Count Are not correct");
									Assert.assertTrue(false);
								}
						}
						else if(i%2!=0)
						{
								ActualRates= Rates.get(l).getAttribute("value");
		        				 ActualRates=ActualRates+".00";
		        				 if((RatesInDB.get(i).equals(ActualRates))==true)
		        				 {
		        					 isRatesAndCountCorrect=true;	
		        					 Assert.assertTrue(isRatesAndCountCorrect);
		        					 l=l+1;
									break;
		        				 }
		        				 else
		        				 {
		        					 System.out.println("Rates Are not correct");
									Assert.assertTrue(false);
		        				 }
								
						}
	        				       	
        	}
        							 
        	}
        	
        		if(isRatesAndCountCorrect==true)
        		{
        		 for(WebElement Checkbox: Columns)
        		 {
        			 
        			 this.explicitwaitele(Checkbox);
        			 WebElement Checked = Checkbox.findElement(By.tagName("input"));
        			
        			 //System.out.println(Checked.isSelected());
        			 Checkbox.click();   
        			
        			 if(!Checked.isSelected())
        			 {
        				 this.explicitwaitele(Checkbox);
        				 Checked.click();  
        			 }
        			 Assert.assertTrue(Checked.isSelected(), "Employee not selected and Checkbox not checked");
        			 try {
        				 //this.explicitwaitClick("Action");
						this.Dropdown("Action", Action);
					} catch (Exception e) {
						this.explicitwaitClick("ActionReopen");
						this.Dropdown("ActionReopen", Action);
					}
        			 this.ClearData("Remarks");
        			 this.SendData("Remarks", "TESTING");
        			 this.explicitwaitClick("SubmitAction");
        			 this.Click("SubmitAction");
        			 this.explicitwaitClick("Ok");
        		     this.Click("Ok");        		     
        		     return;
        		 }
        		}
        		else
        		{
        			System.out.println("Can't be Approved, Either the count or Shift Rate is not correct");
        			return;
        		}
        		
        	}
        	
        	    
        }
        	    
	}
		
	}
	
	public void SupShiftApproval() throws Throwable
	{
		home.GoSupApprovalPage();		
		FindEmpVerifyDetails("Approve");
				
	}
	
	public void SupShiftRejection() throws Throwable
	{
		home.GoSupApprovalPage();	
		FindEmpVerifyDetails("Reject");				
	}
	
	public void ReopenReqApproval() throws Throwable
	{
		home.GoSupReopenApprovalPage();		
		FindEmpVerifyDetails("Reopen");
				
	}
	
	public void ReopenReqRejection() throws Throwable
	{
		home.GoSupReopenApprovalPage();		
		FindEmpVerifyDetails("Reject");
				
	}
	
	public Boolean VerifyEmailFormatOnAppBySup() throws Throwable
	{
		Boolean Verified=false;
		String From=null;String ActualSubject=null; 
		From = ReadEmailFromDB()[0];
		ActualSubject= ReadEmailFromDB()[1];
		String ProjectManagerEmployeeId=null;
		String EmployeeId=Data.getData("EmpulseAttendance", 2, 0);
		String Year = Data.getData("EmpulseAttendance", 2, 22); String MonthName= Apply_Shift_Page.months[Integer.parseInt(Data.getData("EmpulseAttendance", 2, 23))]; 
		String EmployeeEmailId = PersonalDetails(EmployeeId)[0];
		EmployeeId= PersonalDetails(EmployeeId)[1];
		String	EmployeeFirstName= PersonalDetails(EmployeeId)[2];
		String	EmployeeLastName= PersonalDetails(EmployeeId)[3];
		String ExpectedSubject="Shift Allowance pending for approval for : "+EmployeeFirstName+" "+EmployeeLastName+" ("+EmployeeId+")";
		String SupervisorEmployeeId= PersonalDetails(EmployeeId)[4];
		String SupervisorEmailId = PersonalDetails(SupervisorEmployeeId)[0];
		String SupervisorFirstName = PersonalDetails(SupervisorEmployeeId)[2];
		String SupervisorLastName = PersonalDetails(SupervisorEmployeeId)[3];
		ProjectManagerEmployeeId = DB.PMEMPID();		
		String ProjectManagerEmailId=PersonalDetails(ProjectManagerEmployeeId)[0];
		String ProjectManagerFirstName= PersonalDetails(ProjectManagerEmployeeId)[2];
		String ProjectManagerLastName= PersonalDetails(ProjectManagerEmployeeId)[3];

		String ExpectedBody="Actual receipeints="+ProjectManagerEmailId+"\n"
				+ "Actual CCs="+SupervisorEmailId+";"+EmployeeEmailId+"\n"
				+ "Actual BCCs=\n"
				+ "Dear " +ProjectManagerFirstName+" "+ProjectManagerLastName+",\n\n"
				+ "Kindly note the shift allowance submitted by " +EmployeeFirstName+" "+EmployeeLastName+" ("+EmployeeId+") for the month of "+MonthName+" - "+Year+" is Approved by "+SupervisorFirstName +" "+SupervisorLastName+" is now pending for your approval.\n\n"
				+ "Thanks and Regards,\n"
				+ "Shift Allowance Admin\n\n"
				+ "Please do not response to this email. For any technical/functional issues,Kindly raise your service request using: BMC Remedy Service desk portal (Finance Application > Shift Allowance).";
		try {
			MailInitialiser();
			String ActualBody= driver.findElement(By.xpath("/html/body")).getText();
			Assert.assertTrue(From.equalsIgnoreCase("noreply.shiftallowance.hr@capgemini.com"));
			//System.out.println("Actual Subject is: "+ActualSubject);
			//System.out.println("Expected Subject is: "+ExpectedSubject);
			Assert.assertTrue(ActualSubject.equalsIgnoreCase(ExpectedSubject));
			Assert.assertTrue(ActualBody.equalsIgnoreCase(ExpectedBody));
			Verified=true;
		} catch(IOException e){
			System.out.println("exception");
		}
		finally{
			HtmlToTxt();
		}	
		return Verified;
	}
	
	public Boolean VerifyEmailFormatOnRejectionBySup() throws Throwable
	{
		Boolean Verified=false;
		String From=null;String ActualSubject=null; 
		String ExpectedSubject=null;
		String EmployeeId=Data.getData("EmpulseAttendance", 2, 0);
		String Year = Data.getData("EmpulseAttendance", 2, 22); String MonthName= Apply_Shift_Page.months[Integer.parseInt(Data.getData("EmpulseAttendance", 2, 23))]; 
		String EmployeeEmailId = PersonalDetails(EmployeeId)[0];
		EmployeeId= PersonalDetails(EmployeeId)[1];
		String	EmployeeFirstName= PersonalDetails(EmployeeId)[2];
		String	EmployeeLastName= PersonalDetails(EmployeeId)[3];
		String SupervisorEmployeeId= PersonalDetails(EmployeeId)[4];
		String SupervisorEmailId = PersonalDetails(SupervisorEmployeeId)[0];
		String SupervisorFirstName = PersonalDetails(SupervisorEmployeeId)[2];
		String SupervisorLastName = PersonalDetails(SupervisorEmployeeId)[3];
		ExpectedSubject="Shift Allowance Rejected by : "+SupervisorFirstName+" "+SupervisorLastName+"";
		String ExpectedBody="Actual receipeints="+EmployeeEmailId+"\n"
				+ "Actual CCs="+SupervisorEmailId+"\n"
				+ "Actual BCCs=\n"
				+ "Dear " +EmployeeFirstName+" "+EmployeeLastName+" ("+EmployeeId+"),\n\n"
				+ "Kindly note the shift allowance submitted by " +EmployeeFirstName+" "+EmployeeLastName+" ("+EmployeeId+") for the month of "+MonthName+" - "+Year+" is rejected by "+SupervisorFirstName +" "+SupervisorLastName+".\n"
				+ "Rejection Remarks: TESTING\n"
				+ "Note: The Shift request would be rejected for the whole month, employee can fill the roaster and resubmit the request again.\n\n"
				+ "Thanks and Regards,\n"
				+ "Shift Allowance Admin\n\n"
				+ "Please do not response to this email. For any technical/functional issues,Kindly raise your service request using: BMC Remedy Service desk portal (Finance Application > Shift Allowance).";
		From = ReadEmailFromDB()[0];
		ActualSubject= ReadEmailFromDB()[1];		
		try {
			MailInitialiser();
			
			String ActualBody= driver.findElement(By.xpath("/html/body")).getText();
			Assert.assertTrue(From.equalsIgnoreCase("noreply.shiftallowance.hr@capgemini.com"));
			//System.out.println("Actual Subject is:\n "+ActualSubject);
			//System.out.println("Expected Subject is:\n "+ExpectedSubject);
			Assert.assertTrue(ActualSubject.equalsIgnoreCase(ExpectedSubject));
			Assert.assertTrue(ActualBody.equals(ExpectedBody));
			Verified=true;
		} catch(IOException e){
			System.out.println("exception");
		}
		finally{
			HtmlToTxt();
		}
		return Verified;				
	}
	
	public Boolean VerifyEmailFormatOnReopenRequestRejected() throws Throwable
	{

		Boolean Verified= false;
		String From=null;String ActualSubject=null; String ExpectedSubject=null;String ProjectManagerEmployeeId=null;
		String EmployeeId=Data.getData("EmpulseAttendance", 2, 0);
		String Year = Data.getData("EmpulseAttendance", 2, 22); String MonthName= Apply_Shift_Page.months[Integer.parseInt(Data.getData("EmpulseAttendance", 2, 23))]; 
		String EmployeeEmailId = PersonalDetails(EmployeeId)[0];
		EmployeeId= PersonalDetails(EmployeeId)[1];
		String	EmployeeFirstName= PersonalDetails(EmployeeId)[2];
		String	EmployeeLastName= PersonalDetails(EmployeeId)[3];
		String SupervisorEmployeeId= PersonalDetails(EmployeeId)[4];
		String SupervisorEmailId = PersonalDetails(SupervisorEmployeeId)[0];
		String SupervisorFirstName= PersonalDetails(SupervisorEmployeeId)[2];
		String SupervisorLastName= PersonalDetails(SupervisorEmployeeId)[3];
		ProjectManagerEmployeeId = DB.PMEMPID();		
		String ProjectManagerEmailId=PersonalDetails(ProjectManagerEmployeeId)[0];
		From = ReadEmailFromDB()[0];
		ActualSubject= ReadEmailFromDB()[1];
		//System.out.println("Actual Subject is:\n"+ActualSubject); 
		ExpectedSubject="Reopen Request Rejected by "+SupervisorFirstName+" "+SupervisorLastName +" for "+EmployeeFirstName +" "+EmployeeLastName+" ("+EmployeeId+")";
		//System.out.println(ExpectedSubject);

		try {
			MailInitialiser();
			String ActualBody= driver.findElement(By.xpath("/html/body")).getText();
			//System.out.println("Actual Body is:\n "+ActualBody);
			String ExpectedBody="Actual receipeints="+EmployeeEmailId+"\n"
					+ "Actual CCs="+SupervisorEmailId+";"+ProjectManagerEmailId+"\n"
					+ "Actual BCCs=\n"
					+ "Dear " +EmployeeFirstName+" "+EmployeeLastName+" ("+EmployeeId+"),\n\n"
					+ "Kindly note the Reopen shift allowance submitted by " +EmployeeFirstName+" "+EmployeeLastName+" ("+EmployeeId+") for the month of "+MonthName+" - "+Year+" is rejected by "+SupervisorFirstName+" "+SupervisorLastName+".\n\n"
					+ "Rejection Remarks: TESTING\n\n"
					+ "Note: The Shift request would be rejected for the whole month, employee can fill the roaster and resubmit the request again.\n\n"
					+ "Thanks and Regards,\n"
					+ "Shift Allowance Admin\n\n"
			        + "Please do not response to this email. For any technical/functional issues,Kindly raise your service request using :BMC Remedy Service desk portal (Finance Application > Shift Allowance).";

			//System.out.println("Expected Body is:\n "+ExpectedBody);
			Assert.assertTrue(From.equalsIgnoreCase("noreply.shiftallowance.hr@capgemini.com"));
			Assert.assertTrue(ActualSubject.equalsIgnoreCase(ExpectedSubject));
			Assert.assertTrue(ActualBody.equals(ExpectedBody));
			Verified=true;

		} catch(IOException e){
			System.out.println("exception");
		}
		finally{
			HtmlToTxt();
		}
		return Verified;

	}
	
	public Boolean VerifyEmailFormatOnReopenRequestApproved() throws Throwable
	{

		Boolean Verified= false;
		String From=null;String ActualSubject=null; String ExpectedSubject=null;String ProjectManagerEmployeeId=null;
		String EmployeeId=Data.getData("EmpulseAttendance", 2, 0);
		String Year = Data.getData("EmpulseAttendance", 2, 22); String MonthName= Apply_Shift_Page.months[Integer.parseInt(Data.getData("EmpulseAttendance", 2, 23))]; 
		String EmployeeEmailId = PersonalDetails(EmployeeId)[0];
		EmployeeId= PersonalDetails(EmployeeId)[1];
		String	EmployeeFirstName= PersonalDetails(EmployeeId)[2];
		String	EmployeeLastName= PersonalDetails(EmployeeId)[3];
		String SupervisorEmployeeId= PersonalDetails(EmployeeId)[4];
		String SupervisorEmailId = PersonalDetails(SupervisorEmployeeId)[0];
		String SupervisorFirstName= PersonalDetails(SupervisorEmployeeId)[2];
		String SupervisorLastName= PersonalDetails(SupervisorEmployeeId)[3];
		ProjectManagerEmployeeId = DB.PMEMPID();		
		String ProjectManagerEmailId=PersonalDetails(ProjectManagerEmployeeId)[0];
		From = ReadEmailFromDB()[0];
		ActualSubject= ReadEmailFromDB()[1];
		//System.out.println("Actual Subject is:\n"+ActualSubject); 
		ExpectedSubject="Shift Request Reopened by"+SupervisorFirstName+" "+SupervisorLastName +" for "+EmployeeFirstName +" "+EmployeeLastName+" ("+EmployeeId+")";
		//System.out.println(ExpectedSubject);

		try {
			MailInitialiser();
			String ActualBody= driver.findElement(By.xpath("/html/body")).getText();
			//System.out.println("Actual Body is:\n "+ActualBody);
			String ExpectedBody="Actual receipeints="+EmployeeEmailId+"\n"
					+ "Actual CCs="+SupervisorEmailId+";"+ProjectManagerEmailId+"\n"
					+ "Actual BCCs=\n"
					+ "Dear " +EmployeeFirstName+" "+EmployeeLastName+" ("+EmployeeId+"),\n\n"
					+ "Kindly note the Reopen shift allowance submitted by " +EmployeeFirstName+" "+EmployeeLastName+" ("+EmployeeId+") for the month of "+MonthName+" - "+Year+" is Approved by "+SupervisorFirstName+" "+SupervisorLastName+".\n\n"
					+ "Approval Remarks: TESTING\n\n"
					+ "Note: The Shift request would be reopened for the whole month, employee can fill the roaster and resubmit the request again.\n\n"
					+ "Please follow the steps for claiming shift for entire month\n\n"
					+ "1. Ensure the entire months shift roster has been uploaded or rostered by Supervisor in Empulse\n\n"
					+ "2. Ensure your attendance for the entire month is regularized in Empulse\n\n"
					+ "3. Once the Empulse details are correct, then click on the + sign, and enter Project code / task code details for the days intended to claim shift\n\n"
					+ "4. For a day if on-call needs to be claimed then, shift should not be rostered through Empulse; if rostered connect with your supervisor to remove the roster for that particular day\n\n"
					+ "5. If any update has been done in Empulse, please wait for 48 hrs. For the data to reflect; if post 48 hrs. Data is not available then raise a helpdesk request.\n\n"
					+ "6. Ensure to select the project details and then click on submit button\n\n"
					+ "Thanks and Regards,\n"
					+ "Shift Allowance Admin\n\n"
			        + "Please do not response to this email. For any technical/functional issues,Kindly raise your service request using: BMC Remedy Service desk portal (Finance Application > Shift Allowance).";

			//System.out.println("Expected Body is:\n "+ExpectedBody);
			Assert.assertTrue(From.equalsIgnoreCase("noreply.shiftallowance.hr@capgemini.com"));
			Assert.assertTrue(ActualSubject.equalsIgnoreCase(ExpectedSubject));
			Assert.assertTrue(ActualBody.equals(ExpectedBody));
			Verified=true;

		} catch(IOException e){
			System.out.println("exception");
		}
		finally{
			HtmlToTxt();
		}
		return Verified;

	}
	
	
}
