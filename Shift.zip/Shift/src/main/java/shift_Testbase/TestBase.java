package shift_Testbase;


import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.sql.Connection;
import java.sql.ResultSet;
import java.io.FileInputStream;
import java.sql.PreparedStatement;
import java.util.List;
import java.util.Properties;
import java.util.concurrent.TimeUnit;

import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.ie.InternetExplorerDriver;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.remote.DesiredCapabilities;
import org.openqa.selenium.support.Color;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;

import shift_Pages.LoginPage;
import utilities.DB_Operation;


public class TestBase {
	 public static WebDriver driver;
	 public static Properties prop;
	 public static Properties propLocators;
	 public static File newTextFile;
	 public static String Mail_txt= System.getProperty("user.dir")+"\\src\\main\\java\\Files\\Mail.txt";
	 String Mail_html= System.getProperty("user.dir")+"\\src\\main\\java\\Files\\Mail.html";
	
	 //Read properties file
	public TestBase() {
		
		//Environment variables are stored in properties file
		try{
		  prop = new Properties();
			FileInputStream ip = new FileInputStream(System.getProperty("user.dir")
					+ "\\src\\main\\java\\configuration\\Environment.properties");
			prop.load(ip); 
			
			//locators are stored in properties file
			propLocators= new Properties();
			FileInputStream ipLocators = new FileInputStream(System.getProperty("user.dir")
					+ "\\src\\main\\java\\configuration\\locators.properties");
			propLocators.load(ipLocators); 
		} catch (IOException e) {
			
			e.printStackTrace();
		}
	
		}
	
	
	
	public static boolean isTestRunable(String TCName) throws IOException {
		// 1. check if test case exist
		// 2. check run mode
		// 3. execute the TC

		FileInputStream excel = new FileInputStream(System.getProperty("user.dir")
				+ "/src/main/java/testdata/TestCases.xlsx");
		XSSFWorkbook wb = new XSSFWorkbook(excel);
		XSSFSheet sh = wb.getSheet("TestCases");
		
		// total no of rows
		//int totalRows = sh.getPhysicalNumberOfRows();
		int totalRows =78;
		// total no of columns
		int totalColumn = sh.getRow(0).getPhysicalNumberOfCells();

		for (int i = 66; i < totalRows; i++)
			
		{
			if (sh.getRow(i).getCell(2).getStringCellValue().equals(TCName))
			{
				if (sh.getRow(i).getCell(3).getStringCellValue().equals("Y")) 
				{
					return true;
				}
			}
		}
		return false;

	}


	
	
//this method is for defining the browser and initialize the browser
	public static void StartBrowser(){

		
		String BrowseName = prop.getProperty("BrowseName");
		
		if(BrowseName.equalsIgnoreCase("firefox"))
		{
			driver= new FirefoxDriver();
		}
		
		else if(BrowseName.equalsIgnoreCase("chrome"))
		{
			String ChromePath= System.getProperty("user.dir")+"\\src\\main\\java\\Browser_Drivers\\chromedriver.exe";
			System.setProperty("webdriver.chrome.driver", ChromePath);
			ChromeOptions options= new ChromeOptions();
	        options.addArguments("--no-sandbox");
	        options.addArguments("--disable-dev-shm-usage");
			//options.addArguments("--incognito");
			//DesiredCapabilities capabalities= DesiredCapabilities.chrome();
			//capabalities.setCapability(ChromeOptions.CAPABILITY, options);
			driver= new ChromeDriver();
		}
		else if(BrowseName.equalsIgnoreCase("IE"))
		{
			//System.out.println(prop.getProperty("URL"));
			String IEPath= System.getProperty("user.dir") +"\\src\\main\\java\\Browser_Drivers\\IEDriverServer.exe";
			System.setProperty("webdriver.ie.driver", IEPath);
			DesiredCapabilities capability = DesiredCapabilities.internetExplorer();
			capability.setCapability(InternetExplorerDriver.INTRODUCE_FLAKINESS_BY_IGNORING_SECURITY_DOMAINS, true);
			capability.setCapability(InternetExplorerDriver.IGNORE_ZOOM_SETTING, true);
			capability.setCapability(InternetExplorerDriver.INITIAL_BROWSER_URL, "");
			driver= new InternetExplorerDriver();
			
			
		}
		
		
		driver.manage().window().maximize();
		driver.manage().deleteAllCookies();
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		driver.get(prop.getProperty("URL"));
		
		
		
	}
	
	
	
	
	public WebElement findelement(String locatorkey) 
	{

		return driver.findElement(By.xpath(propLocators.getProperty(locatorkey)));

	}
	
	public List<WebElement> findelements(String locatorkey)
	{

		return driver.findElements(By.xpath(propLocators.getProperty(locatorkey)));

	}
	
	public void Click(String locatorkey) throws Throwable
	{
		driver.findElement(By.xpath(propLocators.getProperty(locatorkey))).click();
	}
	public void SendData(String locatorkey,String Data){
		
		driver.findElement(By.xpath(propLocators.getProperty(locatorkey))).sendKeys(Data);
		
	}
	
	public void hover(String locatorkey)
	{
		Actions actions= new Actions(driver);
		actions.moveToElement(driver.findElement(By.xpath(propLocators.getProperty(locatorkey)))).build().perform();	
		
	}
	public void explicitwait(String xpahtKey)
	{
		WebDriverWait wait = new WebDriverWait(driver, 30);
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath(propLocators.getProperty(xpahtKey))));		
	} 
	
	public void explicitwaitele(WebElement ele)
	{
		WebDriverWait wait = new WebDriverWait(driver, 30);
		wait.until(ExpectedConditions.elementToBeClickable(ele));		
	} 
	
	public void waitElementNotVisible(String locatorkey)
	{
		WebDriverWait wait = new WebDriverWait(driver, 30);
		wait.until(ExpectedConditions.invisibilityOfElementLocated(By.xpath(propLocators.getProperty(locatorkey))));
	}
	
	public void explicitwaitClick(String xpahtKey) {
		WebDriverWait wait = new WebDriverWait(driver, 7000);
		wait.until(ExpectedConditions.elementToBeClickable(By.xpath(propLocators.getProperty(xpahtKey))));
	}
	
	// Dropdown
	public void Dropdown(String xpahtKey, String text) {
		Select dropdown = new Select(driver.findElement(By.xpath(propLocators.getProperty(xpahtKey))));
		List<WebElement> options = dropdown.getOptions();
		for(WebElement ouroption :options )
		{
			if(ouroption.getText().contains(text))
			{
				String VisibleText= ouroption.getText();
				//System.out.println(VisibleText);
				dropdown.selectByVisibleText(VisibleText);
			}
			
		}

	}
	//Clear TextBox
public void ClearData(String locatorkey){
		
		driver.findElement(By.xpath(propLocators.getProperty(locatorkey))).clear();
		
	}
//Dropdown by index
	public void DropdownIndex(String xpahtKey, int index) {
		Select dropdown = new Select(driver.findElement(By.xpath(propLocators.getProperty(xpahtKey))));
		dropdown.selectByIndex(index);
	}
	public List<WebElement> Dropdown_list(String xpahtKey, String text) {
		Select dropdown = new Select(driver.findElement(By.xpath(propLocators.getProperty(xpahtKey))));
		dropdown.selectByVisibleText(text);
		List<WebElement> a = dropdown.getOptions();
		return a;
	}
	//Element displayed or not
	public boolean isDisplayed(String locatorkey)
	{
		return driver.findElement(By.xpath(propLocators.getProperty(locatorkey))).isDisplayed();
	}
	//MESSAGE DISLAYED OR NOT
	public boolean isTextDisplayed(String Text)
	{
		
		return driver.findElements(By.xpath("//label[text()="+"'"+Text+"'"+"]")).size()!=0;
	}
	
	//Scroll Page To view
	public void scrollpageToView(String locatorkey) {
		JavascriptExecutor js = (JavascriptExecutor) driver;

		 js.executeScript("arguments[0].scrollIntoView();",driver.findElement(By.xpath(propLocators.getProperty(locatorkey))) );//scrolling the page to view

	}
	
	// Vertical scroll - up by 150 pixels
	public void scrollpageup() {
		JavascriptExecutor js = (JavascriptExecutor) driver;

		js.executeScript("scroll(400,0)");
	}

	// Scroll bottom of the page
	public void scrollpagebottom() {
		((JavascriptExecutor) driver).executeScript("window.scrollTo(0, document.body.scrollHeight)");

	}
	
	//Checking if element is present
	public Boolean isElementPresent(String locatorkey)
	{
		Boolean Element =driver.findElements(By.xpath(propLocators.getProperty(locatorkey))).size()!=0;
		return Element;
	}
	
	//Getting the colour in hex
	public String getColour(String locatorkey)
	{
		 String color =driver.findElement(By.xpath(propLocators.getProperty(locatorkey))).getCssValue("background-color");
		 String ActualColour = Color.fromString(color).asHex();
		 return ActualColour;
	}
	
	public static String[] ReadEmailFromDB() throws Throwable
	{
		DB_Operation DB= new DB_Operation();
		Connection conn=DB.ConnectingToDB();
		PreparedStatement  PstmtSelect= conn.prepareStatement( "SELECT  TOP 1 * FROM ["+DB.DBName+"].[dbo].[tblLogMailNotification] ORDER BY SENTDATE DESC"); 
		ResultSet VerifyEmail= PstmtSelect.executeQuery( );
		String EmailDetails[] = new String[3];
		  while(VerifyEmail.next())
		  {
			  EmailDetails[0]=VerifyEmail.getString("FromId");
			  EmailDetails[1]=VerifyEmail.getString("Subject");
			  EmailDetails[2]= VerifyEmail.getString("HtmlBody");
			// System.out.println("HtmlBody is\t"+ HtmlBody);
		   }    
		  return EmailDetails;
	}
	
	
	public static void TxtToHtml() throws Throwable{
		 
     	//System.out.println(text);
        newTextFile = new File(Mail_txt);

        FileWriter fw = new FileWriter(newTextFile);
        fw.write(ReadEmailFromDB()[2]);
        fw.close();
        Path source = Paths.get(Mail_txt);
		Files.move(source, source.resolveSibling("Mail.html"));
	 }
	
	   public void HtmlToTxt() throws IOException{		 
     	

		 Path source1 = Paths.get(Mail_html);
			Files.move(source1, source1.resolveSibling("Mail.txt"));
			PrintWriter writer = new PrintWriter(newTextFile);
			writer.print("");
			writer.close();			 
			 }
	
	public static void MailInitialiser() throws Throwable{
		
		TxtToHtml();
	
		String BrowseName = prop.getProperty("BrowseName");
		
		if(BrowseName.equalsIgnoreCase("firefox"))
		{
			driver= new FirefoxDriver();
		}
		
		else if(BrowseName.equalsIgnoreCase("chrome"))
		{
			String ChromePath= System.getProperty("user.dir")+"\\src\\main\\java\\Browser_Drivers\\chromedriver.exe";
			System.setProperty("webdriver.chrome.driver", ChromePath);
			driver= new ChromeDriver();
			
		}
		else if(BrowseName.equalsIgnoreCase("IE"))
		{
			String IEPath= System.getProperty("user.dir") +"\\src\\main\\java\\Browser_Drivers\\IEDriverServer.exe";
			System.setProperty("webdriver.ie.driver", IEPath);
			driver= new InternetExplorerDriver();
		}
		
		driver.manage().window().maximize();
		driver.manage().deleteAllCookies();
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
        driver.get(System.getProperty("user.dir")+"\\src\\main\\java\\Files\\Mail.html");
		
		
	}
	
	public String[] PersonalDetails(String EmpId) throws Exception
	{
		String Details[]= new String[5];
		DB_Operation DB= new DB_Operation();
		Connection conn=DB.ConnectingToDB();
		PreparedStatement  PstmtSelect= conn.prepareStatement( "select * from ["+DB.DBName+"].[dbo].[tblEmployeeMaster] where EmployeeID=?"); 
		PstmtSelect.setString( 1, EmpId);
		ResultSet EmployeeDetails= PstmtSelect.executeQuery( );
		while(EmployeeDetails.next())
		{
			Details[0] = EmployeeDetails.getString("EmailAddress");
			Details[1]= EmployeeDetails.getString("EmployeeID");
			Details[2]= EmployeeDetails.getString("FirstName");
			Details[3]= EmployeeDetails.getString("LastName");
			Details[4]= EmployeeDetails.getString("SupervisorID");
			//System.out.println(SupervisorEmployeeId);
		} 
		return Details;
		
	}
	
	
	
	
	
	
	
	
	
	
	
	
}
