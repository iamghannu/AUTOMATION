package utilities;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import shift_Testbase.TestBase;


public class DB_Operation extends TestBase {
	
public static Connection con;
public static Read_Excel EmpulseAttData=new Read_Excel();
Read_Excel ExcelShiftDetailsData= new Read_Excel();;
public String DBName;

    public  Connection ConnectingToDB() throws Exception
    {
    	DBName=prop.getProperty("DBName");
	Class.forName("com.microsoft.sqlserver.jdbc.SQLServerDriver");
	//System.out.println("Driver Loaded");
	  con = DriverManager.getConnection("jdbc:jtds:sqlserver://10.102.22.136:1433;database=In-PNQ-DSQLDB01/DBName;integratedSecurity=true", "test_ShiftAllowance","test_ShiftAllowance");
   // System.out.println("CONNECTION SUCCESS");
    return(con);
    
   }

	
	public void InsertingDataEmpulseAtt(String SheetName) throws Throwable
	{
		ConnectingToDB();
		System.out.println("Empulse Data is being created, Kindly Wait "); 
         int NoOfDays= EmpulseAttData.NoOfRow(SheetName);
		for(int i=2;i<NoOfDays;i++)
		{
		    int index=0;
			PreparedStatement ps= con.prepareStatement("Insert into ["+DBName+"].[dbo].[tbl_Fact_EmpulseAttendance](EmpID,EmpName,Org,SBU,BU,SubBU,LocName,SwipeLocation,JobTitName,Entity,PeopleGroup,Billability,DssFunction,Description,InOutDate,PunchInTime,PunchOutTime,ActHrsWorked,AttendanceClassification,ShiftCode,ShiftID,Globalgroupid,Year,Month,Date) values(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?) ") ;
			for(int j=0;j<25;j++)
			{
				 index=index+1;			   
				 ps.setString(index, EmpulseAttData.getData(SheetName, i,j) );
			}
			 ps.executeUpdate();
		}
 		con.close();
 		System.out.println("Empulse Data Creation is Complete and thank you for your Patience");
	}
	
	public void InsertingDataShiftDetails(String SheetName) throws Throwable
	{
		ConnectingToDB();
		System.out.println("Shift Data is being created, Kindly Wait");
        int NoOfDays= ExcelShiftDetailsData.NoOfRow(SheetName);
		for(int i=2;i<NoOfDays;i++)
		{
		    int index=0;
			PreparedStatement ps= con.prepareStatement("INSERT INTO ["+DBName+"].[dbo].[tbl_Fact_EmpulseShiftDetails]([EmpID],[ShiftDate],[ShiftID],[ShiftName],[ShiftCode],[Year],[Month],[Date],[GlobalGroupID])VALUES(?,?,?,?,?,?,?,?,?)") ;
			for(int j=0;j<9;j++)
			{
				 index=index+1;				  
				 ps.setString(index, ExcelShiftDetailsData.getData(SheetName, i,j));
			}
			 ps.executeUpdate();
		}
		con.close();
		System.out.println("Shift Data Creation is Complete and thank you for your Patience");
	}
	
	
	  
	    
	    public void DeletingData() throws Throwable
		{
	        ConnectingToDB();
		    PreparedStatement  PstmtEmpAttn=con.prepareStatement("DELETE FROM   ["+DBName+"].[dbo].[tbl_Fact_EmpulseAttendance]  where EmpID=? and Year =? and Month=? ");
		    PstmtEmpAttn.setString( 1, EmpulseAttData.getData("EmpulseAttendance", 2, 0)); 
		    PstmtEmpAttn.setString( 2, EmpulseAttData.getData("EmpulseAttendance", 2, 22)); 
		    PstmtEmpAttn.setString( 3, EmpulseAttData.getData("EmpulseAttendance", 2, 23));
		    PstmtEmpAttn.executeUpdate();
		    PreparedStatement PstmtShift=con.prepareStatement("DELETE FROM   ["+DBName+"].[dbo].[tbl_Fact_EmpulseShiftDetails]  where EmpID=? and Year =? and Month=? ");
		    PstmtShift.setString( 1, EmpulseAttData.getData("EmpulseAttendance", 2 , 0)); 
		    PstmtShift.setString( 2, EmpulseAttData.getData("EmpulseAttendance", 2, 22)); 
		    PstmtShift.setString( 3, EmpulseAttData.getData("EmpulseAttendance", 2, 23));
		    PstmtShift.executeUpdate();
		    con.close();
		}
	    
	    public void DeletingRequestDetails() throws Throwable
	    {
	         ConnectingToDB();
		     PreparedStatement pstmt0=con.prepareStatement("delete from ["+DBName+"].[dbo].[tblShiftAllowanceTransaction] where shiftdetailsid IN(select shiftdetailsid from ["+DBName+"].[dbo].[tblshiftrequestdetails] where requestid IN(select requestid  from ["+DBName+"].[dbo].[tblshiftrequest] where employeeid=?  and year=? and month=?))" );
		     pstmt0.setString( 1, EmpulseAttData.getData("EmpulseAttendance", 2, 0)); 
		     pstmt0.setString( 2, EmpulseAttData.getData("EmpulseAttendance", 2, 22)); 
		     pstmt0.setString( 3, EmpulseAttData.getData("EmpulseAttendance", 2, 23));
		     pstmt0.executeUpdate();
		     PreparedStatement pstmt=con.prepareStatement("delete from ["+DBName+"].[dbo].[tblshiftrequestdetails] where requestid IN(select requestid  from ["+DBName+"].[dbo].[tblshiftrequest] where employeeid=?  and year=? and month=?) " );
		     pstmt.setString( 1, EmpulseAttData.getData("EmpulseAttendance", 2, 0)); 
		     pstmt.setString( 2, EmpulseAttData.getData("EmpulseAttendance", 2, 22)); 
		     pstmt.setString( 3, EmpulseAttData.getData("EmpulseAttendance", 2, 23));
		     pstmt.executeUpdate();
		     PreparedStatement pstmt2=con.prepareStatement("delete from ["+DBName+"].[dbo].[tblshiftrequest] where requestid IN(select requestid  from ["+DBName+"].[dbo].[tblshiftrequest] where employeeid=?  and year=? and month=?)");
		     pstmt2.setString( 1, EmpulseAttData.getData("EmpulseAttendance", 2, 0)); 
		     pstmt2.setString( 2, EmpulseAttData.getData("EmpulseAttendance", 2, 22)); 
		     pstmt2.setString( 3, EmpulseAttData.getData("EmpulseAttendance", 2, 23));
		     pstmt2.executeUpdate();
		     con.close();
	    }
	    
	    public String FindStatusId() throws Throwable
	    {
	    	  ConnectingToDB();
	    	  PreparedStatement  PstmtSelect= con.prepareStatement( "select StatusId from ["+DBName+"].[dbo].[tblshiftrequest] where EmployeeId =? and Year =? and Month =?"); 
	    	  //System.out.println(EmpulseAttData.getData("EmpulseAttendance", 2, 0));
	    	  PstmtSelect.setString( 1, EmpulseAttData.getData("EmpulseAttendance", 2, 0));
			  PstmtSelect.setString( 2, EmpulseAttData.getData("EmpulseAttendance", 2, 22));
			  PstmtSelect.setString( 3, EmpulseAttData.getData("EmpulseAttendance", 2, 23));
			  ResultSet Verify_StatusId= PstmtSelect.executeQuery( );
			  String StatusId=null;
			  while(Verify_StatusId.next())  
			  {
				  StatusId = Verify_StatusId.getString("StatusId");
			   }
			  con.close();
			return StatusId;   	  
	    }
	    
	    public List VerifyShiftRatesAndCount() throws Throwable
	    {
	    	
	    	  ConnectingToDB();
	    	  List Rates= new ArrayList<>();
	    	  PreparedStatement  PstmtSelect= con.prepareStatement( "select * from ["+DBName+"].[dbo].[tblshiftrequestdetails] where RequestID IN(select RequestID from ["+DBName+"].[dbo].[tblshiftrequest] where EmployeeId =? and Year =? and Month =?)");
	    	  PstmtSelect.setString( 1, EmpulseAttData.getData("EmpulseAttendance", 2, 0));
			  PstmtSelect.setString( 2, EmpulseAttData.getData("EmpulseAttendance", 2, 22));
			  PstmtSelect.setString( 3, EmpulseAttData.getData("EmpulseAttendance", 2, 23));
			  ResultSet Verify_Rates= PstmtSelect.executeQuery();
			  while(Verify_Rates.next())  
			  {				  
				  Rates.add(Verify_Rates.getString("TotalMSShift"));
				  Rates.add(Verify_Rates.getString("AdjustedMSAmount"));
				  Rates.add(Verify_Rates.getString("TotalAFShift"));
				  Rates.add(Verify_Rates.getString("AdjustedASAmount"));
				  Rates.add(Verify_Rates.getString("TotalNSShift"));
				  Rates.add(Verify_Rates.getString("AdjustedNSAmount"));
				  Rates.add(Verify_Rates.getString("TotalONCShift"));
				  Rates.add(Verify_Rates.getString("AdjustedOCAAmount"));
				  Rates.add(Verify_Rates.getString("TotalONCHShift"));
				  Rates.add(Verify_Rates.getString("AdjustedOCAHAmount"));
				  Rates.add(Verify_Rates.getString("TotalAmount"));				  
			   }
			  con.close();	    	
			return Rates;	    	
	    }
	    
	    public String PMEMPID() throws Throwable
	    {
	    	ConnectingToDB();
	    	String ProjectManagerEmployeeId=null;
	    	PreparedStatement  PstmtSelect3= con.prepareStatement( "SELECT L1Approver FROM ["+DBName+"].[dbo].[tblprojectmaster] where projectnumber IN ( SELECT ProjectNumber from ["+DBName+"].[dbo].[tblshiftrequestdetails] where RequestID IN (select RequestID from ["+DBName+"].[dbo].[tblshiftrequest] where EmployeeId =? and Year =? and Month =?))"); 
			PstmtSelect3.setString( 1, EmpulseAttData.getData("EmpulseAttendance", 2, 0));
			PstmtSelect3.setString( 2, EmpulseAttData.getData("EmpulseAttendance", 2, 22));
			PstmtSelect3.setString( 3, EmpulseAttData.getData("EmpulseAttendance", 2, 23));
			ResultSet L1Approver= PstmtSelect3.executeQuery( );
			while(L1Approver.next())
			{
				 ProjectManagerEmployeeId = L1Approver.getString("L1Approver");
			} 
			con.close();
			return ProjectManagerEmployeeId;    	
	    }
	    
	    
	    public String RequiredDetails(String EmpId,String Attribute) throws Exception
	    {
	    	ConnectingToDB();String Details="";
	    	PreparedStatement  PstmtSelect3= con.prepareStatement( "SELECT * FROM ["+DBName+"].[dbo].[tblEmployeeMaster] where EmployeeID = ?"); 
			PstmtSelect3.setString( 1,EmpId );
			ResultSet Result= PstmtSelect3.executeQuery();
			while(Result.next())
			{
				Details = Result.getString(Attribute);
			} 
			con.close();
			return Details;	    	
	    }
	    
	    
	    
}


