package utilities;

import java.io.File;
import java.io.FileInputStream;



import org.apache.poi.ss.usermodel.DataFormatter;
import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

import shift_Testbase.TestBase;



public class Read_Excel extends TestBase {
	
	//XSSFWorkbook wb;
	String DataPath = System.getProperty("user.dir")
			+ prop.getProperty("Excel_data_path");
			
		
	
	public String getData(String SheName,int row,int col ) throws Throwable {
		File fis1 = new File(DataPath);
		FileInputStream src1 = new FileInputStream (fis1);
		XSSFWorkbook wb= new XSSFWorkbook(src1);	
		XSSFSheet Sheet1 = wb.getSheet(SheName);
		XSSFCell cell = Sheet1.getRow(row).getCell(col);
		DataFormatter formatter = new DataFormatter();
		String data=formatter.formatCellValue(cell);
		//System.out.println(data);
		return data;
	}
	
	
	public int NoOfRow(String SheetName) throws Throwable 
	{
		File fis1 = new File(DataPath);
		FileInputStream src1 = new FileInputStream (fis1);
		XSSFWorkbook wb= new XSSFWorkbook(src1);	
		XSSFSheet Sheet = wb.getSheet(SheetName);
		//System.out.println("No of Rows to be input is:\t"+ Sheet.getPhysicalNumberOfRows());
		return(Sheet.getPhysicalNumberOfRows());
	}
}
