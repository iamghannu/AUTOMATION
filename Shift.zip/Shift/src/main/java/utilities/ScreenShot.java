package utilities;

import java.io.File;

import org.apache.commons.io.FileUtils;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;

import shift_Testbase.TestBase;

public class ScreenShot extends TestBase{
	
	static String LOCATION_OF_SCREENSHOT = System.getProperty("user.dir")+"\\Screenshot\\";

	public void CaptureScrShot(String ScrshotName)
	{
		
		
		try {
			TakesScreenshot ts = (TakesScreenshot) driver;
			File source = ts.getScreenshotAs(OutputType.FILE);
			String Destination = LOCATION_OF_SCREENSHOT+ScrshotName+".png";
			FileUtils.copyFile(source, new File(Destination));
			
			System.out.println("Screenshot Taken");
			//return Destination;
		} catch (Exception e) {
			
			System.out.println("Exception while taking Screenshot "+e.getMessage());
			//return e.getMessage();
		} 
		
		
		
		
	}
	
	
	
}
