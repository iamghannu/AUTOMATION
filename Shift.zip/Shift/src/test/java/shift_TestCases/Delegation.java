package shift_TestCases;

import java.sql.Connection;
import java.util.Set;

import org.openqa.selenium.By;
import org.testng.Assert;
import org.testng.ITestResult;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import shift_Pages.Apply_Shift_Page;
import shift_Pages.HomePage;
import shift_Pages.LoginPage;
import shift_Pages.PMApprovalPage;
import shift_Pages.ReopenRequestPage;
import shift_Pages.SupervisorApprovalPage;
import shift_Testbase.TestBase;
import utilities.DB_Operation;
import utilities.Read_Excel;
import utilities.ScreenShot;

public class Delegation extends TestBase {

	DB_Operation DB;LoginPage login; HomePage home; Apply_Shift_Page apply; Read_Excel Data; ScreenShot screenshot; Connection conn;SupervisorApprovalPage Sup;
	String uid; String pass;String supempid;String SupNTUserID;PMApprovalPage PM;ShiftRequestWorkFlow Flow; ReopenRequestPage ReopenReq;String PMEmpid; String PMNTUserID;
	
	
	
	@BeforeTest
	public void CreatingData() throws Throwable
	{		
		//Creating objects for the pages of application
		login=new LoginPage();home = new HomePage();apply = new Apply_Shift_Page(); Sup=new SupervisorApprovalPage();
		 PM = new PMApprovalPage();Flow= new ShiftRequestWorkFlow();ReopenReq=new ReopenRequestPage();
		
		//Creating objects for UTILITY CLASSES
		Data= new Read_Excel();DB= new DB_Operation();conn=DB.ConnectingToDB();screenshot = new ScreenShot();
		
		uid = Data.getData("LogInData", 1, 0);// storing the username;
		pass = Data.getData("LogInData", 1, 1);//storing the password
		supempid= DB.RequiredDetails(Data.getData("EmpulseAttendance", 2, 0), "SupervisorID");
		SupNTUserID=DB.RequiredDetails(supempid, "NTUserID");
		
	}
	
	
	@BeforeMethod
	public void setUp() throws Exception {
		StartBrowser();		
	}
	
	
	@Test(priority=1, enabled = false,description="Verify that the tabs Home,Approvals,Reports and Delegate is displayed in the home page, to any SUPERVISOR.",invocationCount=1)
	public void TabsForSupervisor() throws Throwable
	{
		login.LogIn(SupNTUserID, pass);	
        Assert.assertTrue(this.isDisplayed("Home"));
        Assert.assertTrue(this.isDisplayed("Approval"));
        Assert.assertTrue(this.isDisplayed("Reports"));
        Assert.assertTrue(this.isDisplayed("Delegate"));	
	}
	
	
	@Test(priority=2, enabled = false,description="Verify that the tabs Home,Approvals,Reports and Delegate is displayed in the home page, to any PROJECT MANAGER.",invocationCount=1)
	public void TabsForPM() throws Throwable
	{
		PMEmpid=DB.PMEMPID();
		PMNTUserID=DB.RequiredDetails(PMEmpid, "NTUserID");
		login.LogIn(PMNTUserID, pass);
        Assert.assertTrue(this.isDisplayed("Home"));
        Assert.assertTrue(this.isDisplayed("Approval"));
        Assert.assertTrue(this.isDisplayed("Reports"));
        Assert.assertTrue(this.isDisplayed("PMDelegate"));	
	}
	
	@Test(priority=3, enabled = false,description="Verify that the fields Name,Emp.ID,Employee Name,Start Date,End Date,Add and Clear should be displayed in the DELEGATE FORM in the page DELEGATE",invocationCount=1)
	public void FieldsInDelgatePage() throws Throwable
	{
		login.LogIn(SupNTUserID, pass);
        home.GoSupDelegatePage();	
        Assert.assertTrue(this.isDisplayed("SupName"));
        Assert.assertTrue(this.isDisplayed("ProxyEmployeeId"));
        Assert.assertTrue(this.isDisplayed("ProxyEmployeeName"));
        Assert.assertTrue(this.isDisplayed("StartDate"));	
        Assert.assertTrue(this.isDisplayed("EndDate"));
        Assert.assertTrue(this.isDisplayed("AddProxyEmp"));
        Assert.assertTrue(this.isDisplayed("ClearProxyEmp"));	      
	}
	
	
	
	
	
	@AfterMethod(enabled=true)
	public void tearDown(ITestResult result) throws Exception {
		
		//Taking Screenshots when test cases FAIL
		if (ITestResult.FAILURE == result.getStatus()) {
			String name =result.getName();
			screenshot.CaptureScrShot(name);
		}
		
		driver.quit();
	}
	
	
	
}
