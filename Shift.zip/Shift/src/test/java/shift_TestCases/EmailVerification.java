package shift_TestCases;

import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

import org.openqa.selenium.By;
import org.testng.Assert;
import org.testng.ITestResult;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import shift_Pages.Apply_Shift_Page;
import shift_Pages.HomePage;
import shift_Pages.LoginPage;
import shift_Testbase.TestBase;
import utilities.DB_Operation;
import utilities.Read_Excel;
import utilities.ScreenShot;

public class EmailVerification extends TestBase {

	DB_Operation DB;
	LoginPage login;   HomePage home;  Apply_Shift_Page apply;   Read_Excel Data; ScreenShot screenshot;
	Connection conn; 
	String uid;  String pass;
	
	

	@BeforeTest
	public void CreatingData() throws Throwable {
		DB= new DB_Operation();
		DB.InsertingDataShiftDetails("ShiftDetails");// INSERTING DATA INTO SHIFTDETAILS TABLE											 
		DB.InsertingDataEmpulseAtt("EmpulseAttendance");// INSERING DATA INTO EMPULSEATTENDANCE TABLE											 
		Data= new Read_Excel();
		login=new LoginPage();
		home = new HomePage();
		apply = new Apply_Shift_Page(); screenshot = new ScreenShot();
		conn=DB.ConnectingToDB();
		uid = Data.getData("LogInData", 1, 0);// storing the username;
		pass = Data.getData("LogInData", 1, 1);//storing the password
	}
	
	
	@BeforeMethod
	public void setUp() throws Exception {
		StartBrowser();
	}
	
	@Test(priority=1, enabled= true, description="Verify that SUPERVISOR receives mail in correct format when a employee raises a request.",invocationCount=1)
	public void VerifyEmailOnSubmissionOfRequest() throws Throwable
	{
		//---- WRITE CODE TO SUBMIT A REQUEST-----
		
		
		//----------------------------------------
		
		String From=null;String ActualSubject=null; String ExpectedSubject=null;
		String EmployeeId=Data.getData("EmpulseAttendance", 2, 0);
		String Year = Data.getData("EmpulseAttendance", 2, 22); String MonthName= Apply_Shift_Page.months[Integer.parseInt(Data.getData("EmpulseAttendance", 2, 23))]; 
		String EmployeeEmailId = PersonalDetails(EmployeeId)[0];
		EmployeeId= PersonalDetails(EmployeeId)[1];
		String	EmployeeFirstName= PersonalDetails(EmployeeId)[2];
		String	EmployeeLastName= PersonalDetails(EmployeeId)[3];
		String SupervisorEmployeeId= PersonalDetails(EmployeeId)[4];
		String SupervisorEmailId = PersonalDetails(SupervisorEmployeeId)[0];
		String SupervisorFirstName= PersonalDetails(SupervisorEmployeeId)[2];
		String SupervisorLastName= PersonalDetails(SupervisorEmployeeId)[3];
		From = ReadEmailFromDB()[0];
		ActualSubject= ReadEmailFromDB()[1];
		//System.out.println(ActualSubject); 
		ExpectedSubject="Shift Allowance pending for approval for : "+EmployeeFirstName+" "+EmployeeLastName+" ("+EmployeeId+")";
		//System.out.println(ExpectedSubject);

		try {
			MailInitialiser();
			String ActualBody= driver.findElement(By.xpath("/html/body")).getText();
			String ExpectedBody="Actual receipeints="+SupervisorEmailId+"\n"
					+ "Actual CCs="+EmployeeEmailId+";vinayak-vasant.sonkaramble@capgemini.com\n"
					+ "Actual BCCs=\n"
					+ "Dear " +SupervisorFirstName+" "+SupervisorLastName+",\n\n"
					+ "Kindly note the shift allowance submitted by " +EmployeeFirstName+" "+EmployeeLastName+" ("+EmployeeId+") for the month of "+MonthName+" - "+Year+" is waiting for your approval.\n\n"
					+ "Please click Here to Approve / Reject.\n\n\n"
					+ "Thanks and Regards,\n"
					+ "Shift Allowance Admin\n\n"
					+ "Please do not response to this email. For any technical/functional issues,Kindly raise your service request using: BMC Remedy Service desk portal (Finance Application > Shift Allowance).";
			Assert.assertTrue(From.equalsIgnoreCase("noreply.shiftallowance.hr@capgemini.com"));
			Assert.assertTrue(ActualSubject.equalsIgnoreCase(ExpectedSubject));
			Assert.assertTrue(ActualBody.equals(ExpectedBody));


		} catch(IOException e){
			System.out.println("exception");
		}
		finally{
			HtmlToTxt();
		}
	}
	
	
	
	
	@Test(priority=2, enabled= true, description="Verify that PM receives mail in correct format when a request raised by employee is APPROVED by SUPERVISOR.",invocationCount=1)
	public void VerifyEmailOnApprovalBySupervisor() throws Throwable
	{
		//---- WRITE CODE TO SUBMIT A REQUEST AND GET IT APPROVED BY SUPERVISOR-----
		
		
		//----------------------------------------
		
		String From=null;String ActualSubject=null; String ExpectedSubject=null;
		String ProjectManagerEmployeeId=null;
		String EmployeeId=Data.getData("EmpulseAttendance", 2, 0);
		String Year = Data.getData("EmpulseAttendance", 2, 22); String MonthName= Apply_Shift_Page.months[Integer.parseInt(Data.getData("EmpulseAttendance", 2, 23))]; 
		String EmployeeEmailId = PersonalDetails(EmployeeId)[0];
		EmployeeId= PersonalDetails(EmployeeId)[1];
		String	EmployeeFirstName= PersonalDetails(EmployeeId)[2];
		String	EmployeeLastName= PersonalDetails(EmployeeId)[3];
		String SupervisorEmployeeId= PersonalDetails(EmployeeId)[4];
		String SupervisorEmailId = PersonalDetails(SupervisorEmployeeId)[0];
		String SupervisorFirstName = PersonalDetails(SupervisorEmployeeId)[2];
		String SupervisorLastName = PersonalDetails(SupervisorEmployeeId)[3];
		PreparedStatement  PstmtSelect3= conn.prepareStatement( "SELECT L1Approver FROM [GshiftAllowance_SIT].[dbo].[tblprojectmaster] where projectnumber IN ( SELECT ProjectNumber from [GshiftAllowance_SIT].[dbo].[tblshiftrequestdetails] where RequestID IN (select RequestID from [GshiftAllowance_SIT].[dbo].[tblshiftrequest] where EmployeeId =? and Year =? and Month =?))"); 
		PstmtSelect3.setString( 1, Data.getData("EmpulseAttendance", 2, 0));
		PstmtSelect3.setString( 2, Data.getData("EmpulseAttendance", 2, 22));
		PstmtSelect3.setString( 3, Data.getData("EmpulseAttendance", 2, 23));
		ResultSet L1Approver= PstmtSelect3.executeQuery( );
		while(L1Approver.next())
		{
			ProjectManagerEmployeeId = L1Approver.getString("L1Approver");
		} 
		String ProjectManagerEmailId=PersonalDetails(ProjectManagerEmployeeId)[0];
		String ProjectManagerFirstName= PersonalDetails(ProjectManagerEmployeeId)[2];
		String ProjectManagerLastName= PersonalDetails(ProjectManagerEmployeeId)[3];

		From = ReadEmailFromDB()[0];
		ActualSubject= ReadEmailFromDB()[1];
		//System.out.println(ActualSubject); 
		ExpectedSubject="Shift Allowance Approved for : "+EmployeeFirstName+" "+EmployeeLastName+" ("+EmployeeId+")";
		//System.out.println(ExpectedSubject);
		
		
		try {
			MailInitialiser();
			String ActualBody= driver.findElement(By.xpath("/html/body")).getText();
			String ExpectedBody="Actual receipeints="+ProjectManagerEmailId+"\n"
					+ "Actual CCs="+SupervisorEmailId+";"+EmployeeEmailId+"\n"
					+ "Actual BCCs=\n"
					+ "Dear " +ProjectManagerFirstName+" "+ProjectManagerLastName+",\n\n"
					+ "Kindly note the shift allowance submitted by " +EmployeeFirstName+" "+EmployeeLastName+" ("+EmployeeId+") for the month of "+MonthName+" - "+Year+" is approved by "+SupervisorFirstName +" "+SupervisorLastName+" is now pending for your approval.\n\n"
					+ "Thanks and Regards,\n"
					+ "Shift Allowance Admin\n\n"
					+ "Please do not response to this email. For any technical/functional issues,Kindly raise your service request using: BMC Remedy Service desk portal (Finance Application > Shift Allowance).";
			Assert.assertTrue(From.equalsIgnoreCase("noreply.shiftallowance.hr@capgemini.com"));
			Assert.assertTrue(ActualSubject.equalsIgnoreCase(ExpectedSubject));
			Assert.assertTrue(ActualBody.equals(ExpectedBody));

		} catch(IOException e){
			System.out.println("exception");
		}
		finally{
			HtmlToTxt();
		}
		
	}
	
	
	@Test(priority=3, enabled= true, description="Verify that EMPLOYEE receives mail in correct format when the request raised by employee is REJECTED by SUPERVISOR.",invocationCount=1)
	public void VerifyEmailOnRejectionBySupervisor() throws Throwable
	{
		//---- WRITE CODE TO SUBMIT A REQUEST AND GET IT Rejected BY SUPERVISOR-----
		
		
				//----------------------------------------
		
		String From=null;String ActualSubject=null; String ExpectedSubject=null;
		String EmployeeId=Data.getData("EmpulseAttendance", 2, 0);
		String Year = Data.getData("EmpulseAttendance", 2, 22); String MonthName= Apply_Shift_Page.months[Integer.parseInt(Data.getData("EmpulseAttendance", 2, 23))]; 
		String EmployeeEmailId = PersonalDetails(EmployeeId)[0];
		EmployeeId= PersonalDetails(EmployeeId)[1];
		String	EmployeeFirstName= PersonalDetails(EmployeeId)[2];
		String	EmployeeLastName= PersonalDetails(EmployeeId)[3];
		String SupervisorEmployeeId= PersonalDetails(EmployeeId)[4];
		String SupervisorEmailId = PersonalDetails(SupervisorEmployeeId)[0];
		String SupervisorFirstName = PersonalDetails(SupervisorEmployeeId)[2];
		String SupervisorLastName = PersonalDetails(SupervisorEmployeeId)[3];
		

		From = ReadEmailFromDB()[0];
		ActualSubject= ReadEmailFromDB()[1];
		//System.out.println(ActualSubject); 
		ExpectedSubject="Shift Allowance Rejected by : "+SupervisorFirstName+" "+SupervisorLastName+"";
		//System.out.println(ExpectedSubject);
		
		
		try {
			MailInitialiser();
			String ActualBody= driver.findElement(By.xpath("/html/body")).getText();
			String ExpectedBody="Actual receipeints="+EmployeeEmailId+"\n"
					+ "Actual CCs="+SupervisorEmailId+"\n"
					+ "Actual BCCs=\n"
					+ "Dear " +EmployeeFirstName+" "+EmployeeLastName+",\n\n"
					+ "Kindly note the shift allowance submitted by " +EmployeeFirstName+" "+EmployeeLastName+" ("+EmployeeId+") for the month of "+MonthName+" - "+Year+" is approved by "+SupervisorFirstName +" "+SupervisorLastName+" is Rejected by "+SupervisorFirstName +""+SupervisorLastName+"\n\n"
					+ "Rejection Remarks: rejected\n"
					+ "Note: The Shift request would be rejected for the whole month, employee can fill the roaster and resubmit the request again. Thanks and Regards,\n"
					+ "Shift Allowance Admin\n\n"
					+ "Please do not response to this email. For any technical/functional issues,Kindly raise your service request using: BMC Remedy Service desk portal (Finance Application > Shift Allowance).";
			Assert.assertTrue(From.equalsIgnoreCase("noreply.shiftallowance.hr@capgemini.com"));
			Assert.assertTrue(ActualSubject.equalsIgnoreCase(ExpectedSubject));
			Assert.assertTrue(ActualBody.equals(ExpectedBody));

		} catch(IOException e){
			System.out.println("exception");
		}
		finally{
			HtmlToTxt();
		}
		
	}

	
	@Test(priority=4, enabled= false, description="Verify that EMPLOYEE receives mail in correct format when the request raised by employee is REJECTED by PM",invocationCount=1)
	public void VerifyEmailOnRejectedByPM() throws Throwable
	{
		//---- WRITE CODE TO SUBMIT A REQUEST AND GET IT APPROVED BY SUPERVISOR AND THEN GET IT APPROVED BY PM-----
		
		
				//----------------------------------------
		
		
		String From=null;String ActualSubject=null; String ExpectedSubject=null;
		String ProjectManagerEmployeeId=null;
		String EmployeeId=Data.getData("EmpulseAttendance", 2, 0);
		String Year = Data.getData("EmpulseAttendance", 2, 22); String MonthName= Apply_Shift_Page.months[Integer.parseInt(Data.getData("EmpulseAttendance", 2, 23))]; 
		String EmployeeEmailId = PersonalDetails(EmployeeId)[0];
		EmployeeId= PersonalDetails(EmployeeId)[1];
		String	EmployeeFirstName= PersonalDetails(EmployeeId)[2];
		String	EmployeeLastName= PersonalDetails(EmployeeId)[3];
		String SupervisorEmployeeId= PersonalDetails(EmployeeId)[4];
		String SupervisorEmailId = PersonalDetails(SupervisorEmployeeId)[0];

		PreparedStatement  PstmtSelect3= conn.prepareStatement( "SELECT L1Approver FROM [GshiftAllowance_SIT].[dbo].[tblprojectmaster] where projectnumber IN ( SELECT ProjectNumber from [GshiftAllowance_SIT].[dbo].[tblshiftrequestdetails] where RequestID IN (select RequestID from [GshiftAllowance_SIT].[dbo].[tblshiftrequest] where EmployeeId =? and Year =? and Month =?))"); 
		PstmtSelect3.setString( 1, Data.getData("EmpulseAttendance", 2, 0));
		PstmtSelect3.setString( 2, Data.getData("EmpulseAttendance", 2, 22));
		PstmtSelect3.setString( 3, Data.getData("EmpulseAttendance", 2, 23));
		ResultSet L1Approver= PstmtSelect3.executeQuery( );
		while(L1Approver.next())
		{
			ProjectManagerEmployeeId = L1Approver.getString("L1Approver");
		} 
		String ProjectManagerEmailId=PersonalDetails(ProjectManagerEmployeeId)[0];
		String ProjectManagerFirstName= PersonalDetails(ProjectManagerEmployeeId)[2];
		String ProjectManagerLastName= PersonalDetails(ProjectManagerEmployeeId)[3];

		From = ReadEmailFromDB()[0];
		ActualSubject= ReadEmailFromDB()[1];
		//System.out.println(ActualSubject); 
		ExpectedSubject="Shift Allowance Rejected by : "+ProjectManagerFirstName+" "+ProjectManagerLastName+"";
		//System.out.println(ExpectedSubject);
		
		try {
			MailInitialiser();
			String ActualBody= driver.findElement(By.xpath("/html/body")).getText();
			String ExpectedBody="Actual receipeints="+EmployeeEmailId+"\n"
					+ "Actual CCs="+SupervisorEmailId+";"+ProjectManagerEmailId+"\n"
					+ "Actual BCCs=\n"
					+ "Dear " +EmployeeFirstName+" "+EmployeeLastName+",\n\n"
					+ "Kindly note the shift allowance submitted by " +EmployeeFirstName+" "+EmployeeLastName+" ("+EmployeeId+") for the month of "+MonthName+" - "+Year+" is Rejected by "+ProjectManagerFirstName +""+ProjectManagerLastName+".\n\n"
					+ "Rejection Remarks: rejected\n"
					+ "Note: The Shift request would be rejected for the whole month, employee can fill the roaster and resubmit the request again. Thanks and Regards,\n"
					+ "Shift Allowance Admin\n\n"
					+ "Please do not response to this email. For any technical/functional issues,Kindly raise your service request using: BMC Remedy Service desk portal (Finance Application > Shift Allowance).";
			Assert.assertTrue(From.equalsIgnoreCase("noreply.shiftallowance.hr@capgemini.com"));
			Assert.assertTrue(ActualSubject.equalsIgnoreCase(ExpectedSubject));
			Assert.assertTrue(ActualBody.equals(ExpectedBody));


		} catch(IOException e){
			System.out.println("exception");
		}
		finally{
			HtmlToTxt();
		}
	}
	
		
		
	
	@Test(priority=5, enabled= false, description="Verify that EMPLOYEE receives mail in correct format when the request raised by employee is APPROVED by PM",invocationCount=1)
	public void VerifyEmailOnApprovalByPM() throws Throwable
	{
		//---- WRITE CODE TO SUBMIT A REQUEST AND GET IT APPROVED BY SUPERVISOR AND THEN GET IT APPROVED BY PM-----
		
		
				//----------------------------------------
		

		String From=null;String ActualSubject=null; String ExpectedSubject=null;
		String ProjectManagerEmployeeId=null;
		String EmployeeId=Data.getData("EmpulseAttendance", 2, 0);
		String Year = Data.getData("EmpulseAttendance", 2, 22); String MonthName= Apply_Shift_Page.months[Integer.parseInt(Data.getData("EmpulseAttendance", 2, 23))]; 
		String EmployeeEmailId = PersonalDetails(EmployeeId)[0];
		EmployeeId= PersonalDetails(EmployeeId)[1];
		String	EmployeeFirstName= PersonalDetails(EmployeeId)[2];
		String	EmployeeLastName= PersonalDetails(EmployeeId)[3];
		String SupervisorEmployeeId= PersonalDetails(EmployeeId)[4];
		String SupervisorEmailId = PersonalDetails(SupervisorEmployeeId)[0];

		PreparedStatement  PstmtSelect3= conn.prepareStatement( "SELECT L1Approver FROM [GshiftAllowance_SIT].[dbo].[tblprojectmaster] where projectnumber IN ( SELECT ProjectNumber from [GshiftAllowance_SIT].[dbo].[tblshiftrequestdetails] where RequestID IN (select RequestID from [GshiftAllowance_SIT].[dbo].[tblshiftrequest] where EmployeeId =? and Year =? and Month =?))"); 
		PstmtSelect3.setString( 1, Data.getData("EmpulseAttendance", 2, 0));
		PstmtSelect3.setString( 2, Data.getData("EmpulseAttendance", 2, 22));
		PstmtSelect3.setString( 3, Data.getData("EmpulseAttendance", 2, 23));
		ResultSet L1Approver= PstmtSelect3.executeQuery( );
		while(L1Approver.next())
		{
			ProjectManagerEmployeeId = L1Approver.getString("L1Approver");
		} 
		String ProjectManagerEmailId=PersonalDetails(ProjectManagerEmployeeId)[0];
		String ProjectManagerFirstName= PersonalDetails(ProjectManagerEmployeeId)[2];
		String ProjectManagerLastName= PersonalDetails(ProjectManagerEmployeeId)[3];

		From = ReadEmailFromDB()[0];
		ActualSubject= ReadEmailFromDB()[1];
		//System.out.println(ActualSubject); 
		ExpectedSubject="Shift Allowance Approved for : "+EmployeeFirstName+" "+EmployeeLastName+" ("+EmployeeId+")";
		//System.out.println(ExpectedSubject);
		
		try {
			MailInitialiser();
			String ActualBody= driver.findElement(By.xpath("/html/body")).getText();
			System.out.println(ActualBody);
			String ExpectedBody="Actual receipeints="+EmployeeEmailId +"\n"
					+ "Actual CCs="+SupervisorEmailId+";"+ProjectManagerEmailId+"\n"
					+ "Actual BCCs=\n"
					+ "Dear " +EmployeeFirstName+" "+EmployeeLastName+" EmployeeId,\n\n"
					+ "Kindly note the shift allowance submitted by " +EmployeeFirstName+" "+EmployeeLastName+" ("+EmployeeId+") for the month of "+MonthName+" - "+Year+" is Approved by "+ProjectManagerFirstName +""+ProjectManagerLastName+".\n\n"
					+ "Thanks and Regards,\n"
					+ "Shift Allowance Admin\n\n"
					+ "Please do not response to this email. For any technical/functional issues,Kindly raise your service request using: BMC Remedy Service desk portal (Finance Application > Shift Allowance).";
			//System.out.println(ExpectedBody);
			Assert.assertTrue(From.equalsIgnoreCase("noreply.shiftallowance.hr@capgemini.com"));
			Assert.assertTrue(ActualSubject.equalsIgnoreCase(ExpectedSubject));
			Assert.assertTrue(ActualBody.equals(ExpectedBody));


		} catch(IOException e){
			System.out.println("exception");
		}
		finally{
			HtmlToTxt();
		}	
	}

	
	
	
	
	@AfterMethod(enabled=false)
	public void tearDown(ITestResult result) throws Throwable {
		if (ITestResult.FAILURE == result.getStatus()) {
			String name =result.getName();
			screenshot.CaptureScrShot(name);
		}
		
		DB.DeletingRequestDetails();
		driver.quit();
	}
	
	// Deleting the DATA
		@AfterTest(enabled = false)
		public void DeletingData() throws Throwable {
			DB.DeletingData();
		}
	
	
}
