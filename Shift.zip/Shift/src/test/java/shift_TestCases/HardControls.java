package shift_TestCases;


import java.sql.Connection;
import java.sql.PreparedStatement;



import java.sql.SQLException;


import org.testng.Assert;
import org.testng.ITestResult;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import shift_Pages.Apply_Shift_Page;
import shift_Pages.HomePage;
import shift_Pages.LoginPage;
import shift_Testbase.TestBase;
import utilities.DB_Operation;
import utilities.Read_Excel;
import utilities.ScreenShot;

public class HardControls extends TestBase {

	DB_Operation DB;
	LoginPage login;   HomePage home;  Apply_Shift_Page apply;   Read_Excel Data; ScreenShot screenshot;
	Connection conn; 
	String uid;  String pass;
	 
	 
	//final boolean sap= false;

	@BeforeTest
	public void CreatingData() throws Throwable {
	   // status[0]=false;
		//status[1]=true;
		//status[2]=false;
		
		DB= new DB_Operation();
	//	DB.InsertingDataShiftDetails("ShiftDetails");// INSERTING DATA INTO SHIFTDETAILS TABLE											 
		//DB.InsertingDataEmpulseAtt("EmpulseAttendance");// INSERING DATA INTO EMPULSEATTENDANCE TABLE											 
		Data= new Read_Excel();
		login=new LoginPage();
		home = new HomePage();
		apply = new Apply_Shift_Page(); screenshot = new ScreenShot();
		conn=DB.ConnectingToDB();
		uid = Data.getData("LogInData", 1, 0);// storing the username;
		pass = Data.getData("LogInData", 1, 1);//storing the password
	}
	
	
	@BeforeMethod
	public void setUp() throws Exception {
		StartBrowser();
		
	}
	
	
	
	@Test(priority=1, enabled= true, description="Verify employee is able to submit Shift with the project , shift and task details- Individually , not using BULK INSERT option.",invocationCount=100)
	public void IndividualDayShiftSubmit() throws Throwable
	{
		  login.LogIn(uid, pass);
		  home.LogOff();
		 /* home.Shift();
		  Boolean isMonthToBeClickedPresent =apply.MonthToBeClicked();
		  Assert.assertTrue(isMonthToBeClickedPresent);
		  this.waitElementNotVisible("Spinner");
		  apply.IndividualApply(Data.getData("EmpulseAttendance", 2, 24), Data.getData("ProjectDetails", 1, 0), Data.getData("ProjectDetails", 1, 1));
		  this.scrollpagebottom();
		  this.explicitwaitClick("Submit");
		  Thread.sleep(5000);
		  this.Click("Submit");
		  this.explicitwaitClick("OKButton");
		  this.Click("OKButton");
		  this.explicitwaitClick("OKButtonAfterSubmit");
		  this.Click("OKButtonAfterSubmit");
		  String StatusId = DB.FindStatusId();
		  Assert.assertTrue(StatusId.contains("2"));*/
		  	  
	}
	
	
	
	@Test(priority=2, enabled= false, description="Verify shift request  should  be submitted by the employee when working hours is equal to 8.30 hrs.")
	public void ShiftSubmittedWithAverageWrkHrs() throws SQLException, Throwable
	{
		  PreparedStatement  PstmtUpdate= conn.prepareStatement( "UPDATE  [GshiftAllowance_SIT].[dbo].[tbl_Fact_EmpulseAttendance] SET PunchInTime='06:00:00 ',PunchOutTime='14:30:00 PM',ActHrsWorked='08:30:00',AttendanceClassification='W(-)' where EmpID=? and Month=? and Date=?" ); 
		  PstmtUpdate.setString( 1, Data.getData("EmpulseAttendance", 2, 0));
		  PstmtUpdate.setString( 2, Data.getData("EmpulseAttendance", 2, 23));
		  PstmtUpdate.setString( 3, Data.getData("EmpulseAttendance", 2, 24));
		  PstmtUpdate.executeUpdate();
		  
		  login.LogIn(uid, pass);
		  home.Shift();
		  Boolean isMonthToBeClickedPresent =apply.MonthToBeClicked(); 
		  Assert.assertTrue(isMonthToBeClickedPresent);
		  this.waitElementNotVisible("Spinner");
		  apply.IndividualApply(Data.getData("EmpulseAttendance", 2, 24), Data.getData("ProjectDetails", 1, 0), Data.getData("ProjectDetails", 1, 1));
		  this.scrollpagebottom();
		  this.explicitwaitClick("Submit");
		  Thread.sleep(5000);
		  this.Click("Submit");
		  this.explicitwaitClick("OKButton"); 
		  this.Click("OKButton");
		  this.explicitwaitClick("OKButtonAfterSubmit");
		  this.Click("OKButtonAfterSubmit");
		  String StatusId = DB.FindStatusId();
		  Assert.assertTrue(StatusId.contains("2"));
	}
	
	
	@Test(priority=3, enabled= false, description="Verify for days  having work hours less than 8.30 hrs,  is  highlighted in orange and shift request should not be raised for those days ")
	public void ShiftNotSubmittedWithPoorWrkHrs() throws Throwable
	{
		  //For a particular day making the employee data as LESS THAN 8.30 HRS
		  PreparedStatement  PstmtUpdate= conn.prepareStatement( "UPDATE  [GshiftAllowance_SIT].[dbo].[tbl_Fact_EmpulseAttendance] SET PunchInTime='06:00:00 ',PunchOutTime='14:29:00 PM',ActHrsWorked='08:29:00',AttendanceClassification='W(-)' where EmpID=? and Month=? and Date=?" ); 
		  PstmtUpdate.setString( 1, Data.getData("EmpulseAttendance", 2, 0));
		  PstmtUpdate.setString( 2, Data.getData("EmpulseAttendance", 2, 23));
		  PstmtUpdate.setString( 3, Data.getData("EmpulseAttendance", 2, 24));
		  PstmtUpdate.executeUpdate();
				  
				  
		  login.LogIn(uid, pass);
		  home.Shift();
		  Boolean isMonthToBeClickedPresent =apply.MonthToBeClicked(); 
		  Assert.assertTrue(isMonthToBeClickedPresent);
		  this.waitElementNotVisible("Spinner");
		  String ExpectedColour = "#FF7F50";
		  String ActualColour= apply.ExtractColour(Data.getData("EmpulseAttendance", 2, 24));
		  Assert.assertTrue(ActualColour.equalsIgnoreCase(ExpectedColour));
		  Boolean isPlusSignPresent= apply.ClickPlusSign(Data.getData("EmpulseAttendance", 2, 24));
		  Assert.assertFalse(isPlusSignPresent);
		 
	}
	
	
	@Test (priority=5, enabled= false, description="Verify that the following message Swipe details not available from Empulse. In case of employees working from home or Client Location please have your regularized attendance approve by Supervisor in Empulse application")
	public void SwipeDetailsNotAvailableMessageDisplayed() throws SQLException, Throwable
	{
		  PreparedStatement  PstmtUpdate= conn.prepareStatement( "DELETE FROM  [GshiftAllowance_SIT].[dbo].[tbl_Fact_EmpulseAttendance] where EmpID=? and Year=? and  Month=? " ); 
		  PstmtUpdate.setString( 1, Data.getData("EmpulseAttendance", 2, 0));
		  PstmtUpdate.setString( 2, Data.getData("EmpulseAttendance", 2, 22));
		  PstmtUpdate.setString( 3, Data.getData("EmpulseAttendance", 2, 23));
		  PstmtUpdate.executeUpdate();
		
		  login.LogIn(uid, pass);
		  home.Shift();
		  Boolean isMonthToBeClickedPresent =apply.MonthToBeClicked(); 
		  Assert.assertTrue(isMonthToBeClickedPresent);
		  this.waitElementNotVisible("Spinner");
		  Boolean isSwipeDetailsNotAvailableMessageDisplayed=  this.isTextDisplayed("Swipe details not available from Empulse for certain days. In case of employees working from home/Client Location, please have your regularized attendance approved by Supervisor in Empulse application.");
	      Assert.assertTrue(isSwipeDetailsNotAvailableMessageDisplayed);
	
	}
	
	
	@Test (priority=7, enabled= false, description="Verify that even if the roaster is available for only one day of the month, i.e the employee is tagged in a shift for only particular day of the month, the following message,'Shift roster for <Month - Year> is not available from empulse application, please contact your Supervisor or you can apply for On-Call shift.', should not be displayed ")
	public void RoasterDetailsNotAvailableMessageNotDisplayed() throws SQLException, Throwable
	{
		//Deleting all the data from SHIFTDETAILS TABLE EXCEPT FOR ONE DAY
		 PreparedStatement  PstmtUpdate= conn.prepareStatement( "DELETE FROM  [GshiftAllowance_SIT].[dbo].[tbl_Fact_EmpulseShiftDetails] where EmpID=? and Year=? and  Month=? and date !=?" ); 
		  PstmtUpdate.setString( 1, Data.getData("ShiftDetails", 2, 0));
		  PstmtUpdate.setString( 2, Data.getData("ShiftDetails", 2, 5));
		  PstmtUpdate.setString( 3, Data.getData("ShiftDetails", 2, 6));
		  PstmtUpdate.setString( 4, Data.getData("ShiftDetails", 2, 7));
		  PstmtUpdate.executeUpdate();
		
		  login.LogIn(uid, pass);
		  home.Shift();
		  Boolean isMonthToBeClickedPresent =apply.MonthToBeClicked(); 
		  Assert.assertTrue(isMonthToBeClickedPresent);
		  this.waitElementNotVisible("Spinner");
		  Boolean isRoasterDetailsNotAvailableMessageDisplayed=  this.isTextDisplayed("(Shift roster for April-2019 is not available from empulse application, please contact your Supervisor or you can apply for On-Call shift.)");
	      Assert.assertFalse(isRoasterDetailsNotAvailableMessageDisplayed);
	
	} 
	
	
	@Test (priority=8, enabled= false, description="Verify if roster for the  month is not available from Empulse then message should be displayed as,Shift roster for month-year is not available from empulse application,please contact your Supervisor or you can apply for On-Call shift.")
	public void RoasterDetailsNotAvailableMessageDisplayed() throws SQLException, Throwable
	{
		  DB.DeletingData();
		  login.LogIn(uid, pass);
		  home.Shift();
		  Boolean isMonthToBeClickedPresent =apply.MonthToBeClicked(); 
		  Assert.assertTrue(isMonthToBeClickedPresent);
		  this.waitElementNotVisible("Spinner");
		  Boolean isRoasterDetailsNotAvailableMessageDisplayed=  this.isTextDisplayed("(Shift roster for April-2019 is not available from empulse application, please contact your Supervisor or you can apply for On-Call shift.)");
	      Assert.assertTrue(isRoasterDetailsNotAvailableMessageDisplayed);
	
	}
	


	@Test(priority=9, enabled= false, description="Verify Plus sign and Cancel sign  are  available on the days of the selected month even if  shift roster details are not avaialable from Empulse ")
	public void PlusCancelSignAvailable() throws Throwable
	{
		 DB.DeletingData();
		  login.LogIn(uid, pass);
		  home.Shift();
		  Boolean isMonthToBeClickedPresent =apply.MonthToBeClicked(); 
		  Assert.assertTrue(isMonthToBeClickedPresent);
		  this.waitElementNotVisible("Spinner");
		  Boolean isPlusCancelSignPresentinAllDay= apply.isPlusCancelSignPresentOnAllDays();
		  Assert.assertTrue(isPlusCancelSignPresentinAllDay);
	}
	
	@Test(priority=10, enabled= false, description="Verify  employee is able to apply OnCall shift type   when shift roster details are  not avaialable from Empulse")
	public void OnCallRequestWhenRoasterNotAvailable() throws Throwable
	{
		 DB.DeletingData();
		 login.LogIn(uid, pass);
		 home.Shift();
		 Boolean isMonthToBeClickedPresent =apply.MonthToBeClicked(); 
		 Assert.assertTrue(isMonthToBeClickedPresent);
		 this.waitElementNotVisible("Spinner");
		 String ShiftType= apply.IndividualApply(Data.getData("EmpulseAttendance", 2, 24),  Data.getData("ProjectDetails", 1, 0), Data.getData("ProjectDetails", 1, 1));
		 Assert.assertTrue(ShiftType.equalsIgnoreCase("On Call"));
		 this.scrollpagebottom();
		 this.explicitwaitClick("Submit");
		 this.Click("Submit");
		 this.explicitwaitClick("OKButton");
		 this.Click("OKButton");
		 this.explicitwaitClick("OKButtonAfterSubmit");
		 this.Click("OKButtonAfterSubmit");
		 String StatusId = DB.FindStatusId();
		 Assert.assertTrue(StatusId.contains("2"));
	}
	
	
	@AfterMethod(enabled=true)
	public void tearDown(ITestResult result) throws Throwable {
		if (ITestResult.FAILURE == result.getStatus()) {
			String name =result.getName();
			screenshot.CaptureScrShot(name);
		}
		
		DB.DeletingRequestDetails();
		driver.quit();
	}
	
	// Deleting the DATA
		@AfterTest(enabled = false)
		public void DeletingData() throws Throwable {
			DB.DeletingData();
		}
}
