package shift_TestCases;

import java.sql.Connection;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.testng.Assert;
import org.testng.ITestResult;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

import shift_Pages.Apply_Shift_Page;
import shift_Pages.HomePage;
import shift_Pages.LoginPage;
import shift_Pages.PMApprovalPage;
import shift_Pages.ReopenRequestPage;
import shift_Pages.SupervisorApprovalPage;
import shift_Testbase.TestBase;
import utilities.DB_Operation;
import utilities.Read_Excel;
import utilities.ScreenShot;

public class ReopenRequestWorkFlow extends TestBase{

	DB_Operation DB;LoginPage login; HomePage home; Apply_Shift_Page apply; Read_Excel Data; ScreenShot screenshot; Connection conn;SupervisorApprovalPage Sup;
	String uid; String pass;PMApprovalPage PM;ShiftRequestWorkFlow Flow; ReopenRequestPage ReopenReq;String supempid;String SupNTUserID; String PMEmpid; String PMNTUserID;
	
	
	
	@BeforeTest
	public void CreatingData() throws Throwable
	{		
		//Creating objects for the pages of application
		login=new LoginPage();home = new HomePage();apply = new Apply_Shift_Page(); Sup=new SupervisorApprovalPage();
		 PM = new PMApprovalPage();Flow= new ShiftRequestWorkFlow();ReopenReq=new ReopenRequestPage();
		 Flow.CreatingData();
		//Creating objects for UTILITY CLASSES
		Data= new Read_Excel();DB= new DB_Operation();conn=DB.ConnectingToDB();screenshot = new ScreenShot();
		
		uid = Data.getData("LogInData", 1, 0);// storing the username;
		pass = Data.getData("LogInData", 1, 1);//storing the password
		supempid= DB.RequiredDetails(Data.getData("EmpulseAttendance", 2, 0), "SupervisorID");
		SupNTUserID=DB.RequiredDetails(supempid, "NTUserID");
	}
	

	@BeforeMethod
	public void setUp() throws Exception {
		StartBrowser();		
	}
	
	
	@Test(priority=1, enabled = true,description="Verify that the option Reopen is displayed on hovering over the tab Shift",invocationCount=1)
	public void ReopenDisplayed() throws Throwable
	{
		login.LogIn(uid, pass);
		this.hover("ShiftButton");
		Assert.assertTrue(this.isDisplayed("Reopen"));
		
	}
	
	@Test(priority=2, enabled = true,description="Verify that an employee can raise a request to reopen any of the request of  last three month if the field Shift status has  value Approved & Closed and other necessary details are filled.",invocationCount=1)
	public void ReopeningAppClosed() throws Throwable
	{
		
		Flow.PMApproval();
		this.Click("LogOff");
		Assert.assertTrue(DB.FindStatusId().contains("9"));
		login.LogIn(uid, pass);
		home.Reopen(); 
		ReopenReq.RaiseReopenRequest("Closed_Approved");
		String StatusId = DB.FindStatusId();
		Assert.assertTrue(StatusId.contains("12"));
	}
	
	@Test(priority=3, enabled = true,description="Verify that an employee can raise a request to reopen any of the request of  last three month if the field Shift status has  value Approved & Closed and other necessary details are filled.",invocationCount=1)
	public void ReopeningProOwnApp() throws Throwable
	{
		  login.LogIn(uid, pass);
		  home.Shift();
		  Boolean isMonthToBeClickedPresent =apply.MonthToBeClicked(); 
		  Assert.assertTrue(isMonthToBeClickedPresent);
		  this.waitElementNotVisible("Spinner");
		  apply.IndividualApply(Data.getData("EmpulseAttendance", 2, 24), Data.getData("ProjectDetails", 1, 0), Data.getData("ProjectDetails", 1, 1));
		  apply.IndividualApply(Data.getData("EmpulseAttendance", 5, 24), Data.getData("ProjectDetails", 1, 0), Data.getData("ProjectDetails", 2, 1));
		  this.scrollpagebottom();
		  this.explicitwait("Submit");
		  this.explicitwaitClick("Submit");		
		  Thread.sleep(3000);
		  this.Click("Submit");		 
		  this.explicitwaitClick("OKButton");
		  this.Click("OKButton");
		  this.explicitwaitClick("OKButtonAfterSubmit");
		  this.Click("OKButtonAfterSubmit");
		  String StatusId = DB.FindStatusId();
		  Assert.assertTrue(StatusId.contains("2"));	
		  this.Click("LogOff");
		  login.LogIn(SupNTUserID, pass);
		  Sup.SupShiftApproval();
		  Sup.SupShiftApproval();
		  StatusId = DB.FindStatusId();
		  Assert.assertTrue(StatusId.contains("3"));
		  this.Click("LogOff");
		  PMEmpid=DB.PMEMPID();
	      PMNTUserID=DB.RequiredDetails(PMEmpid, "NTUserID");
		  login.LogIn(PMNTUserID, pass);
		  PM.PMShiftApproval();
		  Assert.assertTrue(DB.FindStatusId().contains("5"));
		  this.Click("LogOff");
		  login.LogIn(uid, pass);
		  home.Reopen(); 
		  ReopenReq.RaiseReopenRequest("ProjectOwner_Approved");
		  StatusId = DB.FindStatusId();
		  Assert.assertTrue(StatusId.contains("12"));
	}
	
	@Test(priority=4, enabled = true,description="Verify that an employee can raise a request to reopen any of the request of  last three month if the field Shift status has  value Approved & Closed and other necessary details are filled.",invocationCount=1)
	public void ReopeningSupApp() throws Throwable
	{
		
		Flow.SupervisorApproval();
		this.Click("LogOff");
		Assert.assertTrue(DB.FindStatusId().contains("3"));
		login.LogIn(uid, pass);
		home.Reopen(); 
		ReopenReq.RaiseReopenRequest("Supervisor_Approved");
		String StatusId = DB.FindStatusId();
		Assert.assertTrue(StatusId.contains("12"));
	}
	
	@Test(priority=5, enabled = true,description="Verify that an employee can raise a request to reopen any of the request of  last three month if the field Shift status has  value Approved & Closed and other necessary details are filled.",invocationCount=1)
	public void ReopeningSubmittedReq() throws Throwable
	{
		//Flow.CreatingData();
		Flow.SubmitShiftRequest();
		Assert.assertTrue(DB.FindStatusId().contains("2"));
		home.Reopen(); 
		ReopenReq.RaiseReopenRequest("Submitted");
		String StatusId = DB.FindStatusId();
		Assert.assertTrue(StatusId.contains("12"));
	}
	
	@Test(priority=6, enabled = true,description="Verify that an employee can raise a request to reopen any of the request of  last three month if the field Shift status has  value Approved & Closed and other necessary details are filled.",invocationCount=1)
	public void isTextDisplayed() throws Throwable
	{
		login.LogIn(uid, pass);
		home.Reopen(); 
		String ExpectedInstructions="� Reopen request can only be raised if the shift request is in the submitted , closed & approved.\n"
				+ "� When the shift request gets reopen then data from the empulse will be fetched such as : Regularize If the supervisor change the rostering in empulse then this will get reflected in the reopen.\n"
				+ "� Employee can submit for shift for the entire month\n"
				+ "� Month wise reopen of shift can be done\n"
				+ "�Empulse data should be regularize and roster for the entire month should be available .\n"
				+ "� Only those request which are either in the submitted , closed or approved can be reopen (month wise) .";
//System.out.println("Expected Instructions is : \n"+ExpectedInstructions);

	String ActualInstructions=	this.findelement("Instructions").getText();
	//System.out.println("Actual Instructions is : \n"+ActualInstructions);
    Assert.assertTrue(ActualInstructions.contains(ExpectedInstructions));
	}
	
	@Test(priority=7, enabled = true,description="Verify that an email is triggered to the supervisor after an employee successfully submits a request for reopening of a SHIFT request.",invocationCount=1)
	public void VerifyEmailOnSubmissionOfReopenRequest() throws Throwable
	{
		ReopeningSubmittedReq();
		driver.close();
		Assert.assertTrue(ReopenReq.VerifyEmailFormatOfReopenRequest());
	}
	
	@Test(priority=8, enabled = true,description="Verify that the option Supervisor Reopen is dispalyed on hovering over the tab Approval if the looged in employee has the role of SUPERVISOR.",invocationCount=1)
	public void SupReopenOptDisplayed() throws Throwable
	{
		login.LogIn(SupNTUserID, pass);
        this.hover("Approval");
        Assert.assertTrue(this.isDisplayed("SupervisorReopen"));
	}
	
	@Test(priority=9, enabled = true,description="Verify that a SUPERVISOR can reject a reopen request.",invocationCount=1)
    public void RejectReopenRequ() throws Throwable
    {
		ReopeningSubmittedReq();
		this.Click("LogOff");
		login.LogIn(SupNTUserID, pass);
        Sup.ReopenReqRejection();
        String StatusId = DB.FindStatusId();
		Assert.assertTrue(StatusId.contains("13"));
    }
	
	@Test(priority=10, enabled = true,description="Verify that employee receives an email once the reopen request is rejected by the  Supervisor.",invocationCount=1)
	public void VerifyEmailOnRejectionOfReopenRequest() throws Throwable
	{
		RejectReopenRequ();
		driver.close();
		Assert.assertTrue(Sup.VerifyEmailFormatOnReopenRequestRejected());
	}

	@Test(priority=11, enabled = true,description="Verify that employee receives an email once the reopen request is rejected by the  Supervisor.",invocationCount=1)
	public void ReopenReqRaisedAgainAfterRejection() throws Throwable
	{
		RejectReopenRequ();
		this.Click("LogOff");
		login.LogIn(uid, pass);
		home.Reopen(); 
		ReopenReq.RaiseReopenRequest("Reopen_Rejected");
		String StatusId = DB.FindStatusId();
		Assert.assertTrue(StatusId.contains("12"));
	}
	
	@Test(priority=12, enabled = true,description="Verify that a SUPERVISOR can approve a reopen request.",invocationCount=1)
    public void ApproveReopenRequ() throws Throwable
    {
		ReopeningSubmittedReq();
		this.Click("LogOff");
		login.LogIn(SupNTUserID, pass);
        Sup.ReopenReqApproval();
        String StatusId = DB.FindStatusId();
		Assert.assertTrue(StatusId.contains("11"));
    }
	
	@Test(priority=13, enabled = true,description="Verify that employee receives an email once the reopen request is approved by the  Supervisor.",invocationCount=1)
    public void VerifyEmailOnApprovalOfReopenRequest() throws Throwable
    {
		ApproveReopenRequ();
		driver.close();
		Assert.assertTrue(Sup.VerifyEmailFormatOnReopenRequestApproved());

    }
	
	@Test(priority=14, enabled = true,description="Verify that the roaster is autopopulated with data from empulse once a REQUEST is reopened and the employee is able to raise request again.",invocationCount=1)
    public void SubmitShiftRequestAfterApprovalOfReopenRequest() throws Throwable
    {
		ApproveReopenRequ();
		this.Click("LogOff");
		Flow.SubmitShiftRequest();
    }
	
	
	@AfterMethod(enabled=true)
	public void tearDown(ITestResult result) throws Throwable
	{		
		DB.DeletingRequestDetails();	
		//Taking Screenshots when test cases FAIL
		if (ITestResult.FAILURE == result.getStatus()) {
			String name =result.getName();
			screenshot.CaptureScrShot(name);
		}		
		driver.quit();		
	}
	
	// Deleting the DATA
			@AfterTest(enabled = true)
			public void DeletingData() throws Throwable {			
				DB.DeletingData();			
			}
	
	
}
