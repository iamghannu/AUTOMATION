package shift_TestCases;

import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.testng.Assert;
import org.testng.ITestResult;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

import shift_Pages.Apply_Shift_Page;
import shift_Pages.HomePage;
import shift_Pages.LoginPage;
import shift_Pages.PMApprovalPage;
import shift_Pages.SupervisorApprovalPage;
import shift_Testbase.TestBase;
import utilities.DB_Operation;
import utilities.Read_Excel;
import utilities.ScreenShot;

public class ShiftRequestWorkFlow extends TestBase {
	
	DB_Operation DB;LoginPage login; HomePage home; Apply_Shift_Page apply; Read_Excel Data; ScreenShot screenshot; Connection conn;SupervisorApprovalPage Sup;
	String uid; String pass;PMApprovalPage PM;String supempid;String SupNTUserID; String PMEmpid; String PMNTUserID;
	WebDriver instances;
	//Make sure the first data of the excel sheets are that of a working day whatever the date be it and the whole data is for same month.
	
	@BeforeTest
	public void CreatingData() throws Throwable {
		
		//Creating objects for the pages of application
		login=new LoginPage();home = new HomePage();apply = new Apply_Shift_Page(); Sup=new SupervisorApprovalPage();
		PM = new PMApprovalPage();
		
		//Creating objects for UTILITY CLASSES
		Data= new Read_Excel();DB= new DB_Operation();conn=DB.ConnectingToDB();screenshot = new ScreenShot();
		
		//DB.InsertingDataShiftDetails("ShiftDetails");// INSERTING DATA INTO SHIFTDETAILS TABLE											 
		//DB.InsertingDataEmpulseAtt("EmpulseAttendance");// INSERING DATA INTO EMPULSEATTENDANCE TABLE		
		
		uid = Data.getData("LogInData", 1, 0);// storing the username;
		pass = Data.getData("LogInData", 1, 1);//storing the password
		supempid= DB.RequiredDetails(Data.getData("EmpulseAttendance", 2, 0), "SupervisorID");
		SupNTUserID=DB.RequiredDetails(supempid, "NTUserID");
	}
	

	@BeforeMethod
	public void setUp() throws Exception {
		StartBrowser();		
	}
	
	
	@Test(priority = 1, enabled =true,description="Verify employee is able to submit Shift with the project , shift and task details",invocationCount=1)
	public void SubmitShiftRequest() throws Throwable {
		  
		  login.LogIn(uid, pass);
		  home.Shift();
		  Boolean isMonthToBeClickedPresent =apply.MonthToBeClicked(); 
		  Assert.assertTrue(isMonthToBeClickedPresent);
		  this.waitElementNotVisible("Spinner");
		  apply.IndividualApply(Data.getData("EmpulseAttendance", 2, 24), Data.getData("ProjectDetails", 1, 0), Data.getData("ProjectDetails", 1, 1));
		  this.scrollpagebottom();
		  this.explicitwait("Submit");
		  this.explicitwaitClick("Submit");		
		  Thread.sleep(3000);
		  this.Click("Submit");		 
		  this.explicitwaitClick("OKButton");
		  this.Click("OKButton");
		  this.explicitwaitClick("OKButtonAfterSubmit");
		  this.Click("OKButtonAfterSubmit");
		  String StatusId = DB.FindStatusId();
		  Assert.assertTrue(StatusId.contains("2"));		
}
	
	
	@Test(priority=2, enabled =true, description="Verify that SUPERVISOR receives mail in correct format when a employee raises a request.",invocationCount=1)
	public void VerifyEmailOnSubmissionOfRequest() throws Throwable
	{
		SubmitShiftRequest();
		driver.close();
		Assert.assertTrue(apply.VerifyEmailFormatOfShiftRequest());
	}
	
	@Test(priority=3, enabled= true, description="Verify that SUPERVISOR can approve requests from his queue.",invocationCount=1)
	public void SupervisorApproval() throws Throwable
	{
		SubmitShiftRequest();
		this.Click("LogOff");
		login.LogIn(SupNTUserID, pass);
		Sup.SupShiftApproval();
		String StatusId = DB.FindStatusId();
		Assert.assertTrue(StatusId.contains("3"));
	}
	

	
	@Test(priority=4,enabled =true, description="Verify that SUPERVISOR can approve requests from his queue.",invocationCount=1)
	public void VerifyEmailOnApprovalBySupervisor() throws Throwable
	{
	SupervisorApproval();
	driver.close();
	Assert.assertTrue(Sup.VerifyEmailFormatOnAppBySup());	
}
	
	@Test(priority=5, enabled =true, description="Verify that PM can approve requests from his queue.",invocationCount=1)
	public  void PMApproval() throws Throwable
	{
		SupervisorApproval();
		this.Click("LogOff");
		PMEmpid=DB.PMEMPID();
		PMNTUserID=DB.RequiredDetails(PMEmpid, "NTUserID");
		login.LogIn(PMNTUserID, pass);
		PM.PMShiftApproval();
		String StatusId = DB.FindStatusId();
		Assert.assertTrue(StatusId.contains("9"));
	}
	
	
	@Test(priority=6, enabled =true, description="Verify that EMPLOYEE receives mail in correct format when the request raised by employee is APPROVED by PM",invocationCount=1)
	public void VerifyEmailOnApprovalByPM() throws Throwable
	{
		PMApproval();
        driver.close();
        Assert.assertTrue(PM.VerifyEmailFormatOnAppByPM());
	}
	
	@Test(priority=7, enabled =true, description="Verify that PM can reject requests from his queue.",invocationCount=1)
	public void PMRejection() throws Throwable
	{
		
		SupervisorApproval();
		this.Click("LogOff");
		PMEmpid=DB.PMEMPID();
		PMNTUserID=DB.RequiredDetails(PMEmpid, "NTUserID");
		login.LogIn(PMNTUserID, pass);
		PM.PMShiftRejection();
		String StatusId = DB.FindStatusId();
		Assert.assertTrue(StatusId.contains("10"));
	}
	
	
	@Test(priority=8, enabled =true, description="Verify that EMPLOYEE receives mail in correct format when the request raised by employee is REJECTED by PM",invocationCount=1)
	public void VerifyEmailOnRejectedByPM() throws Throwable
	{
		PMRejection();
		driver.close();
		Assert.assertTrue(PM.VerifyEmailFormatOnRejectionByPM());		
	}
	
	@Test(priority=9, enabled =true, description="verify that SUPERVISOR can reject requests from his queue.",invocationCount=1)
	public void SupervisorRejection() throws Throwable
	{
		SubmitShiftRequest();
		this.Click("LogOff");
		login.LogIn(SupNTUserID, pass);
		Sup.SupShiftRejection();
		String StatusId = DB.FindStatusId();
		Assert.assertTrue(StatusId.contains("4"));
	}
	
	
	@Test(priority=10, enabled =true, description="Verify that EMPLOYEE receives mail in correct format when the request raised by employee is REJECTED by SUPERVISOR.",invocationCount=1)
	public void VerifyEmailOnRejectionBySupervisor() throws Throwable
	{
		SupervisorRejection();
		driver.close();
		Assert.assertTrue(Sup.VerifyEmailFormatOnRejectionBySup());	
	}
	
	
	@AfterMethod(enabled=true,alwaysRun=true)
	public void tearDown(ITestResult result) throws Throwable {
		
		DB.DeletingRequestDetails();
		//Taking Screenshots when test cases FAIL
		if (ITestResult.FAILURE == result.getStatus()) {
			String name =result.getName();
			screenshot.CaptureScrShot(name);
		}
		
		driver.quit();
	}
	
	  // Deleting the DATA
		@AfterTest(enabled = true)
		public void DeletingData() throws Throwable {			
			DB.DeletingData();			
		}
	
	
	
	
	
	
	
	
}
