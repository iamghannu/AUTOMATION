package shift_TestCases;




import java.sql.Connection;
import java.sql.PreparedStatement;

import org.testng.Assert;
import org.testng.ITestResult;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;




















import shift_Pages.Apply_Shift_Page;
import shift_Pages.HomePage;
import shift_Pages.LoginPage;
import shift_Testbase.TestBase;
import utilities.DB_Operation;
import utilities.Read_Excel;
import utilities.ScreenShot;

public class UserInterface extends TestBase {

	DB_Operation DB;
	LoginPage login;   HomePage home;  Apply_Shift_Page apply;   Read_Excel Data; ScreenShot screenshot;
	Connection conn;
	String uid;  String pass;
	
	//Make sure the first data of the excel sheets are that of a working day whatever the date be it and the whole data is for same month.
	@BeforeTest
	public void CreatingData() throws Throwable {
		DB= new DB_Operation();
		DB.InsertingDataShiftDetails("ShiftDetails");// INSERTING DATA INTO SHIFTDETAILS TABLE											 
		DB.InsertingDataEmpulseAtt("EmpulseAttendance");// INSERING DATA INTO EMPULSEATTENDANCE TABLE											 
		Data= new Read_Excel();
		login=new LoginPage();
		home = new HomePage();
		apply = new Apply_Shift_Page(); screenshot = new ScreenShot();
		conn=DB.ConnectingToDB();
		uid = Data.getData("LogInData", 1, 0);// storing the username;
		pass = Data.getData("LogInData", 1, 1);//storing the password
	}
	
	
	
	
	@BeforeMethod
	public void setUp() throws Exception {
		StartBrowser();
	}
	
	
	
	
	@Test(priority = 1, enabled =true,description="Checking If Last Three Months Calendar are Displayed Or Not In Sequence")
	public void LastThreeMonthsCalendar() throws Throwable {
		login.LogIn(uid, pass);
		home.Shift();
		Boolean isLatThreeMonthsCalendarPresent = apply.MonthsSequence();
		Assert.assertTrue(isLatThreeMonthsCalendarPresent);
		
		
}
	
	
	@Test(priority = 2, enabled = true, description="Checking If All The Colour Legends  are present or not")
	public void ColourLegends() throws Throwable {
		login.LogIn(uid, pass);
		home.Shift();
		 

		Boolean LegendHolidays = apply.isDisplayed("Holidays");
		Assert.assertTrue(LegendHolidays);
		Boolean LegendVacation = apply.isDisplayed("Vacation");
		Assert.assertTrue(LegendVacation);
		Boolean LegendWeekends = apply.isDisplayed("Weekends");
		Assert.assertTrue(LegendWeekends);
		Boolean LegendAbsent = apply.isDisplayed("Absent");
		Assert.assertTrue(LegendAbsent);
		Boolean LegendLessWrkHrs = apply.isDisplayed("LessWrkHrs");
		Assert.assertTrue(LegendLessWrkHrs);
	}
	
	
	  @Test (priority=3, enabled=true,description="Checking If The ABSENT DAYS are highlighted in RED or not") 
	  public void AbsentDaysHighlightedred () throws Throwable
	  {
		  //For a particular day making the employee data as absent
		  PreparedStatement  PstmtUpdate= conn.prepareStatement( "UPDATE  ["+DB.DBName+"].[dbo].[tbl_Fact_EmpulseAttendance] SET PunchInTime='',PunchOutTime='',ActHrsWorked='0:00:00',AttendanceClassification='AB' where EmpID=? and Month=? and Date=?" ); 
		  PstmtUpdate.setString( 1, Data.getData("EmpulseAttendance", 2, 0));
		  PstmtUpdate.setString( 2, Data.getData("EmpulseAttendance", 2, 23));
		  PstmtUpdate.setString( 3, Data.getData("EmpulseAttendance", 2, 24));
		  PstmtUpdate.executeUpdate();
				  
				  
		  login.LogIn(uid, pass);
		  home.Shift();
		  Boolean isMonthToBeClickedPresent =apply.MonthToBeClicked(); 
		  Assert.assertTrue(isMonthToBeClickedPresent);
		  this.waitElementNotVisible("Spinner");
		  String ExpectedColour = "#ff2a00";
		  String ActualColour= apply.ExtractColour(Data.getData("EmpulseAttendance", 2, 24));
		  Assert.assertTrue(ActualColour.equalsIgnoreCase(ExpectedColour));
		  
	  }
	  
	  @Test (priority=4, enabled=true,description="Checking If The Days having work hours less than 8.30 are highlighted in Orange or not") 
	  public void PoorWrkHrsDaysHighlightedOrange () throws Throwable
	  {
		  //For a particular day making the employee data as absent
		  PreparedStatement  PstmtUpdate= conn.prepareStatement( "UPDATE  ["+DB.DBName+"].[dbo].[tbl_Fact_EmpulseAttendance] SET PunchInTime='06:00:00 ',PunchOutTime='14:29:00 PM',ActHrsWorked='08:29:00',AttendanceClassification='W(-)' where EmpID=? and Month=? and Date=?" ); 
		  PstmtUpdate.setString( 1, Data.getData("EmpulseAttendance", 2, 0));
		  PstmtUpdate.setString( 2, Data.getData("EmpulseAttendance", 2, 23));
		  PstmtUpdate.setString( 3, Data.getData("EmpulseAttendance", 2, 24));
		  PstmtUpdate.executeUpdate();
				  
				  
		  login.LogIn(uid, pass);
		  home.Shift();
		  Boolean isMonthToBeClickedPresent =apply.MonthToBeClicked(); //Boolean isMonthToBeClickedPresent =
		  Assert.assertTrue(isMonthToBeClickedPresent);
		  this.waitElementNotVisible("Spinner");
		  String ExpectedColour = "#FF7F50";
		  String ActualColour= apply.ExtractColour(Data.getData("EmpulseAttendance", 2, 24));
		  Assert.assertTrue(ActualColour.equalsIgnoreCase(ExpectedColour));
		  
	  }
	  
	  @Test (priority=5, enabled=true,description="Checking If Weekends are highlighted in Grey or not") 
	  public void WeekendsHighlightedGrey () throws Throwable
	  {		  
		  login.LogIn(uid, pass);
		  home.Shift();
		  Boolean isMonthToBeClickedPresent =apply.MonthToBeClicked(); 
		  Assert.assertTrue(isMonthToBeClickedPresent);
		  this.waitElementNotVisible("Spinner");
		  String ExpectedColour = "#dddddd";
		  String ActualColour= this.getColour("WeekendDay");
		  Assert.assertTrue(ActualColour.equalsIgnoreCase(ExpectedColour));
		  
	  }
	  
	  @Test(priority=6, enabled=true,description="On Clicking Any Plus Sign, a pop-up  with dropdown  fields Shift  , Project and  Task is displayed or not") 
	 public void PopDisplayedOnClickingPlus () throws Throwable
	  {
		  login.LogIn(uid, pass);
		  home.Shift();
		  Boolean isMonthToBeClickedPresent =apply.MonthToBeClicked(); 
		  Assert.assertTrue(isMonthToBeClickedPresent);
		  this.waitElementNotVisible("Spinner");
		  if(this.isElementPresent("Plus"))
		  {
		  this.explicitwaitClick("Plus");
		  this.Click("Plus");
		  this.explicitwait("PopUpAfterPlusSign");
		  this.isDisplayed("Shift");
		  this.isDisplayed("Project");
		  this.isDisplayed("Task");
		  }
		  else
		  {
			  System.out.println("");
		  }
		  
	  }
	  
	  
	  @Test(priority=7, enabled=true,description="If Bulk Insert Option is available or not?")  
	  public void BulkInsertAvailable() throws Throwable
	  {
		  login.LogIn(uid, pass);
		  home.Shift();
		  Boolean isMonthToBeClickedPresent =apply.MonthToBeClicked(); 
		  Assert.assertTrue(isMonthToBeClickedPresent);
		  this.waitElementNotVisible("Spinner");
		  this.scrollpagebottom();
		  this.explicitwait("BulkInsert");
		  this.isDisplayed("BulkInsert");  
	  }

	
	
	@AfterMethod(enabled=true)
	public void tearDown(ITestResult result) throws Exception {
		
		//Taking Screenshots when test cases FAIL
		if (ITestResult.FAILURE == result.getStatus()) {
			String name =result.getName();
			screenshot.CaptureScrShot(name);
		}
		
		driver.quit();
	}
	
	
	
	  // Deleting the DATA
		@AfterTest(enabled = true)
		public void DeletingData() throws Throwable {
			DB.DeletingData();
		}
	
	
}
